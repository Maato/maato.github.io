#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define GL_GLEXT_PROTOTYPES
#include <GL/gl.h>
#include <GL/glext.h>

#include "renderer.h"

#ifdef EMSCRIPTEN
#include <emscripten.h>
#define exit(a) (emscripten_force_exit(a))
#endif

enum {
	PROGRAM_NONE = 0,
	PROGRAM_LINES = 1,
	PROGRAM_LASER = 2,
	PROGRAM_IMAGE = 3,
	PROGRAM_MAX = 32
};

struct Program {
	bool initialized;
	GLuint id;
	GLuint vertex;
	GLuint fragment;
};

struct ImageProgram {
	GLuint u_sampler_id;
	GLuint u_time_id;
	GLuint a_position_id;
	GLuint a_texcoord_id;

	u32 data_count;
	Vec4 data[1024];
};

struct RenderState {
	bool initialized;
	u8 bound_program;
	GLuint bound_texture;
	bool vertex_attrib_array_enabled;
	bool texcoord_attrib_array_enabled;
	GLuint dynamic_buffer;
	Program programs[PROGRAM_MAX];
	GLuint textures[TEXTURE_MAX];
	ImageProgram imageprogram;
};

static RenderState *render_state = NULL;

static const char program_lines_vertex[] = R"(
	#ifdef GL_ES
	precision mediump float;
	#endif
	attribute vec4 a_position;
	void main()
	{
	    gl_Position = a_position * vec4(1.0, 16.0/ 9.0, 1.0, 1.0);
	}
)";
static const char program_lines_fragment[] = R"(
	#ifdef GL_ES
	precision mediump float;
	#endif
	uniform vec4 u_color;
	void main()
	{
	    gl_FragColor = u_color;
	}
)";
static const char program_laser_vertex[] = R"(
	#ifdef GL_ES
	precision mediump float;
	#endif
	attribute vec4 a_position;
	attribute vec2 a_texcoord;
	varying vec2 v_texcoord;
	void main()
	{
	    gl_Position = a_position * vec4(1.0, 16.0/ 9.0, 1.0, 1.0);
		v_texcoord = a_texcoord;
	}
)";
static const char program_laser_fragment[] = R"( 
	#ifdef GL_ES
	precision mediump float;
	#endif
	varying vec2 v_texcoord;
	uniform float u_length;
	uniform vec4 u_color;
	void main()
	{
		float len = 0.0;

		if(v_texcoord.x < 0.5) {
			len = (0.5 - length(v_texcoord.xy - vec2(0.5))) * 3.0;
		} else if(v_texcoord.x > u_length-0.5) {
			len = (0.5 - length(v_texcoord.xy - vec2(u_length-0.5,0.5))) * 3.0;
		} else {
			len = (0.5 - abs(v_texcoord.y - 0.5)) * 3.0;
		}
		float d = len;
		gl_FragColor = vec4(vec3(d),len) * u_color;
	}
)";
static const char program_image_vertex[] = R"(
	#ifdef GL_ES
	precision mediump float;
	#endif
	attribute vec4 a_position;
	attribute vec2 a_texcoord;
	varying vec2 v_texcoord;
	void main()
	{
	    gl_Position = a_position * vec4(1.0, 16.0/ 9.0, 1.0, 1.0);
		v_texcoord = a_texcoord;
	}
)";
static const char program_image_fragment[] = R"( 
	#ifdef GL_ES
	precision mediump float;
	#endif
	varying vec2 v_texcoord;
	uniform sampler2D u_sampler;
	uniform float u_time;
	void main()
	{
		vec4 color = texture2D(u_sampler, v_texcoord);
		color.rgb = color.rgb * color.a;
		gl_FragColor = color;
	}
)";

const char *gl_error_to_string(GLenum err) {
	switch(err) {
	case GL_INVALID_ENUM: return "GL_INVALID_ENUM";
	case GL_INVALID_VALUE: return "GL_INVALID_VALUE";
	case GL_INVALID_OPERATION: return "GL_INVALID_OPERATION";
	case GL_INVALID_FRAMEBUFFER_OPERATION: return "GL_INVALID_FRAMEBUFFER_OPERATION";
	case GL_OUT_OF_MEMORY: return "GL_OUT_OF_MEMORY";
	case GL_STACK_UNDERFLOW: return "GL_STACK_UNDERFLOW";
	case GL_STACK_OVERFLOW: return "GL_STACK_OVERFLOW";
	default: return "<Unknown error>";
	};
}

#define GL(stmt) do { stmt; GLenum err = glGetError(); if(err != GL_NO_ERROR) { printf("%d: %s\n", __LINE__, gl_error_to_string(err));  } } while(0);

static void load_program(u8 prog_idx, const char*vertex_src, const char*fragment_src)
{
	Program prg = { 0 };

	GL(prg.id = glCreateProgram());
	GL(prg.vertex = glCreateShader(GL_VERTEX_SHADER));
	GL(prg.fragment = glCreateShader(GL_FRAGMENT_SHADER));

	GL(glShaderSource(prg.vertex, 1, &vertex_src, NULL));
	GL(glCompileShader(prg.vertex));

	GLint compile_status;
	glGetShaderiv(prg.vertex, GL_COMPILE_STATUS, &compile_status);
	if(compile_status != GL_TRUE) {
		char buf[16384];
		glGetShaderInfoLog(prg.vertex, 16384, NULL, buf);
		printf("Program: %u\n", prog_idx);
		puts("compile_status != GL_TRUE");
		puts(buf);
		return;
	}

	GL(glShaderSource(prg.fragment, 1, &fragment_src, NULL));
	GL(glCompileShader(prg.fragment));

	glGetShaderiv(prg.fragment, GL_COMPILE_STATUS, &compile_status);
	if(compile_status != GL_TRUE) {
		char buf[16384];
		glGetShaderInfoLog(prg.fragment, 16384, NULL, buf);
		printf("Program: %u\n", prog_idx);
		puts("compile_status != GL_TRUE");
		puts(buf);
		return;
	}

	GL(glAttachShader(prg.id, prg.vertex));
	GL(glAttachShader(prg.id, prg.fragment));
	GL(glLinkProgram(prg.id));

	GLint link_status;
	glGetProgramiv(prg.id, GL_LINK_STATUS, &link_status);
	if(link_status != GL_TRUE) {
		char buf[16384];
		glGetProgramInfoLog(prg.id, 16384, NULL, buf);
		puts("link_status != GL_TRUE");
		puts(buf);
		return;
	}

	/* Unload previously loaded program before saving this program */
	if(render_state->programs[prog_idx].initialized) {
		glDeleteShader(render_state->programs[prog_idx].fragment);
		glDeleteShader(render_state->programs[prog_idx].vertex);
		glDeleteProgram(render_state->programs[prog_idx].id);
	}
	prg.initialized = true;
	render_state->programs[prog_idx] = prg;
}

static void render_bind_program(u8 program_id);
static void flush_image_program()
{
	if(render_state->imageprogram.data_count > 0) {
		render_bind_program(PROGRAM_IMAGE);
		GL(glBufferData(GL_ARRAY_BUFFER,
						render_state->imageprogram.data_count * sizeof(Vec4),
						render_state->imageprogram.data, GL_DYNAMIC_DRAW));
		GL(glVertexAttribPointer(render_state->imageprogram.a_position_id, 2, GL_FLOAT, GL_FALSE,
								 sizeof(Vec4),
								 NULL));
		GL(glVertexAttribPointer(render_state->imageprogram.a_texcoord_id, 2, GL_FLOAT, GL_FALSE,
								 sizeof(Vec4),
								 (void*)sizeof(Vec2)));
		GL(glUniform1i(render_state->imageprogram.u_sampler_id, 0));
		GL(glUniform1f(render_state->imageprogram.u_time_id, 0.0f));
		GL(glDrawArrays(GL_TRIANGLES, 0, render_state->imageprogram.data_count));
		render_state->imageprogram.data_count = 0;
	}
}

static void render_bind_program(u8 program_id)
{
	if(render_state->bound_program != program_id) {
		if(!render_state->programs[program_id].initialized) {
			puts("cannot bind uninitialized program");
			exit(1);
		}

		if(render_state->bound_program == PROGRAM_IMAGE) {
			flush_image_program();
			GL(glDisableVertexAttribArray(render_state->imageprogram.a_position_id));
			GL(glDisableVertexAttribArray(render_state->imageprogram.a_texcoord_id));
		}

		GL(glUseProgram(render_state->programs[program_id].id));

		if(program_id == PROGRAM_IMAGE) {
			GL(glEnableVertexAttribArray(render_state->imageprogram.a_position_id));
			GL(glEnableVertexAttribArray(render_state->imageprogram.a_texcoord_id));
		}
		render_state->bound_program = program_id;
	}
}

static void render_bind_texture(GLuint texture)
{
	if(render_state->bound_texture != texture) {
		flush_image_program();
		glBindTexture(GL_TEXTURE_2D, texture);
	}
	render_state->bound_texture = texture;
}

static void render_item(DrawItem *item)
{
	switch(item->type) {
	case DRAW_FLUSH: {
		flush_image_program();
		break;
	}
	case DRAW_CLEAR: {
		glClearColor(((item->clear.color & 0x00FF0000) >> 16) / 255.0f,
					 ((item->clear.color & 0x0000FF00) >> 8) / 255.0f,
					 ((item->clear.color & 0x000000ff)) / 255.0f,
					 0.0f);
		glClear(GL_COLOR_BUFFER_BIT);
		break;
	}
	case DRAW_LASER: {
		render_bind_program(PROGRAM_LASER);
		Vec4 data[6];

		Vec2 start = item->laser.start;
		Vec2 end = item->laser.end;
		Vec2 dir = end - start;
		float len = vec_length(dir);
		dir = vec_normalize(dir) * item->laser.width;

		Vec2 normal = vec_perp(dir);

		float uw = (len + item->laser.width * 2.0f) / (item->laser.width * 2.0f);

		GL(glUniform1f(glGetUniformLocation(render_state->programs[PROGRAM_LASER].id, "u_length"), uw));
		GL(glUniform4f(glGetUniformLocation(render_state->programs[PROGRAM_LASER].id, "u_color"),
					   item->laser.color.r,
					   item->laser.color.g,
					   item->laser.color.b,
					   item->laser.color.a));
		
		data[0].xy = start - normal - dir;
		data[0].uv = {0.0f, 0.0f};
		data[1].xy = end - normal + dir;
		data[1].uv = {uw, 0.0f};
		data[2].xy = start + normal - dir;
		data[2].uv = {0.0f, 1.0f};

		
		data[3].xy = end - normal + dir;
		data[3].uv = {uw, 0.0f};
		data[4].xy = start + normal - dir;
		data[4].uv = {0.0f, 1.0f};
		data[5].xy = end + normal + dir;
		data[5].uv = {uw, 1.0f};

		GL(glEnableVertexAttribArray(glGetAttribLocation(render_state->programs[PROGRAM_LASER].id, "a_position")));
		GL(glEnableVertexAttribArray(glGetAttribLocation(render_state->programs[PROGRAM_LASER].id, "a_texcoord")));
		GL(glBufferData(GL_ARRAY_BUFFER, sizeof(data), data, GL_DYNAMIC_DRAW));
		GL(glVertexAttribPointer(glGetAttribLocation(render_state->programs[PROGRAM_LASER].id, "a_position"),
								 2, GL_FLOAT, GL_FALSE, sizeof(data[0]), NULL));
		GL(glVertexAttribPointer(glGetAttribLocation(render_state->programs[PROGRAM_LASER].id, "a_texcoord"),
								 2, GL_FLOAT, GL_FALSE, sizeof(data[0]), (void*)sizeof(data[0].xy)));
		GL(glDrawArrays(GL_TRIANGLES, 0, 6));
		GL(glDisableVertexAttribArray(glGetAttribLocation(render_state->programs[PROGRAM_LASER].id, "a_position")));
		GL(glDisableVertexAttribArray(glGetAttribLocation(render_state->programs[PROGRAM_LASER].id, "a_texcoord")));
		break;
	}
	case DRAW_LINE_STRIP: {
		render_bind_program(PROGRAM_LINES);
		GL(glUniform4f(glGetUniformLocation(render_state->programs[PROGRAM_LINES].id, "u_color"),
					   item->lines.color.r,
					   item->lines.color.g,
					   item->lines.color.b,
					   item->lines.color.a));
		GL(glBufferData(GL_ARRAY_BUFFER, item->lines.count*2*sizeof(GLfloat), item->lines.pts, GL_DYNAMIC_DRAW));
		GL(glEnableVertexAttribArray(glGetAttribLocation(render_state->programs[PROGRAM_LINES].id, "a_position")));
		GL(glVertexAttribPointer(glGetAttribLocation(render_state->programs[PROGRAM_LINES].id, "a_position"),
								 2, GL_FLOAT, GL_FALSE, 0, NULL));
		GL(glDrawArrays(GL_LINE_STRIP, 0, item->lines.count));
		GL(glDisableVertexAttribArray(glGetAttribLocation(render_state->programs[PROGRAM_LINES].id, "a_position")));
		break;
	}
	case DRAW_LINE_LIST: {
		render_bind_program(PROGRAM_LINES);
		GLint attribLocation;
		GL(glUniform4f(glGetUniformLocation(render_state->programs[PROGRAM_LINES].id, "u_color"),
					   item->lines.color.r,
					   item->lines.color.g,
					   item->lines.color.b,
					   item->lines.color.a));
		GL(glEnableVertexAttribArray(glGetAttribLocation(render_state->programs[PROGRAM_LINES].id, "a_position")));
		GL(attribLocation = glGetAttribLocation(render_state->programs[PROGRAM_LINES].id, "a_position"));

		GL(glBufferData(GL_ARRAY_BUFFER, item->lines.count*2*sizeof(GLfloat), item->lines.pts, GL_DYNAMIC_DRAW));
		GL(glVertexAttribPointer(attribLocation, 2, GL_FLOAT, GL_FALSE, 0, NULL));
		GL(glDrawArrays(GL_LINES, 0, item->lines.count));
		GL(glDisableVertexAttribArray(glGetAttribLocation(render_state->programs[PROGRAM_LINES].id, "a_position")));
		break;
	}
	case DRAW_IMAGE: {
		render_bind_program(PROGRAM_IMAGE);
		render_bind_texture(render_state->textures[item->image.tex]);
		if(render_state->imageprogram.data_count + 6 > ArrayCount(render_state->imageprogram.data)) {
			flush_image_program();
		}

		Vec4 * data = &render_state->imageprogram.data[render_state->imageprogram.data_count];
		render_state->imageprogram.data_count += 6;
		data[0].xy = item->image.corners[0];
		data[0].uv = { 0.0f, 1.0f };
		data[1].xy = item->image.corners[1];
		data[1].uv = { 1.0f, 1.0f };
		data[2].xy = item->image.corners[3];
		data[2].uv = { 0.0f, 0.0f };

		data[3].xy = item->image.corners[2];
		data[3].uv = { 1.0f, 0.0f };
		data[4].xy = item->image.corners[1];
		data[4].uv = { 1.0f, 1.0f };
		data[5].xy = item->image.corners[3];
		data[5].uv = { 0.0f, 0.0f };

		break;
	}
	case DRAW_LOAD_IMAGE: {
		GL(glBindTexture(GL_TEXTURE_2D, render_state->textures[item->load_image.tex]));
		GL(glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA,
						item->load_image.image->width, item->load_image.image->height,
						0, GL_RGBA, GL_UNSIGNED_BYTE, item->load_image.image->data));
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
		break;
	}
	}
}

void platform_render(DrawItem *item, int n)
{
	for(int i = 0; i < n; ++i, ++item) {
		render_item(item);
	}
}

void renderer_init(void *state, int width, int height) {
	render_state = (RenderState*)state;
	if(!render_state->initialized) {
		GL(glGenBuffers(1, &render_state->dynamic_buffer));
		GL(glBindBuffer(GL_ARRAY_BUFFER, render_state->dynamic_buffer));
		GL(glGenTextures(TEXTURE_MAX, render_state->textures));
		render_state->initialized = true;
	}

	/* Set viewport with correct aspect ratio */
	{
		double aspect_ratio = 16.0 / 9.0;
		int corrected_width = width;
		int corrected_height = height;
		int padding_bottom = 0;
		int padding_left = 0;
		if(width / (double)height < aspect_ratio) {
			corrected_height = (int)(width / aspect_ratio);
			padding_bottom = (height - corrected_height) / 2;
		} else {
			corrected_width = (int)(height * aspect_ratio);
			padding_left = (width - corrected_width) / 2;
		}
		GL(glViewport(padding_left, padding_bottom, corrected_width, corrected_height));
	}

	GL(glEnable(GL_BLEND));
	GL(glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA));
	load_program(PROGRAM_LINES, program_lines_vertex, program_lines_fragment);
	load_program(PROGRAM_LASER, program_laser_vertex, program_laser_fragment);
	load_program(PROGRAM_IMAGE, program_image_vertex, program_image_fragment);
	render_state->imageprogram.a_position_id = glGetAttribLocation(render_state->programs[PROGRAM_IMAGE].id, "a_position");
	render_state->imageprogram.a_texcoord_id = glGetAttribLocation(render_state->programs[PROGRAM_IMAGE].id, "a_texcoord");
	render_state->imageprogram.u_time_id = glGetUniformLocation(render_state->programs[PROGRAM_IMAGE].id, "u_time");
	render_state->imageprogram.u_sampler_id = glGetUniformLocation(render_state->programs[PROGRAM_IMAGE].id, "u_sampler");
	
	render_state->bound_program = PROGRAM_NONE;
	render_state->bound_texture = 0;
}
