#include <emscripten.h>
#include <html5.h>
#include <time.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <AL/al.h>
#include <AL/alc.h>
#include <limits.h>

#include "game.h"
#include "renderer.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include "loadwav.h"

static Image create_stub_image() {
	Image image;
	image.width = 64;
	image.height = 64;
	image.data = (u32*)malloc(sizeof(u32) * image.width * image.height);

	struct {
		u8 r, g, b, a;
	} * data;
	data = (decltype(data))image.data;

	for(u32 y = 0; y < image.height; ++y) {
		for(u32 x = 0; x < image.width; ++x) {
			float nx = x / 64.0f;
			float ny = y / 64.0f;
			u8 v = ((x ^ y) % 64) * 4;
			data->r = (u8)(v * sqrtf(nx*nx+ny*ny) / sqrtf(2.0f));
			data->g = (u8)(v * sqrtf((1.0f-nx)*(1.0f-nx)+ny*ny) / sqrtf(2.0f));
			data->b = (u8)(v * sqrtf(ny*ny+(1.0f-ny)*(1.0f-ny)) / sqrtf(2.0f));
			data->a = 0xff;
			++data;
		}
	}
	return image;
}

Image load_image(const char *name) {

	int x, y, n;
	unsigned char *data = stbi_load(name, &x, &y, &n, 4);
	if(!data) {
		fprintf(stderr, "Failed to load image: '%s'\n", name);
		fprintf(stderr, "   reason: %s\n", stbi_failure_reason());
		return create_stub_image();
	}

	Image image = { 0 };
	image.width = (u32)x;
	image.height = (u32)y;
	image.data = (u32*)data;
	return image;
}



static AudioChunk load_audio(const char *name) {

	FILE *file = fopen(name, "r");
	if(file) {
		wav_header_t *hdr = wav_load(file);
		fclose(file);
		if(hdr) {
			AudioChunk chunk = { 0 };
			chunk.sample_count = hdr->data_subchunk_size / sizeof(i16);
			chunk.samples = (Sample*)hdr->data;
			return chunk;
		}
	}	

	fprintf(stderr, "Failed to load audio: '%s'\n", name);

	AudioChunk chunk = { 0 };
	chunk.sample_count = 0;
	chunk.samples = NULL;
	return chunk;
}

struct PlayingChunk {
	u32 sample_index;
	AudioChunk *chunk;
};

static PlayingChunk playing_chunks[16] = { 0 };

struct sdl_stereo_sample {
	i16 left, right;
};

static void audio_mix_func(void *udata, u8 *stream, int len)
{
	struct { i32 left, right; } mix_buffer[len];
	sdl_stereo_sample *out_buffer = (sdl_stereo_sample*)stream;
	u32 stereo_sample_size = 2 * sizeof(i16);
	u32 samples_in_stream = len / stereo_sample_size;

	memset(mix_buffer, 0, samples_in_stream * sizeof(i32) * 2);
	memset(stream, 0, len);

	for(size_t i = 0; i < sizeof(playing_chunks) / sizeof(playing_chunks[0]); i++) {
		u32 sample_index = playing_chunks[i].sample_index;
		AudioChunk *chunk = playing_chunks[i].chunk;
		if(!chunk) {
			break;
		}

		u32 remaining_samples = chunk->sample_count - sample_index;
		u32 samples_to_copy = remaining_samples;

		if(samples_to_copy > samples_in_stream) {
			samples_to_copy = samples_in_stream;
		}
		playing_chunks[i].sample_index += samples_to_copy;

		for(u32 k = 0; k < samples_to_copy; k++)
		{
			mix_buffer[k].left += chunk->samples[sample_index + k].center;
			mix_buffer[k].right += chunk->samples[sample_index + k].center;
		}

		if(samples_to_copy == remaining_samples) {
			for(size_t j = i; j < sizeof(playing_chunks) / sizeof(playing_chunks[0]); j++) {
				if(j+1 == sizeof(playing_chunks) / sizeof(playing_chunks[0])) {
					playing_chunks[j].chunk = NULL;
				}
				playing_chunks[j] = playing_chunks[j+1];
				if(playing_chunks[j].chunk == NULL) {
					break;
				}
			}
			--i;
		}
	}

	for(u32 i = 0; i < samples_in_stream; ++i) {
		i32 left = mix_buffer[i].left;
		i32 right = mix_buffer[i].right;
		out_buffer[i].left = (left > SHRT_MAX) ? SHRT_MAX : (left < SHRT_MIN) ? SHRT_MIN : left;
		out_buffer[i].right = (right > SHRT_MAX) ? SHRT_MAX : (right < SHRT_MIN) ? SHRT_MIN : right;
	}
}

static ALuint source;
static ALuint buffer;
static void audio_play_chunk(AudioChunk*chunk)
{
	if(chunk->sample_count == 0 || chunk->samples == 0) {
		puts("Not playing audio chunk: no samples");
		return;
	}

	alBufferData(buffer, AL_FORMAT_MONO16, chunk->samples, sizeof(i16)*chunk->sample_count, 48000);
	alSourcei(source, AL_BUFFER, buffer);
	alSourcePlay(source);
}





static double get_seconds() {
	struct timespec res;
	clock_gettime(CLOCK_MONOTONIC, &res);
	return res.tv_sec + (double)res.tv_nsec/1e9;
}

#define GAME_MEMORY_SIZE (8*1024*1024)
#define RENDER_MEMORY_SIZE (2*1024*1024)

static GameInput input;
static void *game_memory;
static void *render_state;
static Platform platform;
static double start_time;
static bool first_iteration = true;

static int video_width = 960;
static int video_height = 540;
static void game_iteration()
{
	if(first_iteration) {
		start_time = get_seconds() - (1.0 / 60.0);
		first_iteration = false;
	}


	/* Check if the surface size has changed Do this because SDL_VIDEORESIZE event is bugged */
	EmscriptenFullscreenChangeEvent status;
	int real_width, real_height, fs;
	emscripten_get_fullscreen_status(&status);
	if(status.isFullscreen) {
		real_width = status.screenWidth;
		real_height = status.screenHeight;
	} else {
		emscripten_get_canvas_size(&real_width, &real_height, &fs);
	}
	if(real_width != video_width || real_height != video_height) {
		renderer_init(render_state, real_width, real_height);
		video_width = real_width;
		video_height = real_height;
	}
	

	Key * key = (Key*)&input.keys;
	for(u32 i = 0; i < sizeof(input.keys) / sizeof(Key); i++) {
		key->transitions = 0;
		key++;
	}
	key = (Key*)&input.debug_keys;
	for(u32 i = 0; i < sizeof(input.debug_keys) / sizeof(Key); i++) {
		key->transitions = 0;
		key++;
	}

#define HANDLE_KEY(sdl_suffix, input_field) case SDLK_ ## sdl_suffix : { \
	if(input.input_field.pressed && event.type == SDL_KEYUP) { \
		input.input_field.pressed = false; \
		input.input_field.transitions++; \
	} else if(!input.input_field.pressed && event.type == SDL_KEYDOWN) { \
		input.input_field.pressed = true; \
		input.input_field.transitions++; \
	} \
}
	/* Handle SDL events */
	SDL_Event event;
	while(SDL_PollEvent(&event)) {
		switch(event.type) {
		// case SDL_VIDEORESIZE: {
		// 	SDL_Surface *video_surface = SDL_GetVideoSurface();
		// 	renderer_init(render_state, video_surface->w, video_surface->h);
		// 	printf("%.4f: SDL_VIDEORESIZE: %d, %d\n", get_seconds(), video_surface->w, video_surface->h);
		// 	break;
			// }
		case SDL_KEYUP:
		case SDL_KEYDOWN: {
			if(event.key.repeat) break;
			switch(event.key.keysym.sym) {
				HANDLE_KEY(ESCAPE, keys.escape); break;
				HANDLE_KEY(LEFT, keys.left); break;
				HANDLE_KEY(DOWN, keys.down); break;
				HANDLE_KEY(RIGHT, keys.right); break;
				HANDLE_KEY(UP, keys.up); break;
				HANDLE_KEY(x, keys.attack); break;
				HANDLE_KEY(z, keys.jump); break;
				HANDLE_KEY(s, keys.activate_a); break;
				HANDLE_KEY(a, keys.activate_b); break;
				HANDLE_KEY(F1, debug_keys.F1); break;
				HANDLE_KEY(F2, debug_keys.F2); break;
				HANDLE_KEY(F3, debug_keys.F3); break;
				HANDLE_KEY(F4, debug_keys.F4); break;
				HANDLE_KEY(F5, debug_keys.F5); break;
				HANDLE_KEY(F6, debug_keys.F6); break;
				HANDLE_KEY(F7, debug_keys.F7); break;
				HANDLE_KEY(F8, debug_keys.F8); break;
				HANDLE_KEY(F9, debug_keys.F9); break;
				HANDLE_KEY(F10, debug_keys.F10); break;
				HANDLE_KEY(F11, debug_keys.F11); break;
				HANDLE_KEY(F12, debug_keys.F12); break;
			default: break;
			}
			break;
		}
		default: {
			break;
		}
		}
	}

	double current_time = get_seconds();
	double delta_time = current_time - start_time;
	start_time = current_time;
	game_logic_and_render(game_memory, GAME_MEMORY_SIZE, 1.0 / 60.0, &input, &platform);

	SDL_GL_SwapBuffers();
}

static int on_button_click(int eventType, const EmscriptenMouseEvent *mouseEvent, void *user_data) {

	EmscriptenFullscreenStrategy s = { 0 };
	s.scaleMode = EMSCRIPTEN_FULLSCREEN_SCALE_DEFAULT;
	s.canvasResolutionScaleMode = EMSCRIPTEN_FULLSCREEN_CANVAS_SCALE_HIDEF;
	s.filteringMode = EMSCRIPTEN_FULLSCREEN_FILTERING_DEFAULT;
	emscripten_request_fullscreen_strategy(0, 1, &s);

	return 0;
}

int main(int argc, char *argv[])
{
	/* Initialize SDL */
	SDL_Init(SDL_INIT_VIDEO);
	SDL_GL_SetAttribute(SDL_GL_RED_SIZE     , 5);
	SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE   , 5);
	SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE    , 5);
	SDL_GL_SetAttribute(SDL_GL_ALPHA_SIZE   , 5);
	SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE   , 16);
	SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER , 1);
	SDL_Surface *video_surface = SDL_SetVideoMode(video_width, video_height, 24, SDL_OPENGL | SDL_HWSURFACE | SDL_RESIZABLE);

	/* Initialize Audio */
	ALCdevice *device = alcOpenDevice(NULL);
	if(device) {
		ALCcontext *context = alcCreateContext(device, NULL);
		if(context) {
			alcMakeContextCurrent(context);
		} else {
			puts("No AL context");
		}
	} else {
		puts("No AL device");
	}

	alGenSources((ALuint)1, &source);
	alGenBuffers((ALuint)1, &buffer);

	/* Initialize OpenGL */
	render_state = calloc(1, RENDER_MEMORY_SIZE);
	renderer_init(render_state, video_surface->w, video_surface->h);

	/* Allocate memory for the game state */
	input = { };
	game_memory = calloc(1, GAME_MEMORY_SIZE);
	platform.platform_render = platform_render;
	platform.load_image = load_image;
	platform.load_audio = load_audio;
	platform.platform_play = audio_play_chunk;
	

	/* Register emscripten callback */
	emscripten_set_click_callback("button_fullscreen", 0, 1, on_button_click);

	/* Register main loop */
	emscripten_set_main_loop(game_iteration, 0, 1);

	return 0;

}
