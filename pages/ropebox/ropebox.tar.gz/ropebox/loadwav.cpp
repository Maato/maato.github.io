#include <stdlib.h>
#include <assert.h>

#include "loadwav.h"
#include "dbg.h"

static const char RIFF[4] = { 'R', 'I', 'F', 'F' };
static const char WAVE[4] = { 'W', 'A', 'V', 'E' };
static const char FMT[4]  = { 'f', 'm', 't', ' ' };
static const char DATA[4] = { 'd', 'a', 't', 'a' };

#define AUDIO_FORMAT_PCM 1

wav_header_t* wav_load(FILE *file)
{
	wav_header_t *wav_hdr = NULL;

	assert(file != NULL);

	/* Get file size */
	size_t oldPos = ftell(file);
	fseek(file, 0, SEEK_END);
	size_t length = ftell(file);
	fseek(file, oldPos, SEEK_SET);

	/* Make sure the file contains a complete header */
	check(length >= sizeof(wav_header_t),
	      "File is too small to contain a valid WAVE header!\n");

	/* Allocate memory for the header and read into it */
	wav_hdr = (wav_header_t*)malloc(length);
	fread(wav_hdr, length, 1, file);

	/* Perform file integrity checks */
	check(memcmp(RIFF, wav_hdr->chunk_id, 4) == 0,
	      "Invalid chunk descriptor '%.4s' where 'RIFF' was expected!\n",
	      wav_hdr->chunk_id);

	check(wav_hdr->chunk_size + 8 == (int)length,
	      "Invalid chunk_size '%d' where '%zd' was expected!\n",
	      wav_hdr->chunk_size, length - 8);

	check(memcmp(WAVE, wav_hdr->format, 4) == 0,
	      "Invalid format '%.4s' where 'WAVE' was expected!\n",
	      wav_hdr->format);

	check(memcmp(FMT, wav_hdr->fmt_subchunk_id, 4) == 0,
	      "Invalid subchunk id '%.4s' where 'fmt ' was expected!\n",
	      wav_hdr->fmt_subchunk_id);
	
	check(wav_hdr->fmt_subchunk_size == 16,
	      "Invalid subchunk size '%d' where '16' was expected, "
	      "this file might not contain PCM encoded data!\n",
	      wav_hdr->fmt_subchunk_size);

	check(wav_hdr->audio_format == AUDIO_FORMAT_PCM,
	      "Invalid audio format '%d' only '1 (PCM)' is supported!\n",
	      wav_hdr->audio_format);
	
	check(memcmp(DATA, wav_hdr->data_subchunk_id, 4) == 0,
	      "Invalid subchunk id '%.4s' where 'data' was expected!\n",
	      wav_hdr->data_subchunk_id);

	check(wav_hdr->data_subchunk_size == (int)(length - sizeof(wav_header_t)),
	      "Invalid subchunk size '%d' where '%zd' was expected!\n",
	      wav_hdr->data_subchunk_size, length - 44);

	return wav_hdr;
error:
	free(wav_hdr);
	return NULL;
}

void wav_destroy(wav_header_t *wav_hdr)
{
	free(wav_hdr);
}
