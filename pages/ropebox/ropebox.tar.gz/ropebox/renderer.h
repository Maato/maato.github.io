#ifndef RENDERER_H
#define RENDERER_H

#include "game.h"

extern "C" {
	void platform_render(DrawItem *item, int n);
	void renderer_init(void*state, int width, int height);
}

#endif
