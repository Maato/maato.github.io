#!/bin/bash

if [ "$1" = "emscripten" ]; then
	em++ -Wall \
		 -std=c++11 \
		 -O3 \
		 -lGL -lSDL \
		 -o emscripten_main.bc \
		 -Wno-missing-braces \
		 -Wno-unused-function \
		 game.cpp \
		 webgl_renderer.cpp \
		 loadwav.cpp \
		 emscripten_main.cpp

	em++ emscripten_main.bc \
		 -O3 \
		 --preload-file data/ \
		 -s TOTAL_MEMORY=67108864 \
		 -o emscripten.html
		 #-s ASSERTIONS=1 \

	echo "file://$(pwd)/index.html"
	
else
	DISABLE_WARNINGS="-Wno-unused-function -Wno-unused-variable -Wno-unused-but-set-variable"
	g++ -shared -rdynamic \
		-g \
		-fPIC \
		-O3 \
		-std=c++11 \
		-nodefaultlibs \
		-nostartfiles \
		$DISABLE_WARNINGS \
		-o game.so \
		game.cpp

	g++ -shared -rdynamic \
		-g \
		-fPIC \
		-O3 \
		-std=c++11 \
		-nodefaultlibs \
		-nostartfiles \
		$DISABLE_WARNINGS \
		-o renderer_webgl.so \
		webgl_renderer.cpp

	touch reload.signal

	g++ -Wall \
		-g \
		-std=c++11 \
		-O3 \
		-lSDL2 -lGL -ldl \
		$DISABLE_WARNINGS \
		-Wl,-rpath,'$ORIGIN/' \
		-o linux_main \
		loadwav.cpp \
		linux_main.cpp 
fi
