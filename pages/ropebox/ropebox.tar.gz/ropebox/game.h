#ifndef GAME_H
#define GAME_H

#include <math.h>

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long int u64;
typedef char i8;
typedef short i16;
typedef int i32;
typedef long int i64;

enum Texture {
	TEXTURE_TEST            = 0,
	TEXTURE_TILE_01         = 1,
	TEXTURE_HEART           = 2,
	TEXTURE_HEART_CONTAINER = 3,
	TEXTURE_WALKER          = 4,
	TEXTURE_MAX             = 32
};

#define ArrayCount(A) (sizeof(ArraySizeHelper(A)))
template <typename T, u32 N>
	char (&ArraySizeHelper(T (&a)[N]))[N];

enum DrawType {
	DRAW_CLEAR,
	DRAW_FLUSH,
	DRAW_LOAD_IMAGE,
	DRAW_LINE_STRIP,
	DRAW_LINE_LIST,
	DRAW_LASER,
	DRAW_IMAGE
};

struct Vec2 {
	float x, y;
	
	inline Vec2 operator*(const Vec2 &rhs) const  { return { x*rhs.x, y*rhs.y}; }
	inline Vec2 operator*(float rhs) const        { return { x*rhs, y*rhs}; }
	inline void operator*=(const Vec2 &rhs)       { x *= rhs.x; y *= rhs.y; }
	inline void operator*=(float rhs)             { x *= rhs; y *= rhs; }

	inline Vec2 operator/(const Vec2 &rhs) const  { return { x/rhs.x, y/rhs.y}; }
	inline Vec2 operator/(float rhs) const        { return { x/rhs, y/rhs}; }
	inline void operator/=(const Vec2 &rhs)       { x /= rhs.x; y /= rhs.y; }
	inline void operator/=(float rhs)             { x /= rhs; y /= rhs; }

	inline Vec2 operator+(const Vec2 &rhs) const  { return { x+rhs.x, y+rhs.y }; }
	inline void operator+=(const Vec2 &rhs)       { x += rhs.x; y += rhs.y; }

	inline Vec2 operator-(const Vec2 &rhs) const  { return { x-rhs.x, y-rhs.y }; }
	inline void operator-=(const Vec2 &rhs)       { x -= rhs.x; y -= rhs.y; }

	inline bool operator==(const Vec2 &rhs) const { return x == rhs.x && y == rhs.y; }
	inline bool operator!=(const Vec2 &rhs) const { return x != rhs.x || y != rhs.y; }
};

inline Vec2 vec_normalize(Vec2 v) {
	float len = sqrtf(v.x*v.x + v.y*v.y);
	if(len > 0.0f) {
		return { v.x / len, v.y / len };
	} else {
		return { 0 };
	}
}
inline Vec2 vec_perp(Vec2 v) { return { -v.y, v.x }; }
inline float vec_length(Vec2 v) { return sqrtf(v.x*v.x + v.y*v.y); } 
inline float vec_dot_product(Vec2 a, Vec2 b) { return a.x * b.x + a.y * b.y; }
inline float vec_cross_product(Vec2 a, Vec2 b) { return a.x * b.y - a.y * b.x; }


struct Vec3 {
	union {
		struct { float r, g, b; };
		struct { float x, y, z; };
		struct { Vec2 xy; float _z; };
		struct { float _x; Vec2 yz; };
	};
};

struct Vec4 {
	union {
		struct { float x, y, u, v; };
		struct { float r, g, b, a; };
		struct { Vec2 xy; Vec2 uv; };
		struct { Vec3 xyz; float _u; };
		struct { Vec3 rgb; float _a; };
	};
};

#define RGB(r,g,b)    (Vec4{ r / 255.0f, g / 255.0f, b / 255.0f, 1.0f})
#define RGBA(r,g,b,a) (Vec4{ r / 255.0f, g / 255.0f, b / 255.0f, a / 255.0f})

struct Sample {
	i16 center;
};
struct AudioChunk {
	u32 sample_count;
	Sample * samples;
};

struct Image {
	u32 width;
	u32 height;
	u32 *data;
};

struct Arena {
	u64 used;
	u64 size;
	u8 *data;
};

#define arena_push_struct(arena, struct_type) ((struct_type*)arena_push_size(arena, sizeof(struct_type)))
#define arena_push_array(arena, elem_type, elem_count) ((elem_type*)arena_push_size(arena, sizeof(elem_type)*elem_count))
inline u8 *arena_push_size(Arena *arena, u64 requested_size) {
	requested_size = (requested_size + 7) & (~7); /* round up to multiple of 8 */
	if(arena->size - arena->used > requested_size) {
		u8 *result = arena->data + arena->used;
		arena->used += requested_size;
		return result;
	}
	return 0;
}

struct DrawItem {
	u8 type;
	union {
		struct {
			u32 color;
		} clear;
		struct {
			Vec4 color;
			u32 count;
			Vec2 *pts;
		} lines;
		struct {
			Vec2 start;
			Vec2 end;
			float width;
			Vec4 color;
		} laser;
		struct {
			Vec2 corners[4];
			Texture tex;
			float time;
		} image;
		struct {
			Image *image;
			Texture tex;
		} load_image;
	};
};

struct Key {
	bool pressed;
	int transitions;
};
struct GameInput {
	struct Keys {
		Key left;
		Key right;
		Key up;
		Key down;
		Key jump;
		Key attack;
		Key activate_a;
		Key activate_b;
		Key escape;
	} keys;
	struct DebugKeys {
		Key F1, F2, F3, F4, F5, F6, F7, F8, F9, F10, F11, F12;
	} debug_keys;
};


#define CHUNK_DIAMETER 16
#define TILE_DIAMETER (1.0f)
struct WorldChunk {
	i32 x, y;
	u16 tiles[CHUNK_DIAMETER * CHUNK_DIAMETER];
};


enum ObjectType {
	OBJECT_NONE,
	OBJECT_Player,
	OBJECT_WallRope,
	OBJECT_RopeBox,
	OBJECT_Heart,
	OBJECT_Walker
};

struct PhysicalObject {
	Vec2 old_position;
	Vec2 position;
	Vec2 velocity;
	Vec2 size;
};

struct StationaryObject {
	Vec2 position;
	Vec2 size;
};

struct WallRope {
	enum ObjectType type;
	StationaryObject body;
};

struct RopeBox {
	enum ObjectType type;
	PhysicalObject body;
	bool held;
};

struct Heart {
	enum ObjectType type;
	PhysicalObject body;
};

struct Walker {
	enum ObjectType type;
	PhysicalObject body;
	int invuln_timer;
	int health;
};

struct Player {
	enum ObjectType type;
	PhysicalObject body;
	u16 heart_containers;
	u16 hearts;
	Vec2 facing_dir;
	int frames_in_air;
	bool can_extend_jump;
	int air_jumps_remaining;
	bool hanging_from_ledge;
	int invuln_timer;
	RopeBox *ropebox;
	int frames_in_air_with_negative_y_velocity;
};

struct Object {
	union {
		enum ObjectType type;
		Player player;
		WallRope wallrope;
		RopeBox ropebox;
		Heart heart;
		Walker walker;
	};
	Object *next_in_group;   /* Intrusive style link */
	Object *prev_in_group;   /* Intrusive style link */
	Object *next_in_y_group; /* Intrusive style link */
};

enum State {
	STATE_START = 0,
	STATE_PLAYING,
	STATE_DIED,
	STATE_WON
};

struct GameState {
	bool initialized;
	bool reset_level;
	int rseed;
	Vec2 offset;
	Vec2 scale;
	Image image_test;
	Image image_tile_01;
	Image image_heart;
	Image image_heart_container;
	Image image_walker;
	AudioChunk audio_coin;
	AudioChunk audio_pickup_heart;
	AudioChunk audio_jump;
	AudioChunk audio_land;
	Arena master_arena;
	float elapsed_time;
	WorldChunk world[16];
	Player *player;
	State state;
	float state_timer;

	u32 live_objects;
	Object objects[32768];
	Object *object_group_NONE;     /* Doubly Linked List */
	Object *object_group_Player;   /* Doubly Linked List */
	Object *object_group_WallRope; /* Doubly Linked List */
	Object *object_group_RopeBox;  /* Doubly Linked List */
	Object *object_group_Heart;    /* Doubly Linked List */
	Object *object_group_Walker;    /* Doubly Linked List */
};

extern "C" {
	struct Platform {
		void       (*platform_render)(DrawItem*, int n);
		void       (*platform_play)(AudioChunk*);
		Image      (*load_image)(const char *name);
		AudioChunk (*load_audio)(const char *name);
	};
	bool game_logic_and_render(void*game_memory, u64 game_memory_size, double delta_time, GameInput*, Platform*);
}


#endif
