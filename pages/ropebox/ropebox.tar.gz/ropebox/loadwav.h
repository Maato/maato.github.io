#ifndef LOADWAV_H
#define LOADWAV_H

#include <stdio.h>
#include <stdint.h>

typedef struct
{
	/* RIFF chunk descriptor */
	char chunk_id[4];
	int32_t chunk_size;
	char format[4];

	/* fmt sub-chunk */
	char fmt_subchunk_id[4];
	int32_t fmt_subchunk_size;
	int16_t audio_format;
	int16_t num_channels;
	int32_t sample_rate;
	int32_t byte_rate;
	int16_t block_align;
	int16_t bits_per_sample;

	/* data sub-chunk */
	char data_subchunk_id[4];
	int32_t data_subchunk_size;
	char data[];
} wav_header_t;

wav_header_t *wav_load(FILE *file);
void wav_destroy(wav_header_t *wav);

#endif
