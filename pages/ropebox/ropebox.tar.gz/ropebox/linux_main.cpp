#include "game.h"
#include "renderer.h"

#include <SDL2/SDL.h>
#include <dlfcn.h>
#include <time.h>
#include <sys/stat.h>
#include <limits.h>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include "loadwav.h"

static Image create_stub_image() {
	Image image;
	image.width = 64;
	image.height = 64;
	image.data = (u32*)malloc(sizeof(u32) * image.width * image.height);

	struct {
		u8 r, g, b, a;
	} * data;
	data = (decltype(data))image.data;

	for(u32 y = 0; y < image.height; ++y) {
		for(u32 x = 0; x < image.width; ++x) {
			float nx = x / 64.0f;
			float ny = y / 64.0f;
			u8 v = ((x ^ y) % 64) * 4;
			data->r = (u8)(v * sqrtf(nx*nx+ny*ny) / sqrtf(2.0f));
			data->g = (u8)(v * sqrtf((1.0f-nx)*(1.0f-nx)+ny*ny) / sqrtf(2.0f));
			data->b = (u8)(v * sqrtf(ny*ny+(1.0f-ny)*(1.0f-ny)) / sqrtf(2.0f));
			data->a = 0xff;
			++data;
		}
	}
	return image;
}

static Image load_image(const char *name) {

	int x, y, n;
	unsigned char *data = stbi_load(name, &x, &y, &n, 4);
	if(!data) {
		fprintf(stderr, "Failed to load image: '%s'\n", name);
		fprintf(stderr, "   reason: %s\n", stbi_failure_reason());
		return create_stub_image();
	}

	Image image = { 0 };
	image.width = (u32)x;
	image.height = (u32)y;
	image.data = (u32*)data;
	return image;
}

static AudioChunk load_audio(const char *name) {

	FILE *file = fopen(name, "r");
	if(file) {
		wav_header_t *hdr = wav_load(file);
		fclose(file);
		if(hdr) {
			AudioChunk chunk = { 0 };
			chunk.sample_count = hdr->data_subchunk_size / sizeof(i16);
			chunk.samples = (Sample*)hdr->data;
			return chunk;
		}
	}	

	fprintf(stderr, "Failed to load audio: '%s'\n", name);

	AudioChunk chunk = { 0 };
	chunk.sample_count = 0;
	chunk.samples = NULL;
	return chunk;
}

struct PlayingChunk {
	u32 sample_index;
	AudioChunk *chunk;
};

static u32 playing_chunks_count = 0;
static PlayingChunk playing_chunks[16] = { 0 };

struct sdl_stereo_sample {
	i16 left, right;
};

static void audio_mix_func(void *udata, u8 *stream, int len)
{
	struct { i32 left, right; } mix_buffer[len];
	sdl_stereo_sample *out_buffer = (sdl_stereo_sample*)stream;
	u32 stereo_sample_size = 2 * sizeof(i16);
	u32 samples_in_stream = len / stereo_sample_size;

	memset(mix_buffer, 0, samples_in_stream * sizeof(i32) * 2);
	memset(stream, 0, len);

	for(size_t i = 0; i < sizeof(playing_chunks) / sizeof(playing_chunks[0]); i++) {
		u32 sample_index = playing_chunks[i].sample_index;
		AudioChunk *chunk = playing_chunks[i].chunk;
		if(!chunk) {
			break;
		}

		u32 remaining_samples = chunk->sample_count - sample_index;
		u32 samples_to_copy = remaining_samples;

		if(samples_to_copy > samples_in_stream) {
			samples_to_copy = samples_in_stream;
		}
		playing_chunks[i].sample_index += samples_to_copy;

		for(u32 k = 0; k < samples_to_copy; k++)
		{
			mix_buffer[k].left += chunk->samples[sample_index + k].center;
			mix_buffer[k].right += chunk->samples[sample_index + k].center;
		}

		if(samples_to_copy == remaining_samples) {
			for(size_t j = i; j < sizeof(playing_chunks) / sizeof(playing_chunks[0]); j++) {
				if(j+1 == sizeof(playing_chunks) / sizeof(playing_chunks[0])) {
					playing_chunks[j].chunk = NULL;
				}
				playing_chunks[j] = playing_chunks[j+1];
				if(playing_chunks[j].chunk == NULL) {
					break;
				}
			}
			--i;
		}
	}

	for(u32 i = 0; i < samples_in_stream; ++i) {
		i32 left = mix_buffer[i].left;
		i32 right = mix_buffer[i].right;
		out_buffer[i].left = (left > SHRT_MAX) ? SHRT_MAX : (left < SHRT_MIN) ? SHRT_MIN : left;
		out_buffer[i].right = (right > SHRT_MAX) ? SHRT_MAX : (right < SHRT_MIN) ? SHRT_MIN : right;
	}
}

static void audio_init()
{
	SDL_AudioSpec want = { 0 };
	SDL_AudioSpec have = { 0 };

	want.freq = 48000;
	want.format = AUDIO_S16SYS;
	want.channels = 2;
	want.samples = 2048;
	want.callback = audio_mix_func;

	if(SDL_OpenAudio(&want, &have) < 0) {
		fprintf(stderr, "Failed to open audio: %s\n", SDL_GetError());
	} else {
		if(have.format != want.format) {
			fprintf(stderr, "We didn't get i16 audio format.\n");
		}
	}
}

static void audio_play_chunk(AudioChunk*chunk)
{
	if(chunk->sample_count == 0 || chunk->samples == 0) {
		puts("Not playing audio chunk: no samples");
		return;
	}
	for(size_t i = 0; i < sizeof(playing_chunks) / sizeof(playing_chunks[0]); i++) {
		if(playing_chunks[i].chunk == NULL) {
			playing_chunks[i].sample_index = 0;
			playing_chunks[i].chunk = chunk;
			break;
		}
	}
}

/*===================================================================================
 * Reload game.so Library
 ==================================================================================*/
struct GameLibrary {
	void *handle;
	decltype(game_logic_and_render) *logic_and_render;
};
static bool dummy_logic_and_render(void*, u64 game_memory_size, double delta_time, GameInput *input, Platform*) {
	return !input->keys.escape.pressed;
}

static GameLibrary debug_load_game_library()
{
	GameLibrary library = { 0 };
	library.handle = dlopen("game.so", RTLD_NOW);
	if(library.handle) {
		library.logic_and_render = (decltype(game_logic_and_render)*)dlsym(library.handle, "game_logic_and_render");
	} else {
		puts("Failed to load library.");
	}
	if(!library.logic_and_render) {
		library.logic_and_render = dummy_logic_and_render;
	}
	return library;
}

static void debug_close_game_library(GameLibrary *library)
{
	if(library->handle) {
		dlclose(library->handle);
	}
	*library = { 0 };
	library->logic_and_render = dummy_logic_and_render;
}

/*===================================================================================
 * Reload render Library
 ==================================================================================*/
struct RenderLibrary {
	void *handle;
	decltype(renderer_init)   *lib_renderer_init;
	decltype(platform_render) *lib_platform_render;
};
void dummy_renderer_init(void*, int, int) { }
void dummy_platform_render(DrawItem *item, int n) { }

RenderLibrary debug_load_render_library()
{
	RenderLibrary library = { 0 };
	library.handle = dlopen("renderer_webgl.so", RTLD_NOW);
	if(library.handle) {
		library.lib_renderer_init = (decltype(renderer_init)*)dlsym(library.handle, "renderer_init");
		library.lib_platform_render = (decltype(platform_render)*)dlsym(library.handle, "platform_render");
	} else {
		puts("Failed to load library.");
	}
	if(!library.lib_renderer_init) {
		library.lib_renderer_init = dummy_renderer_init;
	}
	if(!library.lib_platform_render) {
		library.lib_platform_render = dummy_platform_render;
	}
	return library;
}

void debug_close_render_library(RenderLibrary *library)
{
	if(library->handle) {
		dlclose(library->handle);
	}
	*library = { 0 };
	library->lib_renderer_init = dummy_renderer_init;
	library->lib_platform_render = dummy_platform_render;
}

static time_t reload_ctime;
bool debug_should_reload_libraries()
{
	struct stat sb = { 0 };
	if(stat("reload.signal", &sb) < 0) {
		return false;
	}
	if(reload_ctime == 0) {
		reload_ctime = sb.st_ctime;
	}
	if(sb.st_ctime != reload_ctime) {
		puts("Reloading libraries");
		reload_ctime = sb.st_ctime;
		return true;
	}
	return false;
}
static struct timespec timespec_diff(timespec start, timespec stop) {
	struct timespec result;
	if(start.tv_nsec > stop.tv_nsec) {
		result.tv_sec = stop.tv_sec - start.tv_sec - 1;
		result.tv_nsec = 1000000000 + stop.tv_nsec -
			start.tv_nsec;
	} else {
		result.tv_sec = stop.tv_sec - start.tv_sec;
		result.tv_nsec = stop.tv_nsec - start.tv_nsec;
	}
	return result;
}  

static struct timespec timespec_add(timespec a, timespec b) { 
	struct timespec result;
	result.tv_sec = a.tv_sec + b.tv_sec;
	result.tv_nsec = a.tv_nsec + b.tv_nsec;
	if(result.tv_nsec >= 1000000000) { 
		result.tv_sec += 1;
		result.tv_nsec -= 1000000000;
	}
	return result;
}

static bool is_timespec_less(struct timespec v, struct timespec c) {
	if(v.tv_sec > c.tv_sec) return false;
	if(v.tv_nsec >= c.tv_nsec) return false;
	return true;
}

static double get_seconds() {
	struct timespec res;
	clock_gettime(CLOCK_MONOTONIC, &res);
	return res.tv_sec + (double)res.tv_nsec/1e9;
}

/*===================================================================================
 * Main
 ==================================================================================*/
#define GAME_MEMORY_SIZE (32*1024*1024)
#define RENDER_MEMORY_SIZE (8*1024*1024)
int main(int argc, char *argv[])
{
	/* Initialize Game Library */
	GameLibrary game_library = debug_load_game_library();
	if(!game_library.handle) {
		puts("Failed to load game library.");
		exit(1);
	}

	/* Initialize Render Library */
	RenderLibrary render_library = debug_load_render_library();
	if(!render_library.handle) {
		puts("Failed to load render library.");
		exit(1);
	}

	printf("u8 :%zu\n", sizeof(u8));
	printf("u16 :%zu\n", sizeof(u16));
	printf("u32 :%zu\n", sizeof(u32));
	printf("u64 :%zu\n", sizeof(u64));
	
	/* Initialize SDL */
	SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);
	SDL_GL_SetAttribute(SDL_GL_RED_SIZE     , 5);
	SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE   , 5);
	SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE    , 5);
	SDL_GL_SetAttribute(SDL_GL_ALPHA_SIZE   , 5);
	SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE   , 16);
	//SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER , 1);
	//SDL_GL_SetAttribute(SDL_GL_SWAP_CONTROL , 1);
	//SDL_SetVideoMode(1680, 1050, 24, SDL_OPENGL | SDL_DOUBLEBUF | SDL_HWSURFACE | SDL_RESIZABLE);
	//SDL_WM_SetCaption("Game","");
	SDL_Window * window = SDL_CreateWindow("Game", 0, 0, 640, 360,
										   SDL_WINDOW_OPENGL | SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE);

	SDL_GLContext gl_context = SDL_GL_CreateContext(window);

	SDL_GL_SetSwapInterval(1);
	bool vsync_enabled = true;

	/* Initialize OpenGL */
	void *render_state = calloc(1, RENDER_MEMORY_SIZE);

	{
		int window_width, window_height;
		SDL_GetWindowSize(window, &window_width, &window_height);
		render_library.lib_renderer_init(render_state, window_width, window_height);
	}

	/* Initialize audio */
	audio_init();
	SDL_PauseAudio(0);

	/* Allocate memory for the game state */
	GameInput input = { 0 };
	GameState *gamestate = (GameState*)calloc(1, GAME_MEMORY_SIZE);
	Platform platform = { 0 };
	platform.load_image = load_image;
	platform.load_audio = load_audio;
	platform.platform_play = audio_play_chunk;
	platform.platform_render = render_library.lib_platform_render;
	

	/* Main Game Loop */
	static double frame_start_time = get_seconds() - (1.0 / 60.0);
	static struct timespec m_start_time;
	static bool m_has_start_time = false;
	for(;;) {

		Key * key = (Key*)&input.keys;
		for(u32 i = 0; i < sizeof(input.keys) / sizeof(Key); i++) {
			key->transitions = 0;
			key++;
		}
		key = (Key*)&input.debug_keys;
		for(u32 i = 0; i < sizeof(input.debug_keys) / sizeof(Key); i++) {
			key->transitions = 0;
			key++;
		}
		
#define HANDLE_KEY(sdl_suffix, input_field) case SDLK_ ## sdl_suffix : { \
	if(input.input_field.pressed && event.type == SDL_KEYUP) { \
		input.input_field.pressed = false; \
		input.input_field.transitions++; \
	} else if(!input.input_field.pressed && event.type == SDL_KEYDOWN) { \
		input.input_field.pressed = true; \
		input.input_field.transitions++; \
	} \
}

		/* Handle SDL events */
		SDL_Event event;
		while(SDL_PollEvent(&event)) {
			switch(event.type) {
			case SDL_QUIT: {
				exit(0);
				break;
			}
			case SDL_WINDOWEVENT: {
				switch(event.window.event) {
				case SDL_WINDOWEVENT_RESIZED: {
					int window_width, window_height;
					SDL_GetWindowSize(window, &window_width, &window_height);
					render_library.lib_renderer_init(render_state, window_width, window_height);
					break;
				}
				}
				break;
			}
			case SDL_KEYUP:
			case SDL_KEYDOWN: {
				switch(event.key.keysym.sym) {
					HANDLE_KEY(ESCAPE, keys.escape); break;
					HANDLE_KEY(LEFT, keys.left); break;
					HANDLE_KEY(DOWN, keys.down); break;
					HANDLE_KEY(RIGHT, keys.right); break;
					HANDLE_KEY(UP, keys.up); break;
					HANDLE_KEY(x, keys.attack); break;
					HANDLE_KEY(z, keys.jump); break;
					HANDLE_KEY(s, keys.activate_a); break;
					HANDLE_KEY(a, keys.activate_b); break;
					HANDLE_KEY(F1, debug_keys.F1); break;
					HANDLE_KEY(F2, debug_keys.F2); break;
					HANDLE_KEY(F3, debug_keys.F3); break;
					HANDLE_KEY(F4, debug_keys.F4); break;
					HANDLE_KEY(F5, debug_keys.F5); break;
					HANDLE_KEY(F6, debug_keys.F6); break;
					HANDLE_KEY(F7, debug_keys.F7); break;
					HANDLE_KEY(F8, debug_keys.F8); break;
					HANDLE_KEY(F9, debug_keys.F9); break;
					HANDLE_KEY(F10, debug_keys.F10); break;
					HANDLE_KEY(F11, debug_keys.F11); break;
					HANDLE_KEY(F12, debug_keys.F12); break;
				default: break;
				}
				break;
			}
			default: {
				break;
			}
			}
		}

		double frame_end_time = get_seconds();
		double delta_time = frame_end_time - frame_start_time;
		frame_start_time = frame_end_time;
		if(!game_library.logic_and_render(gamestate, GAME_MEMORY_SIZE, delta_time, &input, &platform)) {
			break;
		}

		SDL_GL_SwapWindow(window);

		if(!vsync_enabled) {
			struct timespec now;
			struct timespec delta;
			struct timespec frame_time = { .tv_sec = 0, .tv_nsec = 16666666 };

			clock_gettime(CLOCK_MONOTONIC, &now);
			if(!m_has_start_time) {
					m_start_time = now;
					m_has_start_time = true;
			} else {
				delta = timespec_diff(m_start_time, now);
				if(is_timespec_less(delta, frame_time)) {
						struct timespec sleep_time = timespec_diff(delta, frame_time);
						clock_nanosleep(CLOCK_MONOTONIC, 0, &sleep_time, NULL);
						m_start_time = timespec_add(now, sleep_time);
				} else {
						m_start_time = now;
				}
			}
		}

		if(debug_should_reload_libraries()) {
			debug_close_game_library(&game_library);
			game_library = debug_load_game_library();

			debug_close_render_library(&render_library);
			render_library = debug_load_render_library();
			platform.platform_render = render_library.lib_platform_render;

			{
				int window_width, window_height;
				SDL_GetWindowSize(window, &window_width, &window_height);
				render_library.lib_renderer_init(render_state, window_width, window_height);
			}
		}
	}

	SDL_GL_DeleteContext(gl_context);

	return 0;
}
