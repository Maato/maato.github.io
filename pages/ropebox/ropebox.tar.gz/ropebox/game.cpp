#include "game.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static inline float clamp_float(float lower, float upper, float value) {
	if(value < lower) return lower;
	if(value > upper) return upper;
	return value;
}
static inline int clamp_int(int lower, int upper, int value) {
	if(value < lower) return lower;
	if(value > upper) return upper;
	return value;
}

static inline float max_float(float a, float b) {
	if(b > a) return b;
	return a;
}

static inline float min_float(float a, float b) {
	if(b < a) return b;
	return a;
}

static inline float abs_float(float a) {
	if(a < 0.0f) return -a;
	return a;
}

#define RAND_MAX_32 ((1U << 31) - 1)
//#define RAND_MAX ((1U << 15) - 1)
 
inline int game_rand(int * rseed)
{
	return (*rseed = (*rseed * 214013 + 2531011) & RAND_MAX_32) >> 16;
}
static inline void remove_from_group(Object**group_base, Object*obj)
{
	if(obj->prev_in_group == NULL) {
		*group_base = obj->next_in_group;
	}
	if(obj->next_in_group) {
		obj->next_in_group->prev_in_group = obj->prev_in_group;
	}
	if(obj->prev_in_group) {
		obj->prev_in_group->next_in_group = obj->next_in_group;
	}
	
	obj->prev_in_group = 0;
	obj->next_in_group = 0;
}

#define pop_object(gs, obj, type) (_pop_object(gs, obj, &gs->object_group_##type))
static inline void _pop_object(GameState *gamestate, Object*obj, Object**group_base) {

	remove_from_group(group_base, obj);
	/* Add to none group */
	obj->type = OBJECT_NONE;
	if(gamestate->object_group_NONE) {
		obj->next_in_group = gamestate->object_group_NONE;
		obj->next_in_group->prev_in_group = obj;
	}
	gamestate->object_group_NONE = obj;
}

#define push_object(gs, type) ((type*)_push_object((gs), OBJECT_##type, &gs->object_group_##type))
static inline Object*_push_object(GameState *gamestate, enum ObjectType type, Object** group_base)
{
	Object *result = 0;
	if(gamestate->object_group_NONE) {
		/* First try to reuse an object from object_group_NONE */
		result = gamestate->object_group_NONE;
		remove_from_group(&gamestate->object_group_NONE, result);
	} else if(gamestate->live_objects < ArrayCount(gamestate->objects)) {
		/* Otherwise allocate a new object */
		result = &gamestate->objects[gamestate->live_objects];
		gamestate->live_objects++;
	}

	if(result) {
		memset(result, 0x0, sizeof(Object));
		result->type = type;
		result->next_in_group = *group_base;
		*group_base = result;
		return result;
	} else {
		puts("Out of objects");
		exit(1);
	}
}

static u8 segments[16*4] = { 0, 2, 2, 2, 0, 2, 0, 1, 2, 2, 2, 1, 0, 1, 1, 1, 1, 1, 2, 1, 0, 1, 0, 0,
							 2, 1, 2, 0, 0, 0, 2, 0, 0, 2, 1, 1, 2, 2, 1, 1, 0, 0, 1, 1, 2, 0, 1, 1 };
static u16 glyphs[256] = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4095, 0, 0, 0, 0, 0, 
	231, 68, 189, 221, 94, 219, 251, 85, 255, 223, 153, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	0, 127, 2731, 163, 252, 171, 43, 243, 126, 68, 196, 2602, 162, 870, 2406, 231, 
	63, 95, 2603, 219, 170, 230, 1570, 3174, 3840, 1792, 1665, 0
};

static void draw_laser(Platform *platform, Vec2 start, Vec2 end, float width, Vec4 color) {
	DrawItem item = { 0 };
	item.type = DRAW_LASER;
	item.laser.start = start;
	item.laser.end = end;
	item.laser.width = width;
	item.laser.color = color;
	platform->platform_render(&item, 1);
}

static void draw_lines(Platform *platform, Vec4 color, Vec2 *points, int count) {
	DrawItem item = { 0 };
	item.type = DRAW_LINE_LIST;
	item.lines.color = color;
	item.lines.count = count;
	item.lines.pts = points;
	platform->platform_render(&item, 1);
}

static void draw_image(Platform *platform, Texture tex, Vec2 corners[4], float time = 0.0f) {
	DrawItem item = { 0 };
	item.type = DRAW_IMAGE;
	item.image.tex = tex;
	for(int i = 0; i < 4; i++) {
		item.image.corners[i] = corners[i];
	}
	item.image.time = time;
	platform->platform_render(&item, 1);
}

static void draw_image(Platform *platform, Texture tex, Vec2 position, Vec2 size, float time = 0.0f) {
	Vec2 corners[4];
	corners[0] = position;
	corners[1] = position + Vec2{size.x, 0.0f};
	corners[2] = position + size;
	corners[3] = position + Vec2{0.0f, size.y};
	draw_image(platform, tex, corners, time);
}

static void draw_rect(Platform *platform, Vec2 position, Vec2 size, Vec4 color = RGB(0, 255, 0)) {
	Vec2 bl = position;
	Vec2 br = bl + Vec2{size.x, 0.0f};
	Vec2 tr = bl + size;
	Vec2 tl = bl + Vec2{0.0f, size.y};

	
	draw_laser(platform,
			   bl,
			   br,
			   0.002f,
			   color);
	draw_laser(platform,
			   br,
			   tr,
			   0.002f,
			   color);
	draw_laser(platform,
			   tr,
			   tl,
			   0.002f,
			   color);
	draw_laser(platform,
			   tl,
			   bl,
			   0.002f,
			   color);
}

static void draw_glyph(Platform *platform, Vec2 p, Vec2 scale, u16 c, Vec4 color, float thickness = 0.005f)
{
	int segment_count = 0;
	Vec2 pts[16 * 2];

	for(int i = 0; i < 16; i++) {
		if(c & (1 << i)) {
			pts[segment_count*2+0].x = (segments[i*4+0] / 2.0f) * scale.x + p.x;
			pts[segment_count*2+0].y = (segments[i*4+1] / 2.0f) * scale.y * 2.5f + p.y;
			pts[segment_count*2+1].x = (segments[i*4+2] / 2.0f) * scale.x + p.x;
			pts[segment_count*2+1].y = (segments[i*4+3] / 2.0f) * scale.y * 2.5f + p.y;

			draw_laser(platform,
					   { pts[segment_count*2+0].x, pts[segment_count*2+0].y},
					   { pts[segment_count*2+1].x, pts[segment_count*2+1].y},
					   thickness,
					   color);

			segment_count++;
		}
	}

	//draw_lines(platform, { 0.0f, 1.0f, 1.0f, 1.0f }, pts, segment_count * 2);
}

static void draw_string(Platform *platform, const char*txt, Vec2 p, Vec2 scale, Vec4 color = { 1.0f, 1.0f, 1.0f, 1.0f }, float thickness = 0.005f)
{
	for(u8 c = *txt; *txt; c = *(++txt)) {
		if(c >= 'A' && c <= 'Z') { c -= 'A' - 'a'; }
		draw_glyph(platform, p, scale, glyphs[c], color, thickness);
		p.x += scale.x * 1.5f;
	}
}

static void load_resources(GameState *gamestate, Platform *platform) {
	gamestate->image_test            = platform->load_image("data/planet.png");
	gamestate->image_tile_01         = platform->load_image("data/tile_01.png");
	gamestate->image_heart           = platform->load_image("data/heart.png");
	gamestate->image_heart_container = platform->load_image("data/heart_container.png");
	gamestate->image_walker          = platform->load_image("data/walker.png");
	gamestate->audio_coin            = platform->load_audio("data/coin.wav");
	gamestate->audio_pickup_heart    = platform->load_audio("data/pickup_heart.wav");
	gamestate->audio_jump            = platform->load_audio("data/jump.wav");

	DrawItem load = { 0 };
	load.type = DRAW_LOAD_IMAGE;
	load.load_image.image = &gamestate->image_test;
	load.load_image.tex = TEXTURE_TEST;
	platform->platform_render(&load, 1);

	load = { 0 };
	load.type = DRAW_LOAD_IMAGE;
	load.load_image.image = &gamestate->image_tile_01;
	load.load_image.tex = TEXTURE_TILE_01;
	platform->platform_render(&load, 1);

	load = { 0 };
	load.type = DRAW_LOAD_IMAGE;
	load.load_image.image = &gamestate->image_heart;
	load.load_image.tex = TEXTURE_HEART;
	platform->platform_render(&load, 1);
	
	load = { 0 };
	load.type = DRAW_LOAD_IMAGE;
	load.load_image.image = &gamestate->image_heart_container;
	load.load_image.tex = TEXTURE_HEART_CONTAINER;
	platform->platform_render(&load, 1);

	load = { 0 };
	load.type = DRAW_LOAD_IMAGE;
	load.load_image.image = &gamestate->image_walker;
	load.load_image.tex = TEXTURE_WALKER;
	platform->platform_render(&load, 1);
	

	Vec2 p = { -0.99f, 0.50f}; 
	draw_string(platform, "Loading images", p, Vec2{0.02f,0.02f});
}

u16 get_world_tile(GameState *gamestate, int x, int y)
{
	int world_y = y / CHUNK_DIAMETER;
	int chunk_x = x;
	int chunk_y = y - world_y * CHUNK_DIAMETER;

	if(chunk_x < 0 || chunk_x >= CHUNK_DIAMETER) { return 0; }
	if(world_y < 0 || world_y >= ArrayCount(gamestate->world)) { return 0; }
	if(chunk_y < 0 || chunk_y >= CHUNK_DIAMETER) { return 0; }
	return gamestate->world[world_y].tiles[chunk_x + chunk_y * CHUNK_DIAMETER];
}

static void initialize_world(GameState *gamestate, WorldChunk *world, int chunk_count) {
	/* Initialize world */
	int layout_seed = 0;
	int heart_seed = 1;
	int walker_seed = 2;

	for(int world_chunk_index = 0;
		world_chunk_index < chunk_count;
		++world_chunk_index)
	{
		WorldChunk *chunk = &world[world_chunk_index];
		chunk->x = 0;
		chunk->y = world_chunk_index;

		int empty_cells = 0;

		for(int y = 0; y < CHUNK_DIAMETER; ++y) {
			for(int x = 0; x < CHUNK_DIAMETER; ++x) {

				int wx = x;
				int wy = world_chunk_index * CHUNK_DIAMETER + y;


				if(wx == 0 || wx == CHUNK_DIAMETER - 1 || wy == 0) {
					chunk->tiles[x + y * CHUNK_DIAMETER] = 1;
				} else {

					u16 new_tile = 0;

					if(game_rand(&layout_seed) % 10 == 1) {
						new_tile = 1;
					} else if(empty_cells > 16) {
						new_tile = 1;
					} else {
						new_tile = 0;
					}

					if(new_tile == 0) {
						empty_cells++;
					} else {
						empty_cells = 0;
					}

					chunk->tiles[x + y * CHUNK_DIAMETER] = new_tile;
					
					if(new_tile == 0 && get_world_tile(gamestate, wx, wy-1) == 1 && game_rand(&heart_seed) % 30 == 1) {
						Heart * heart = push_object(gamestate, Heart);
						heart->body.position = Vec2{(float)wx+0.5f, (float)wy} * TILE_DIAMETER;
						heart->body.old_position = heart->body.position;
						heart->body.velocity = Vec2{0.0f, 0.0f};
						heart->body.size = Vec2{0.4f, 0.4f} * TILE_DIAMETER;
					}

					if(new_tile == 0 && get_world_tile(gamestate, wx-1, wy) == 0 &&
					   get_world_tile(gamestate, wx-1, wy-1) == 0 &&
					   get_world_tile(gamestate, wx, wy-1) == 0 &&
					   get_world_tile(gamestate, wx-1, wy-2) == 1 &&
					   get_world_tile(gamestate, wx, wy-2) == 1 && wy > 2)
					{
						Walker *walker = push_object(gamestate, Walker);
						walker->body.position = Vec2{(float)wx, (float)wy-1} * TILE_DIAMETER;
						walker->body.old_position = walker->body.position;
						walker->body.velocity = Vec2{0.0f, 0.0f};
						walker->body.size = Vec2{1.2f, 1.2f} * TILE_DIAMETER;
						walker->invuln_timer = 0;
						walker->health = 3;
					}
				}
			}
		}
	}
	for(int x = 1; x < CHUNK_DIAMETER-1; x++) {
		world[0].tiles[x + 1 * CHUNK_DIAMETER] = 0;
	}
}

bool solve_collision_try(GameState *gamestate, Platform *platform, PhysicalObject *object, Vec2 start, Vec2 end)
{
	Vec2 size = object->size;

	float w_left = min_float(start.x, end.x) - size.x / 2.0f;
	float w_right = max_float(start.x, end.x) + size.x / 2.0f;
	float w_top = max_float(start.y, end.y) + size.y;
	float w_bottom = min_float(start.y, end.y);

	int left = (int)floor(w_left / TILE_DIAMETER);
	int right = (int)ceil(w_right / TILE_DIAMETER);
	int top = (int)ceil(w_top / TILE_DIAMETER);
	int bottom = (int)floor(w_bottom / TILE_DIAMETER);

	// draw_rect(platform,
	// 		  (Vec2{(float)left,(float)bottom} * TILE_DIAMETER - gamestate->offset) * gamestate->scale,
	// 		  (Vec2{(float)width,(float)height} * TILE_DIAMETER) * gamestate->scale);

	for(int y = bottom; y < top; y++) {
		for(int x = left; x < right; x++) {
			if(get_world_tile(gamestate, x, y) >= 1) {
				return false;
			}
		}
	}
	return true;
}

void solve_collision(GameState *gamestate, Platform *platform, PhysicalObject *object) {
	Vec2 start = object->old_position;
	Vec2 end = object->position;
	if(solve_collision_try(gamestate, platform, object, start, end)) {
		object->position = end;
		return;
	}
	// Vec2 only_x = Vec2{end.x, start.y};
	// if(solve_collision_try(gamestate, platform, object, start, only_x)) {
	// 	Vec2 x_probe_y = Vec2{end.x, start.y};
	// 	for(int i = 0; i < 5; i++) {
	// 		x_probe_y.y += (end.y - start.y) / 5.0f;
	// 		if(!solve_collision_try(gamestate, platform, object, start, x_probe_y)) {
	// 			break;
	// 		}
	// 	}
	// 	return;
	// }

	// Vec2 only_y = Vec2{start.x, end.y};
	// if(solve_collision_try(gamestate, platform, object, start, only_y)) {
	// 	Vec2 y_probe_x = Vec2{start.x, end.y};
	// 	for(int i = 0; i < 5; i++) {
	// 		y_probe_x.x += (end.x - start.x) / 5.0f;
	// 		if(!solve_collision_try(gamestate, platform, object, start, y_probe_x)) {
	// 			break;
	// 		}
	// 	}
	// 	return;
	// }

	Vec2 probe = Vec2{start.x, start.y};
	for(int i = 0; i < 5; i++) {
		Vec2 good_probe = probe;
		probe.x += (end.x - start.x) / 5.0f;
		if(!solve_collision_try(gamestate, platform, object, start, probe)) {
			probe = good_probe;
			break;
		}
	}
	for(int i = 0; i < 5; i++) {
		Vec2 good_probe = probe;
		probe.y += (end.y - start.y) / 5.0f;
		if(!solve_collision_try(gamestate, platform, object, start, probe)) {
			probe = good_probe;
			break;
		}
	}

	object->position = probe;
}

Vec2 *object_get_position(Object * obj)
{
	switch(obj->type) {
	case OBJECT_Player: return &obj->player.body.position;
	case OBJECT_RopeBox: return &obj->ropebox.body.position;
	case OBJECT_WallRope: return &obj->wallrope.body.position;
	case OBJECT_Heart: return &obj->heart.body.position;
	case OBJECT_Walker: return &obj->walker.body.position;
	default: return NULL;
	}
}

PhysicalObject *object_get_physical(Object *obj)
{
	switch(obj->type) {
	case OBJECT_Player: return &obj->player.body;
	case OBJECT_RopeBox: return &obj->ropebox.body;
	case OBJECT_Heart: return &obj->heart.body;
	case OBJECT_Walker: return &obj->walker.body;
	default: return NULL;
	}
}

static bool objects_overlap(PhysicalObject *a, PhysicalObject *b)
{
	return (a->position.x - a->size.x / 2.0f < b->position.x + b->size.x / 2.0f &&
			a->position.x + a->size.x / 2.0f > b->position.x - b->size.x / 2.0f &&
			a->position.y - a->size.y / 2.0f < b->position.y + b->size.y / 2.0f &&
			a->position.y + a->size.y / 2.0f > b->position.y - b->size.y / 2.0f );
	   
}

#define GRAVITY (-0.981f)
#define JUMP_VELOCITY (10.0f)
bool game_logic_and_render(void *game_memory, u64 game_memory_size, double delta_time, GameInput *input, Platform *platform)
{
	GameState *gamestate = (GameState*)game_memory;
	if(!gamestate->initialized) {
		gamestate->initialized = true;
		gamestate->reset_level = true;

		/* Memory */
		gamestate->master_arena = { 0 };
		gamestate->master_arena.size = game_memory_size;
		gamestate->master_arena.data = (u8*)gamestate;
		arena_push_struct(&gamestate->master_arena, GameState);

		/* Resources */
		load_resources(gamestate, platform);

	}
	if(gamestate->reset_level) {

		gamestate->live_objects = 0;
		memset(gamestate->objects, 0x0, sizeof(gamestate->objects));
		gamestate->object_group_NONE = NULL;
		gamestate->object_group_Player = NULL;
		gamestate->object_group_WallRope = NULL;
		gamestate->object_group_RopeBox = NULL;
		gamestate->object_group_Heart = NULL;
		gamestate->object_group_Walker = NULL;
		
		/* GameObjects */
		Player *player = push_object(gamestate, Player);
		gamestate->player = player;
		player->heart_containers = 10;
		player->hearts = 3;
		player->body.position = { CHUNK_DIAMETER / 2 * TILE_DIAMETER, TILE_DIAMETER * 1.01f };
		player->body.old_position = player->body.position; 
		player->body.size = Vec2{0.8f, 0.9f} * TILE_DIAMETER;
		player->hanging_from_ledge = false;
		player->facing_dir = Vec2{1.0f, 0.0f};

		RopeBox *ropebox = push_object(gamestate, RopeBox);
		player->ropebox = ropebox;
		ropebox->held = true;
		ropebox->body = player->body;
		ropebox->body.size = Vec2{0.4f, 0.4f} * TILE_DIAMETER;

		initialize_world(gamestate, gamestate->world, ArrayCount(gamestate->world));

		gamestate->reset_level = false;
	}

	DrawItem clear = { 0 };
	clear.type = DRAW_CLEAR;
	clear.clear.color = 0xff000000;
	platform->platform_render(&clear, 1);

	if(gamestate->state == STATE_PLAYING) {

		/* Initialize Y groups */
		int group_count = 64;
		Object * ygroups[group_count];
		for(int i = 0; i < group_count; i++) {
			ygroups[i] = 0;
		}
		float y_group_max_height = ArrayCount(gamestate->world) * CHUNK_DIAMETER * TILE_DIAMETER;
		float y_group_height = y_group_max_height / (float)group_count;
		for(u32 i = 0; i < gamestate->live_objects; i++) {
			Object * obj = &gamestate->objects[i];
			Vec2 *position = object_get_position(obj);
			if(position) {
				int group_idx = clamp_int(0, group_count-1, (int)(position->y / y_group_max_height * group_count));
				obj->next_in_y_group = ygroups[group_idx];
				ygroups[group_idx] = obj;
			}
		}


		/* Debug button handling */
		if(input->debug_keys.F5.pressed && input->debug_keys.F5.transitions) {
			load_resources(gamestate, platform);
		}
		if(input->debug_keys.F3.pressed && input->debug_keys.F3.transitions) {
			initialize_world(gamestate, gamestate->world, ArrayCount(gamestate->world));
		}

		if(input->keys.escape.pressed && input->keys.escape.transitions) {
			return false;
		}

		gamestate->elapsed_time += delta_time;



		////////////////////////////////////////////////////////////////////////////////	
		// Velocity Updating
		////////////////////////////////////////////////////////////////////////////////	
		for(u32 i = 0; i < gamestate->live_objects; i++) {
			Object *obj = &gamestate->objects[i];
			PhysicalObject *body = object_get_physical(obj);
			if(body) {
				body->old_position = body->position;
			}
		}

		////////////////////////////////////////////////////////////////////////////////	
		// Pre-Collision solving Logic
		////////////////////////////////////////////////////////////////////////////////	
		for(u32 i = 0; i < gamestate->live_objects; i++) {
			Object * obj = &gamestate->objects[i];
			switch(obj->type) {
			case OBJECT_Player: {
				Player *player = &obj->player;
				PhysicalObject *body = &player->body;

				if(player->invuln_timer) {
					player->invuln_timer -= 1;
				}

				if(!input->keys.jump.pressed || obj->player.body.velocity.y < 0.0f) {
					body->velocity += Vec2{0.0f, GRAVITY * 1.5f * (float)delta_time * 60.0f};
				} else {
					body->velocity += Vec2{0.0f, GRAVITY * (float)delta_time * 60.0f};
				}

				/* Do physics simulation */
				bool player_on_ground = !solve_collision_try(gamestate, platform,
															 &player->body,
															 player->body.position,
															 player->body.position + Vec2{0.0f, -TILE_DIAMETER / 25.0f});



				if(player_on_ground || player->hanging_from_ledge) {
					player->frames_in_air = 0;
					player->air_jumps_remaining = 0;
					player->frames_in_air_with_negative_y_velocity = 0;
				} else {
					player->frames_in_air++;
					if(player->body.velocity.y < 0.0f) {
						player->frames_in_air_with_negative_y_velocity++;
					}
				}

				/* Handle input */
				{
					bool can_jump = (player->frames_in_air < 5) || player->hanging_from_ledge;
					if(can_jump && input->keys.jump.pressed && input->keys.jump.transitions) {
						if(player->hanging_from_ledge && input->keys.down.pressed) {
							player->can_extend_jump = false;
						} else {
							player->body.velocity.y = JUMP_VELOCITY;
							platform->platform_play(&gamestate->audio_jump);
							if(player->hanging_from_ledge) {
								player->can_extend_jump = true;
							} else {
								player->can_extend_jump = true;
							}
						}
						player->hanging_from_ledge = false;
					}
					if(!can_jump && player->air_jumps_remaining > 0 && input->keys.jump.pressed && input->keys.jump.transitions) {
						player->body.velocity.y = JUMP_VELOCITY;
						platform->platform_play(&gamestate->audio_jump);
						player->can_extend_jump = false;
						player->frames_in_air = 0;
						player->air_jumps_remaining--;
					}
				}

				if(!input->keys.jump.pressed) {
					player->can_extend_jump = false;
				}

				if(player->can_extend_jump && input->keys.jump.pressed && (!input->keys.jump.transitions)) {
					player->body.velocity.y = JUMP_VELOCITY;
					player->can_extend_jump = player->frames_in_air < 4; 
				}


				if(player->hanging_from_ledge) {
					player->body.velocity = Vec2{0.0f, 0.0f};
				} else {
					if(input->keys.left.pressed)  {
						player->facing_dir.x = -1.0f;
						player->body.velocity.x -= 1.5f;
					} 
					if(input->keys.right.pressed) {
						player->facing_dir.x = 1.0f;
						player->body.velocity.x += 1.5f;
					}

					if(!(input->keys.left.pressed || input->keys.right.pressed || (input->keys.attack.pressed && !player->ropebox->held))) {
						player->body.velocity.x *= 0.6f;
					}
				}

				player->body.velocity.x = clamp_float(-10.0f, 10.0f, player->body.velocity.x);
				player->body.velocity.y = clamp_float(-20.0f, 40.0f, player->body.velocity.y);


				PhysicalObject *ropebox_body = &player->ropebox->body;
				PhysicalObject *player_body = &player->body;
				bool overlap = objects_overlap(ropebox_body, player_body);
				if(!player->ropebox->held) {

					/* Pickup the rope box */
					if((input->keys.activate_a.pressed || (input->keys.attack.pressed && input->keys.attack.transitions && input->keys.down.pressed))
					   && overlap)
					{
						player->ropebox->held = true;
					} else if(input->keys.attack.pressed) {
						bool ropebox_on_ground = !solve_collision_try(gamestate, platform,
																	  ropebox_body,
																	  ropebox_body->position,
																	  ropebox_body->position + Vec2{0.0f, -TILE_DIAMETER / 25.0f});
						if(ropebox_on_ground) {
							Vec2 force_dir = vec_normalize(player_body->position - ropebox_body->position);
							player_body->velocity -= force_dir * 2.0f;
						}
					} else if(input->keys.activate_a.pressed) {
						Vec2 force_dir = vec_normalize(ropebox_body->position - player_body->position);
						ropebox_body->velocity -= force_dir * 2.0f;
					}
				} else {
					if(input->keys.attack.pressed && input->keys.attack.transitions) {
						Vec2 additional_force = player->facing_dir * 10.0f;
						additional_force.y = 15.0f;
						if(input->keys.up.pressed) {
							additional_force.x *= 0.3f;
							additional_force += Vec2{0.0f, 5.0f};
						} else if(input->keys.down.pressed && player_on_ground) {
							additional_force = Vec2{ 0.0f, 0.0f };
						} else if(input->keys.down.pressed) {
							additional_force.y *= -1.0f;
						}
						ropebox_body->velocity = player_body->velocity / 10.0f + additional_force;
						player->ropebox->held = false;
					}
				}
				break; /* Player Logic */
			}
			case OBJECT_RopeBox: {
				if(!obj->ropebox.held) {
					PhysicalObject *body = &obj->ropebox.body;
					body->velocity += Vec2{0.0f, GRAVITY * (float)delta_time * 60.0f};
					bool on_ground = !solve_collision_try(gamestate, platform,
														  body,
														  body->position,
														  body->position + Vec2{0.0f, -TILE_DIAMETER / 25.0f});
					if(on_ground && !input->keys.activate_a.pressed) {
						body->velocity.x *= 0.3f;
					}
				}
				break; /* RopeBox Logic */
			}
			case OBJECT_Walker: {
				if(obj->walker.invuln_timer) {
					obj->walker.invuln_timer--;
				}
				break;
			}
			default: {
			}
			}
		}



		////////////////////////////////////////////////////////////////////////////////	
		// Collision solving / Velocity Updating
		////////////////////////////////////////////////////////////////////////////////	
		for(u32 i = 0; i < gamestate->live_objects; i++) {
			Object *obj = &gamestate->objects[i];
			PhysicalObject *body = object_get_physical(obj);

			if(body) {
				body->position += body->velocity * delta_time;
				solve_collision(gamestate, platform, body);

				if(obj->type == OBJECT_Player) {

					Player *player = &obj->player;
					bool player_on_ground = !solve_collision_try(gamestate, platform,
																 &player->body,
																 player->body.position,
																 player->body.position + Vec2{0.0f, -TILE_DIAMETER / 25.0f});

					if(player->frames_in_air_with_negative_y_velocity > 20 && player_on_ground && player->body.velocity.y < -19.0f) {
						if(player->invuln_timer == 0) {
							player->invuln_timer = 60;
							if(player->hearts >= 1) {
								player->hearts -= 1;
								if(player->hearts == 0) {
									gamestate->state = STATE_DIED;
									gamestate->state_timer = 3.0f;
								}
							}
						}
					}
				}

				body->velocity = (body->position - body->old_position) / delta_time;
			}
		}


		////////////////////////////////////////////////////////////////////////////////	
		// Post-Collision solving Logic
		////////////////////////////////////////////////////////////////////////////////	
		for(u32 i = 0; i < gamestate->live_objects; i++) {
			Object * obj = &gamestate->objects[i];
			switch(obj->type) {
			case OBJECT_Player: {
				Player *player = &obj->player;
				PhysicalObject *body = &player->body;

				#define LEDGE_GRAB_X_THRESHOLD (TILE_DIAMETER / 50.0f)

				if(!(input->keys.attack.pressed)) {
					/* Test for right ledge grabbing */
					Vec2 previous_tr = player->body.old_position + player->body.size * Vec2{0.5f, 1.0f};
					Vec2 new_tr      = player->body.position     + player->body.size * Vec2{0.5f, 1.0f};
					if((int)floor(previous_tr.y / TILE_DIAMETER) != (int)floor(new_tr.y / TILE_DIAMETER)) {
						if(player->body.velocity.y < 0.0f && player->body.velocity.x >= 0.0f) {
							int test_y = (int)floor(new_tr.y / TILE_DIAMETER);

							for(int i = -1; i <= 1; i++) {
								int test_x = (int)floor(new_tr.x / TILE_DIAMETER) + i;

								if(get_world_tile(gamestate, test_x, test_y) == 1) {
									if(get_world_tile(gamestate, test_x, test_y+1) == 0) {
										Vec2 tile_top_left = Vec2{(float)test_x, (float)test_y+1.0f} * TILE_DIAMETER;
										if(abs_float(tile_top_left.x-new_tr.x) < LEDGE_GRAB_X_THRESHOLD && abs_float(tile_top_left.y-new_tr.y) < 0.3f) {
											player->hanging_from_ledge = true;
											player->body.position.y = tile_top_left.y - player->body.size.y * 1.001f;
											break;
										}
									}
								}
							}
						}
					}

					/* Test for left ledge grabbing */
					Vec2 previous_tl = player->body.old_position + player->body.size * Vec2{-0.5f, 1.0f};
					Vec2 new_tl      = player->body.position     + player->body.size * Vec2{-0.5f, 1.0f};
					if((int)floor(previous_tl.y / TILE_DIAMETER) != (int)floor(new_tl.y / TILE_DIAMETER)) {
						if(player->body.velocity.y < 0.0f && player->body.velocity.x <= 0.0f) {
							int test_y = (int)floor(new_tl.y / TILE_DIAMETER);

							for(int i = -1; i <= 1; i++) {
								int test_x = (int)floor(new_tl.x / TILE_DIAMETER) + i;

								if(get_world_tile(gamestate, test_x, test_y) == 1) {
									if(get_world_tile(gamestate, test_x, test_y+1) == 0) {
										Vec2 tile_top_right = Vec2{(float)test_x+1.0f, (float)test_y+1.0f} * TILE_DIAMETER;
										if(abs_float(tile_top_right.x-new_tl.x) < LEDGE_GRAB_X_THRESHOLD && abs_float(tile_top_right.y-new_tl.y) < 0.3f) {
											player->hanging_from_ledge = true;
											player->body.position.y = tile_top_right.y - player->body.size.y * 1.001f;
											break;
										}
									}
								}
							}
						}
					}


				} else {
					player->hanging_from_ledge = false;
				}

				if(player->ropebox->held) {
					player->ropebox->body.velocity = Vec2{0.0f, 0.0f};
					player->ropebox->body.position = Vec2{ player->body.position.x,
														   player->body.position.y + (player->body.size.y - player->ropebox->body.size.y) / 2.0f };
				}

				int body_ygroup = clamp_int(1, group_count-2, (int)(body->position.y  / y_group_max_height * group_count));
				for(int group_index = body_ygroup-1; group_index <= body_ygroup+1; group_index++) {
					Object *other = ygroups[group_index];
					while(other) {
						PhysicalObject *other_body = object_get_physical(other);
						if(other_body && other->type == OBJECT_Heart) {
							if(obj->player.hearts < obj->player.heart_containers) {
								if(objects_overlap(body, other_body)) {
									pop_object(gamestate, other, Heart);
									platform->platform_play(&gamestate->audio_pickup_heart);
									obj->player.hearts++;
								}
							}
						} else if(other_body && other->type == OBJECT_Walker) {
							if(objects_overlap(body, other_body) && obj->player.invuln_timer == 0) {
								if(obj->player.hearts >= 1) {
									obj->player.hearts -= 1;
									if(obj->player.hearts == 0) {
										gamestate->state = STATE_DIED;
										gamestate->state_timer = 3.0f;
									}
								}
								obj->player.invuln_timer = 60;

								Vec2 diff = vec_normalize(body->position - other_body->position);
								body->velocity = diff * 20.0f;
							}
						}

						other = other->next_in_y_group;
					}
				}
				break;
			}
			case OBJECT_RopeBox: {
				RopeBox *ropebox = &obj->ropebox;
				PhysicalObject *body = &ropebox->body;
				int body_ygroup = clamp_int(1, group_count-2, (int)(body->position.y  / y_group_max_height * group_count));
				for(int group_index = body_ygroup-1; group_index <= body_ygroup+1; group_index++) {
					Object *other = ygroups[group_index];
					while(other) {
						PhysicalObject *other_body = object_get_physical(other);
						if(other_body && other->type == OBJECT_Walker) {
							if(objects_overlap(body, other_body) && other->walker.invuln_timer == 0) {

								other->walker.invuln_timer = 60;
								Vec2 diff = vec_normalize(body->position - other_body->position);
								printf("%.2f, %.2f\n", diff.x, diff.y);
								body->velocity = diff * 10.0f;
								if(other->walker.health) {
									other->walker.health -= 1;
									if(!other->walker.health) {
										pop_object(gamestate, other, Walker);
									}
								}
							}
						}

						other = other->next_in_y_group;
					}
				}

				break;
			}
			default: {
				break;
			}
			}
		}
	} else if(gamestate->state == STATE_DIED) {
		gamestate->state_timer -= delta_time;
		if(gamestate->state_timer <= 0) {
			gamestate->reset_level = true;
			gamestate->state = STATE_PLAYING;
		}
	} else if(gamestate->state == STATE_START) {
		if(input->keys.jump.pressed) {
			gamestate->state = STATE_PLAYING;
		}
	}

	////////////////////////////////////////////////////////////////////////////////	
	// Drawing
	////////////////////////////////////////////////////////////////////////////////	
	

	/* Draw the world */
	gamestate->offset = gamestate->player->body.position;
	gamestate->offset.y += TILE_DIAMETER * 2.0f;
	gamestate->offset.x = TILE_DIAMETER * (CHUNK_DIAMETER/2);
	gamestate->scale = Vec2{1.9 / (float)(CHUNK_DIAMETER), 1.9 / (float)CHUNK_DIAMETER};


	/* Draw three chunks around players position */
	int player_world_chunk_y = (int)(gamestate->player->body.position.y / (CHUNK_DIAMETER * TILE_DIAMETER));
	int world_start_y = clamp_int(0, ArrayCount(gamestate->world)-1, player_world_chunk_y - 1);
	int world_end_y = clamp_int(0, ArrayCount(gamestate->world)-1, player_world_chunk_y + 1);

	for(int world_index = world_start_y;
		world_index <= world_end_y;
		world_index++)
	{
		WorldChunk *chunk = &gamestate->world[world_index];

		for(int y = 0; y < CHUNK_DIAMETER; ++y) {
			for(int x = 0; x < CHUNK_DIAMETER; ++x) {

				Vec2 tile_bl = Vec2{ (float)x, world_index * CHUNK_DIAMETER + (float)y} * TILE_DIAMETER;
				//Vec2 tile_br = tile_bl + Vec2{ TILE_DIAMETER, 0.0f};
				//Vec2 tile_tl = tile_bl + Vec2{ 0.0f, TILE_DIAMETER };
				//Vec2 tile_tr = tile_bl + Vec2{ TILE_DIAMETER, TILE_DIAMETER };

				if(chunk->tiles[x + y * CHUNK_DIAMETER] >= 1) {
					Vec2 overdraw = Vec2{1.0f,1.0f} * TILE_DIAMETER * 0.07; // 0.08f;
					draw_image(platform,
							   TEXTURE_TILE_01,
							   (tile_bl - gamestate->offset - overdraw) * gamestate->scale,
							   (Vec2{ 1.0f, 1.0f } * TILE_DIAMETER  + overdraw * 2.0f) * gamestate->scale,
							   gamestate->elapsed_time);
				}
			}
		}

		Vec2 glyph_tl = (Vec2{ 0 - TILE_DIAMETER * 0.4f, (world_index+1) * (float)CHUNK_DIAMETER -3} * TILE_DIAMETER - gamestate->offset) * gamestate->scale;
		char glyph = '0' + world_index;
		if(glyph > '9') {
			glyph = glyph - '9' + 'a' - 1;
		}
		draw_glyph(platform,
				   glyph_tl,
				   gamestate->scale * TILE_DIAMETER * 0.3f,
				   glyphs[(int)glyph],
				   RGB(255,0,0));
	}


	for(u32 i = 0; i < gamestate->live_objects; i++) {
		Object *obj = &gamestate->objects[i];
		PhysicalObject *body = object_get_physical(obj);

		if(body) {

			switch(obj->type) {
			case OBJECT_Player: {
				PhysicalObject *ropebox_body = &obj->player.ropebox->body;
				Vec2 start = body->position + Vec2{0.0f, 0.5f} * body->size;
				Vec2 end = ropebox_body->position + Vec2{0.0f, 0.5f} * ropebox_body->size;
				draw_laser(platform,
						   (start - gamestate->offset) * gamestate->scale,
						   (end - gamestate->offset) * gamestate->scale,
						   0.01f, RGB(255,255,255));

				if(obj->player.invuln_timer % 2 == 0) {
					draw_image(platform,
							   TEXTURE_TILE_01,
							   (body->position - gamestate->offset - Vec2{body->size.x / 2.0f, 0.0f}) * gamestate->scale,
							   (body->size) * gamestate->scale,
							   gamestate->elapsed_time);
				}
				break;
			}
			case OBJECT_RopeBox: {
				draw_image(platform,
						   TEXTURE_TILE_01,
						   (body->position - gamestate->offset - Vec2{body->size.x / 2.0f, 0.0f}) * gamestate->scale,
						   (body->size) * gamestate->scale,
						   gamestate->elapsed_time);
				break;
			}
			case OBJECT_Heart: {
				draw_image(platform,
						   TEXTURE_HEART,
						   (body->position - gamestate->offset - Vec2{body->size.x / 2.0f, 0.0f}) * gamestate->scale,
						   (body->size) * gamestate->scale,
						   gamestate->elapsed_time);
				break;
			}
			case OBJECT_Walker: {
				if(obj->walker.invuln_timer % 2 == 0) {
					draw_image(platform,
							   TEXTURE_WALKER,
							   (body->position - gamestate->offset - Vec2{body->size.x / 2.0f, 0.0f}) * gamestate->scale,
							   (body->size) * gamestate->scale,
							   gamestate->elapsed_time);
				}
				break;
			}
			default: {
				break;
			}
			}
			
		}
	}

	for(int i = 0; i < gamestate->player->heart_containers; i++) {
		Vec2 size = { 0.07f, 0.07f };
		Vec2 start = { -1.0f + i * size.x, 1.0f/(16.0f/9.0f) - size.y};
		if(i < gamestate->player->hearts) {
			draw_image(platform,
					   TEXTURE_HEART,
					   start,
					   size,
					   gamestate->elapsed_time);
		} else {
			draw_image(platform,
					   TEXTURE_HEART_CONTAINER,
					   start,
					   size,
					   gamestate->elapsed_time);
		}
	}



	if(gamestate->state == STATE_DIED) {


		
		Vec2 p = { -0.6f, 0.0f };
		draw_string(platform, "You Died", p, Vec2{0.1f,0.1f}, RGB(255, 0, 0), 0.02f);
		p = { 0.0f, -0.3f };
		int glyph = '0' + (int)gamestate->state_timer;
		draw_glyph(platform, p, Vec2{0.1f,0.1f}, glyphs[glyph], RGB(255,0,0), 0.02f);

	} else if(gamestate->state == STATE_START) {
		draw_image(platform,
				   TEXTURE_TEST,
				   { -0.8f, -0.4f },
				   { 1.6f, 0.8f },
				   gamestate->elapsed_time);
		Vec2 p = { -0.5f, 0.0f };
		draw_string(platform, "RopeBox", p, Vec2{0.1f,0.1f}, RGB(255, 255, 255), 0.02f);
		p = { -0.13f, -0.1f };
		draw_string(platform, "z to start", p, Vec2{0.02f,0.02f}, RGB(255, 255, 255), 0.005f);
	}
	

	DrawItem flush = { 0 };
	flush.type = DRAW_FLUSH;
	flush.clear.color = 0xff000000;
	platform->platform_render(&flush, 1);

	if(input->debug_keys.F6.pressed && input->debug_keys.F6.transitions) {
		platform->platform_play(&gamestate->audio_coin);
	}

	return true;
}
