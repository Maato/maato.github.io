#ifndef DBG_H
#define DBG_H

#include <stdio.h>
#include <errno.h> 
#include <string.h>

#ifdef NDEBUG
#define debug(M, ...)
#else 
#define debug(M, ...) fprintf(stderr, "DEBUG %s:%d: " M "\n", (__FILE__), __LINE__, ##__VA_ARGS__) 
#endif

#define clean_errno() (errno == 0 ? "None" : strerror(errno))
 
#define log_error(M, ...)  fprintf(stdout, "[0;31mERR:[0m (%s:%d: errno: %s) " M "\n", (__FILE__), __LINE__, clean_errno(), ##__VA_ARGS__)
#define log_warning(M, ...) fprintf(stdout, "[0;33mWARN:[0m (%s:%d: errno: %s) " M "\n", (__FILE__), __LINE__, clean_errno(), ##__VA_ARGS__) 
#define log_info(M, ...) fprintf(stdout, "[0;34mINFO:[0m " M "\n", ##__VA_ARGS__) 

#define check(A, M, ...)       if(!(A)) { log_error(M, ##__VA_ARGS__); errno=0; goto error; } 
#define check_e(A)             if(!(A)) { log_error(""); errno=0; goto error; }
#define check_s(A)             if(!(A)) { errno=0; goto error; }
#define check_mem(A)           check((A), "Out of memory.")
#define check_debug(A, M, ...) if(!(A)) { debug(M, ##__VA_ARGS__); errno=0; goto error; } 
#define sentinel(M, ...)       { log_error(M, ##__VA_ARGS__); errno=0; goto error; } 

#endif
