#!/bin/bash

gcc -o imgpreview \
	-O3 \
	-Wall \
	-Wextra \
	-Wno-unused-parameter \
	-Wno-unused-function \
	-Wno-unused-variable \
	-lm \
	main.c

strip imgpreview
