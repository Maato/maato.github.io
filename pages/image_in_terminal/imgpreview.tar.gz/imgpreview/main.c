#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <assert.h>

#include "lib/_xterm256.c"

#define STB_IMAGE_IMPLEMENTATION
#include "lib/stb_image.h"

typedef struct {
	unsigned char r, g, b, a;
} RGBA;

typedef struct {
	int r, g, b, a;
} iRGBA;

typedef struct {
	int w, h;
	RGBA *data;
} RGBAImage;

typedef struct {
	int w, h;
	iRGBA *data;
} iRGBAImage;

static inline RGBA rgba_image_color_at(RGBAImage *image, int x, int y) {
	RGBA result = { 0 };
	if(x < 0 || x >= image->w || y < 0 || y >= image->h) {
		return result;
	}
	return image->data[x + y * image->w];
}

static inline iRGBA image_color_at(iRGBAImage *image, int x, int y) {
	iRGBA result = { 0 };
	if(x < 0 || x >= image->w || y < 0 || y >= image->h) {
		return result;
	}
	return image->data[x + y * image->w];
}

static RGBAImage load_image(const char *filename) {
	RGBAImage result = { 0 };
	int channels = 0;
	result.data = (RGBA*)stbi_load(filename, &result.w, &result.h, &channels, 4);
	return result;
}

typedef struct {
	float minx, maxx;
	float miny, maxy;
} Rect;

static inline float rect_overlap_area(Rect *a, Rect *b) {
	Rect c;
	c.minx = b->minx > a->minx ? b->minx : a->minx;
	c.maxx = b->maxx < a->maxx ? b->maxx : a->maxx;
	c.miny = b->miny > a->miny ? b->miny : a->miny;
	c.maxy = b->maxy < a->maxy ? b->maxy : a->maxy;
	float w = c.maxx - c.minx;
	float h = c.maxy - c.miny;
	return w * h;
}

static iRGBAImage resize_image(RGBAImage *source, int new_width, int new_height) {

	iRGBAImage result = { 0 };
	result.w = new_width;
	result.h = new_height;
	result.data = malloc(sizeof(iRGBA) * new_width * new_height);

	float source_w = source->w;
	float source_h = source->h;
	float source_p_w = 1.0f / source_w;
	float source_p_h = 1.0f / source_h;

	float result_w = result.w;
	float result_h = result.h;

	float window_w = source_w / result_w;
	float window_h = source_h / result_h;

	iRGBA *dest = result.data;
	for(int y = 0; y < result.h; y++) {
		for(int x = 0; x < result.w; x++) {
			float window_x = x * window_w;
			float window_y = y * window_h;

			int win_left   = floorf(window_x);
			int win_right  = floorf(window_x + window_w);
			int win_top    = floorf(window_y);
			int win_bottom = floorf(window_y + window_h);

			float divider = 0.0f;
			float r_sum = 0;
			float g_sum = 0;
			float b_sum = 0;

			Rect window_area = {
				window_x, window_x + window_w,
				window_y, window_y + window_h
			};

			for(int sy = win_top; sy <= win_bottom; sy++) {
				for(int sx = win_left; sx <= win_right; sx++) {
					RGBA col = rgba_image_color_at(source, sx, sy);

					Rect pixel_area = {
						sx, sx + 1,
						sy, sy + 1
					};

					float weight = rect_overlap_area(&pixel_area, &window_area);
					r_sum += col.r * weight * (col.a / 255.0f);
					g_sum += col.g * weight * (col.a / 255.0f);
					b_sum += col.b * weight * (col.a / 255.0f);
					divider += weight;
				}
			}

			iRGBA col = {
				r_sum / divider,
				g_sum / divider,
				b_sum / divider,
				0xff };
			dest[x + y * result.w] = col;
		}
	}

	return result;
}

static void dither_image(iRGBAImage *result) {
	iRGBA *pixels = result->data;

	for(int y = 0; y < result->h; y++) {
		for(int x = 0; x < result->w; x++) {
			iRGBA old = pixels[x + y * result->w];
			int c = xterm256_rgb_to_term(old.r, old.g, old.b);
			rgb_t _new = xterm256_term_to_rgb(c);
			iRGBA new = { _new.r, _new.g, _new.b, 0xff };
			pixels[x + y * result->w] = new;

			float r_error = old.r - new.r;
			float g_error = old.g - new.g;
			float b_error = old.b - new.b;

			float q_sum = r_error + g_error + b_error;
			r_error = q_sum / 3.0f;
			g_error = q_sum / 3.0f;
			b_error = q_sum / 3.0f;

			if(x < result->w-1) {
				pixels[(x+1) + (y+0)*result->w].r = roundf(pixels[(x+1) + (y+0)*result->w].r + r_error * 7.0f / 16.0f);
				pixels[(x+1) + (y+0)*result->w].g = roundf(pixels[(x+1) + (y+0)*result->w].g + g_error * 7.0f / 16.0f);
				pixels[(x+1) + (y+0)*result->w].b = roundf(pixels[(x+1) + (y+0)*result->w].b + b_error * 7.0f / 16.0f);
			}

			if(x > 0 && y < result->h-1) {
				pixels[(x-1) + (y+1)*result->w].r = roundf(pixels[(x-1) + (y+1)*result->w].r + r_error * 3.0f / 16.0f);
				pixels[(x-1) + (y+1)*result->w].g = roundf(pixels[(x-1) + (y+1)*result->w].g + g_error * 3.0f / 16.0f);
				pixels[(x-1) + (y+1)*result->w].b = roundf(pixels[(x-1) + (y+1)*result->w].b + b_error * 3.0f / 16.0f);
			}

			if(y < result->h-1) {
				pixels[(x+0) + (y+1)*result->w].r = roundf(pixels[(x+0) + (y+1)*result->w].r + r_error * 5.0f / 16.0f);
				pixels[(x+0) + (y+1)*result->w].g = roundf(pixels[(x+0) + (y+1)*result->w].g + g_error * 5.0f / 16.0f);
				pixels[(x+0) + (y+1)*result->w].b = roundf(pixels[(x+0) + (y+1)*result->w].b + b_error * 5.0f / 16.0f);
			}

			if(x < result->w-1 && y < result->h -1) {
				pixels[(x+1) + (y+1)*result->w].r = roundf(pixels[(x+1) + (y+1)*result->w].r + r_error * 1.0f / 16.0f);
				pixels[(x+1) + (y+1)*result->w].g = roundf(pixels[(x+1) + (y+1)*result->w].g + g_error * 1.0f / 16.0f);
				pixels[(x+1) + (y+1)*result->w].b = roundf(pixels[(x+1) + (y+1)*result->w].b + b_error * 1.0f / 16.0f);
			}
		}
	}
}

static void print_default(iRGBAImage *image) {
 	int color_cache = -1;
	for(int y = 0; y < image->h; y += 1) {
		for(int x = 0; x < image->w; x += 1) {
			iRGBA *in = &image->data[x + y * image->w];
			int term_color = xterm256_rgb_to_term(in->r, in->g, in->b);

			if(color_cache != term_color) {
				printf("\e[48;5;%dm ", term_color);
				color_cache = term_color;
			} else {
				printf(" ");
			}
		}
		color_cache = -1;
		printf("\e[0m\n");
	}
}

static void print_1x2(iRGBAImage *image) {
	for(int y = 0; y < image->h; y += 2) {
		for(int x = 0; x < image->w; x += 1) {
			iRGBA *fg_in = &image->data[x + y * image->w];
			iRGBA *bg_in = &image->data[x + (y+1) * image->w];
			int fg_color = xterm256_rgb_to_term(fg_in->r, fg_in->g, fg_in->b);
			int bg_color = xterm256_rgb_to_term(bg_in->r, bg_in->g, bg_in->b);
			printf("\e[48;5;%dm\e[38;5;%dm▀", bg_color, fg_color);
		}
		printf("\e[0m\n");
	}
}

static void set_color(int fg_color, int bg_color) {
	printf("\e[38;5;%dm\e[48;5;%dm", fg_color, bg_color);
}

static void print_four_pixels_per_glyph(iRGBAImage *image) {
	for(int y = 0; y < image->h; y += 2) {
		for(int x = 0; x < image->w; x += 2) {
			iRGBA tl = image_color_at(image, x,   y);
			iRGBA tr = image_color_at(image, x+1, y);
			iRGBA bl = image_color_at(image, x,   y+1);
			iRGBA br = image_color_at(image, x+1, y+1);

			int c1 = xterm256_rgb_to_term(tl.r, tl.g, tl.b);
			int c2 = xterm256_rgb_to_term(tr.r, tr.g, tr.b);
			int c3 = xterm256_rgb_to_term(bl.r, bl.g, bl.b);
			int c4 = xterm256_rgb_to_term(br.r, br.g, br.b);

			if(c1 == c2 && c2 == c3 && c1 != c4) {
				set_color(c1, c4);
				printf("▛");
			} else if(c2 == c3 && c3 == c4 && c1 != c2) {
				set_color(c4, c1);
				printf("▟");
			} else if(c3 == c4 && c4 == c1 && c1 != c2) {
				set_color(c1, c2);
				printf("▙");
			} else if(c1 == c2 && c2 == c4 && c1 != c3) {
				set_color(c1, c3);
				printf("▜");
			} else if(c1 == c2 && c3 == c4) {
				set_color(c1, c3);
				printf("▀");
			} else if(c1 == c3 && c2 == c4) {
				set_color(c1, c2);
				printf("▌");
			} else if(c1 == c4 && c2 == c3) {
				set_color(c1, c2);
				printf("▚");
			} else {
				iRGBA top = { (tl.r + tr.r) / 2, (tl.g + tr.g) / 2, (tl.b + tr.b) / 2, 0xff };
				iRGBA btm = { (bl.r + br.r) / 2, (bl.g + br.g) / 2, (bl.b + br.b) / 2, 0xff };
				int top_id = xterm256_rgb_to_term(top.r, top.g, top.b);
				int btm_id = xterm256_rgb_to_term(btm.r, btm.g, btm.b);
				set_color(top_id, btm_id);
				printf("▀");
			}

		}
		printf("\e[0m\n");
	}
}

static void print_usage() {
	printf("Usage: %s [OPTION] [FILE]\n", "imgpreview");
	printf("Print a color preview of the image to the terminal using unicode characters.\n");
	printf("\n");
	printf("  -s,  --simple      do not use unicode characters\n");
	printf("  -d,  --double      double resolution by using the upper half block unicode character\n");
	printf("  -q,  --quadruple   quadruple the resolution by using more unicode characters\n");
	printf("  -qd, --dither      same as --quadruple but with dithering added\n");
}

int main(int argc, char *argv[]) {
	if(argc != 3) {
		print_usage();
		return EXIT_FAILURE;
	} else {
		xterm256_init();
		RGBAImage image = load_image(argv[2]);
		if(image.data) {

			struct winsize w;
			ioctl(0, TIOCGWINSZ, &w);

			int columns = w.ws_col;
			int rows    = ((image.h * columns) / (float)image.w) * (7.0f / 13.0f);

			if(strcmp(argv[1], "-s") == 0 || strcmp(argv[1], "--simple") == 0) {
				iRGBAImage resized_image = resize_image(&image, columns, rows);
				if(resized_image.data) {
					print_default(&resized_image);
				}
			} else if(strcmp(argv[1], "-d") == 0 || strcmp(argv[1], "--double") == 0) {
				iRGBAImage resized_image = resize_image(&image, columns, rows*2);
				if(resized_image.data) {
					print_1x2(&resized_image);
				}
			} else if(strcmp(argv[1], "-q") == 0 || strcmp(argv[1], "--quadruple") == 0) {
				iRGBAImage resized_image = resize_image(&image, columns*2, rows*2);
				if(resized_image.data) {
					print_four_pixels_per_glyph(&resized_image);
				}
			} else if(strcmp(argv[1], "-qd") == 0 || strcmp(argv[1], "--dither") == 0) {
				iRGBAImage resized_image = resize_image(&image, columns*2, rows*2);
				if(resized_image.data) {
					dither_image(&resized_image);
					print_four_pixels_per_glyph(&resized_image);
				}
			} else {
				print_usage();
				return EXIT_FAILURE;
			}
		} else {
			fprintf(stderr,"Failed to load image\n");
			return EXIT_FAILURE;
		}
	}
	return EXIT_SUCCESS;
}

