#include <cstdlib>
#include <cstring>
#include <vector>
#include <cstdarg>
#include <SDL_mixer.h>

#include "commonmath.h"
#include "gamestate.h"
#include "options.h"
#include "system.h"
#include "common.h"
#include "properties.h"
#include "matrix.h"
#include "resources.h"
#include "commongl.h"
#include "texref.h"

using namespace std;

uint64_t mFrame = 0;


uint64_t mSandDestroyed = 0;
uint64_t mRockDestroyed = 0;
uint64_t mHardRockDestroyed = 0;
uint64_t mMagmaDestroyed = 0;

uint64_t mUnpayedSand = 0;
uint64_t mUnpayedRock = 0;
uint64_t mUnpayedHardRock = 0;
uint64_t mUnpayedMagma = 0;

uint32_t mSandCollected = 0;
uint32_t mRockCollected = 0;
uint32_t mHardRockCollected = 0;
uint32_t mLavaCollected = 0;

Vector mPlanetCenter = Vector::Zero;

#define SAND_SPAWN_AMOUNT 4000
#define ROCK_SPAWN_AMOUNT 4000
#define LAVA_SPAWN_AMOUNT 4000
#define HARDROCK_SPAWN_AMOUNT 8000

TexRef mSandTex(NULL);
TexRef mRockTex(NULL);
TexRef mHardRockTex(NULL);
TexRef mLavaTex(NULL);
TexRef mTitleScreen(NULL);

Mix_Chunk * mExplode1 = NULL;
Mix_Chunk * mPickup1 = NULL;
Mix_Chunk * mMission1 = NULL;
Mix_Music * mMusic = NULL;

int channels_in_use = 0;

struct QuadRegion;

int mydiv(int x, int y) {
	if(x >= 0) return x / y;
	return ((x-y+1) / y);
}

void channel_finished_cb(int channel)
{
	channels_in_use--;
}

int loop_sound(Mix_Chunk * chunk)
{
	int result = 0;
	if(chunk != NULL) {
		if((result = Mix_PlayChannel(-1, chunk, -1)) == -1) {
			fprintf(stderr, "Mix_PlayChannel: %s\n", Mix_GetError());
		}
	}
	return result;
}

void play_sound(Mix_Chunk * chunk)
{
	if(channels_in_use >= 7 && chunk != mMission1) {
		return;
	}
	if(chunk != NULL) {
		if(Mix_PlayChannel(-1, chunk, 0) == -1) {
			fprintf(stderr, "Mix_PlayChannel: %s\n", Mix_GetError());
		} else {
			channels_in_use++;
		}
	}
}

Mix_Chunk * load_wav(const char * name)
{
	FILE * file = Platform::OpenResource(name);
	if(file == NULL) {
		fprintf(stderr, "Failed to open file: %s\n", name);
		return NULL;
	}
	Mix_Chunk * chunk = Mix_LoadWAV_RW(SDL_RWFromFP(file, 1), 1);
	if(chunk == NULL) {
		fprintf(stderr, "Failed to load wav: %s\n", name);
		return NULL;
	}

	return chunk;
}

struct GameObject {
	bool Deleted;
	uint64_t LastUpdateAt;
	Vector Pos;
	Vector OldPos;
	Vector Vel;
	int Width, Height;
	QuadRegion * Region;

	GameObject(Vector pos, int width, int height) :
		Deleted(false),
		Pos(pos), OldPos(pos), Width(width), Height(height),
		Region(NULL),
		LastUpdateAt(0)
	{
	}
	virtual ~GameObject() {}
	virtual void Draw() = 0;
	virtual void Update(float) = 0;

	void SetPos(Vector newPos) {
		OldPos = Pos;
		Pos = newPos;
		UpdateRegion();
	}
	void UpdateRegion();
};

#define PLAYER_ACCEL 500.0f

static TexRef mRedBulletTex(NULL);
static TexRef mBlueBulletTex(NULL);
static TexRef mPurpleBulletTex(NULL);
static TexRef mGreenBulletTex(NULL);

struct WorldBlock {
	int X, Y;
	uint32_t * Data;
	GLuint TexId;
	uint32_t TexPoolId;
	uint64_t LastUpdateAt;
	bool GenerationQueued;
	bool Ready;
	bool Dirty;

	WorldBlock(int x, int y) :
		X(x), Y(y),
		Data((uint32_t*)malloc(sizeof(uint32_t) * 256 * 256)),
		TexId(0xFFFFFFFFu),
		GenerationQueued(false),
		Ready(false),
		Dirty(false)
	{
		memset(Data, 0x0, sizeof(uint32_t) * 256 * 256);
	}

	~WorldBlock() {
		free(Data);
		Data = NULL;
	}

	void Draw() {
		if(TexId == 0xFFFFFFFFu) {
			return;
		}
		if(LastUpdateAt != mFrame) {
			// fprintf(stdout, "Bailing because lastUpdate was too long ago\n");
			return;
		}


		// fprintf(stdout, "Trying to render\n");
		Vector position = Vector(256.0f * X, 256.0f * Y);
		Vector size = Vector(256.0f, 256.0f);
		Quad vertices = Quad(position, size);
		Quad texcoords;
		texcoords.TopLeft = Vector::Zero;
		texcoords.TopRight = Vector(1.0f, 0.0f);
		texcoords.BottomLeft = Vector(0.0f, 1.0f);
		texcoords.BottomRight = Vector(1.0f, 1.0f);

		// fprintf(stdout, "Using texid: %u\n", TexId);
		glBindTexture(GL_TEXTURE_2D, TexId);
		gl_TextureProg->VertexPointer((void*)&vertices);
		gl_TextureProg->TexCoordPointer((void*)&texcoords);
		gl_TextureProg->Use();
		glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
	}
};

struct MissionLog {
	CompiledText * Lines[6];
	float Age[6];
	MissionLog() {
		for(int i = 0; i < 6; i++) {
			Lines[i] = new CompiledText("img/font.png");
			Lines[i]->SetText("");
		}
	}
	~MissionLog() {
		for(int i = 0; i < 6; i++) {
			delete Lines[i];
			Lines[i] = NULL;
		}
	}

	void Update(float dt) {
		for(int i = 0; i < 6; i++) {
			Age[i] += dt;
		}
	}

	void Draw() {
		Vector start = Vector(270.0f, 638.0f);
		for(int i = 0; i < 6; i++) {

			if(Age[i] < 4.0f) {
				float alpha = 1.0f - Age[i] / 4.0f;
				DrawFilledRect(start-Vector(2.0f, 0.0f), Vector(488.0f, 15.0f), Color(0.0f, 0.8f, 0.0f, alpha));
			}

			Lines[i]->Draw(start);
			start += Vector(0.0f, 21.0f);
		}
	}

	void AddLine(const char * format, ...) {
		char buffer[512];
		va_list vl;
		va_start(vl, format);
		vsnprintf(buffer, 512, format, vl);
		va_end(vl);

		Scroll();
		Lines[5]->SetText(buffer);
		Age[5] = 0.0f;
	}

	void Scroll() {
		CompiledText * temp = Lines[0];
		float tempAge = Age[0];
		Lines[0] = Lines[1]; Age[0] = Age[1];
		Lines[1] = Lines[2]; Age[1] = Age[2];
		Lines[2] = Lines[3]; Age[2] = Age[3];
		Lines[3] = Lines[4]; Age[3] = Age[4];
		Lines[4] = Lines[5]; Age[4] = Age[5];
		Lines[5] = temp;     Age[5] = tempAge;
	}
};

MissionLog * mMissionLog = NULL;

static float interpolate(float a, float b, float x)
{
	float ft = x * 3.1415f;
	float f = (1.0f - cosf(ft)) * 0.5f;

	return a * (1.0f - f) + b * f;
}

 static float intnoise(int x) {
 	x = (x << 13) ^ x;
	return ( 1.0 - ( (x * (x * x * 15731 + 789221) + 1376312589) & 0x7fffffff) / 1073741824.0);
}

inline double findnoise2(int x, int y)
{
	int n= x + y * 43;
	n = (n<<13) ^ n;
	int nn = (n * (n * n * 60493 + 19990303) + 1376312589) & 0x7fffffff;
	return 1.0 -((double)nn/1073741824.0);
}


static float getval(/*float noise[8][8], */int32_t x, int32_t y)
{
	/*int32_t xl = x >> 5;
	int32_t xr = xl+1;
	int32_t yt = y >> 5;
	int32_t yb = yt+1;*/
	
	float xlt = findnoise2(x,     y);//noise[yt&3][xl&3];
	float xrt = findnoise2(x+1,   y);//noise[yt&3][xr&3];
	float xlb = findnoise2(x,   y+1);//noise[yb&3][xl&3];
	float xrb = findnoise2(x+1, y+1);//noise[yb&3][xr&3];
	
	float i1 = interpolate(xlt, xrt, (x & 31) / 31.0f);
	float i2 = interpolate(xlb, xrb, (x & 31) / 31.0f);

	return interpolate(i1, i2, (y & 31) / 31.0f);
}


bool contains_planet(int x, int y) {
	float val = getval(x, y);
	uint8_t byte = 0;

	double boundary = 0.75;
	if(val > boundary) {
		byte = 255;
	}
	if(getval(x-1,y-1) > boundary ||
		getval(x, y-1) > boundary ||
		getval(x-1,y) > boundary)
	{
		byte = 0;
	}
	if(x == 0 && y == 0) {
		return true;
	}
	return byte == 255;
}


int getmod(float degrees, float frequency, float amplitude) {
	float val = degrees / frequency;
	float a = intnoise((int)floorf(val));
	float b = intnoise((int)ceilf(val));
	double value = interpolate(a, b, val - (int)floorf(val));
	return rintf(value * amplitude);
}

#define RGB(r,g,b) ((0xFF << 24) | (b << 16) | (g << 8) | (r))
#define RGBX(r) ((0xFF << 24) | ((r & 0xFF) << 16) | (((r >> 8) & 0xFF) << 8) | (r >> 16))

uint32_t mRockColors[8] = {
	RGBX(0x5c5c5cu), 
	RGBX(0x595959u),
	RGBX(0x545454u),
	RGBX(0x5a5a5au),
	RGBX(0x3e3d38u),
	RGBX(0x4d5154u),
	RGBX(0x5c5c5cu), 
	RGBX(0x595959u)
};

uint32_t mSandColors[8] = {
	RGB(138u, 97u, 52u),
	RGB(113u, 85u, 86u),
	RGB(93u, 69u, 24u),
	RGB(73u, 52u, 12u),
	RGB(191u, 143u, 97u),
	RGB(152u, 114u, 75u),
	RGB(138u, 97u, 52u),
	RGB(113u, 85u, 86u)
};

uint32_t mHardRockColors[8] = {
	RGBX(0x3e3e3eu),
	RGBX(0x383838u),
	RGBX(0x414141u),
	RGBX(0x454545u),
	RGBX(0x565656u),
	RGBX(0x404040u),
	RGBX(0x3e3e3eu),
	RGBX(0x383838u)
};

uint32_t mLavaColors[8] = {
	RGBX(0xdb611fu),
	RGBX(0xcb4c04u),
	RGBX(0xc74c0du),
	RGBX(0xe86b0bu),
	RGBX(0xd25b1au),
	RGBX(0xed7c00u),
	RGBX(0xdb611fu),
	RGBX(0xcb4c04u)
};

bool isLava(uint32_t color) {
	for(int i = 0; i < 8; i++) {
		if((color & 0x00FFFFFF) == (mLavaColors[i] & 0x00FFFFFF)) {
			return true;
		}
	}
	return false;
}

bool isHardRock(uint32_t color) {
	for(int i = 0; i < 8; i++) {
		if((color & 0x00FFFFFF) == (mHardRockColors[i] & 0x00FFFFFF)) {
			return true;
		}
	}
	return false;
}

bool isSand(uint32_t color) {
	for(int i = 0; i < 8; i++) {
		if((color & 0x00FFFFFF) == (mSandColors[i] & 0x00FFFFFF)) {
			return true;
		}
	}
	return false;
}

bool isRock(uint32_t color) {
	for(int i = 0; i < 8; i++) {
		if((color & 0x00FFFFFF) == (mRockColors[i] & 0x00FFFFFF)) {
			return true;
		}
	}
	return false;
}

#include <queue>
#include <pthread.h>
struct Generator {
	pthread_t Thread;
	pthread_mutex_t Lock;
	pthread_cond_t Signal;
	std::queue<WorldBlock*> mJobs;
	bool Running;

	static void * worker_helper(void * user_data) {
		Generator * g = (Generator*)user_data;
		g->Run();
		return NULL;
	}

	Generator() {

		Running = true;
		pthread_mutex_init(&Lock, NULL);
		pthread_cond_init(&Signal, NULL);
		pthread_create(&Thread, NULL, &worker_helper, this);
	}
	~Generator() {
		Running = false;
		pthread_mutex_lock(&Lock);
		pthread_cond_signal(&Signal);
		pthread_mutex_unlock(&Lock);
	}


	void Generate(WorldBlock * block) {
		int wcx = mydiv(block->X, 8);
		int wcy = mydiv(block->Y, 8);
		wcx *= 256 * 8;
		wcy *= 256 * 8;

		Vector wcenter;
		wcenter.X = wcx + 1024.0f;
		wcenter.Y = wcy + 1024.0f;


		Vector block_radius = Vector(128.0f, 128.0f);
		Vector block_center = Vector(block->X * 256, block->Y * 256) + block_radius;

		if(wcenter.GetDist(block_center) - block_radius.GetLength() > 1124) {
			block->GenerationQueued = false;
			block->Ready = true;
			return;
		}



		int rand_seed = findnoise2(wcx, wcy) * 600;

		// fprintf(stdout, "%d, %d\n", block->X, block->Y);
		// fprintf(stdout, "%.2f, %.2f\n", wcenter.X, wcenter.Y);

		for(int y = 0; y < 256; y++) {
			for(int x = 0; x < 256; x++) {
				int world_pix_x = x + block->X * 256;
				int world_pix_y = y + block->Y * 256;
				Vector world_pix = Vector(world_pix_x, world_pix_y) - wcenter;

				//fprintf(stdout, "wc: %.2f, %.2f  - %.2f, %.2f\n", wcenter.X, wcenter.Y, world_pix.X, world_pix.Y);

				float dist = world_pix.GetLength();

				if(dist > 1124) {
					block->Data[x + y * 256] = 0x00000000;
					continue;
				}

				uint32_t color = 0x00000000;

				int rnd = rand();

				float angle = atan2f(world_pix.Y, world_pix.X);
				float degrees = angle / M_PI * 180.0f;
				int lavamod = getmod(degrees+rand_seed, 1.0f, 2.5f) + getmod(degrees+1920.0f+rand_seed, 10.0f, 10.0f);

				if(dist < 128  - lavamod) {
					color = mLavaColors[rnd & 7];
				} else if(dist < 300 - (getmod(degrees+rand_seed, 1.5f, 5.0f) + getmod(degrees+720.0f+rand_seed, 10.0f, 30.0f))) {
					color = mHardRockColors[rnd & 7];
				} else if(dist < 600 - (getmod(degrees+rand_seed, 2.0f, 20.0f) + getmod(degrees+360.0f+rand_seed, 8.0f, 40.0f))) {
					color = mRockColors[rnd & 7];
				} else if(dist < 944 - (getmod(degrees+rand_seed, 5.0f, 60.0f) + getmod(degrees+1080.0f+rand_seed, 1.5f, 10.0f))) {
					color = mSandColors[rnd & 7];
				} else if(dist < 950) {
					if(rnd % 3 == 0) color = RGBX(0x03228);
					if(rnd % 3 == 1) color = RGBX(0x031b7b);
					if(rnd % 3 == 2) color = RGBX(0x051b79);
				}

				block->Data[x + y * 256] = color;
			}
		}
		block->GenerationQueued = false;
		block->Ready = true;
	}

	void Run() {
		do {
			WorldBlock * block = NULL;
			pthread_mutex_lock(&Lock);
			{
				while(mJobs.empty()) {
					pthread_cond_wait(&Signal, &Lock);
				}
				block = mJobs.front();
				mJobs.pop();
			}
			pthread_mutex_unlock(&Lock);

			Generate(block);

		} while(Running);
	}

	void Enqueue(WorldBlock * block) {
		pthread_mutex_lock(&Lock);
		mJobs.push(block);
		pthread_cond_signal(&Signal);
		pthread_mutex_unlock(&Lock);
	}
};


struct QuadRegion {
	int Top, Left;
	int Width, Height;
	QuadRegion ** TopMost;
	QuadRegion * Parent;
	QuadRegion * Tl;
	QuadRegion * Tr;
	QuadRegion * Bl;
	QuadRegion * Br;
	int FilledSlots;
	WorldBlock * Block;
	std::vector<GameObject*> Objects;

	QuadRegion(QuadRegion ** topMost, QuadRegion * parent, int left, int top, int width, int height, QuadRegion * tl, QuadRegion * tr, QuadRegion * bl, QuadRegion * br) :
		TopMost(topMost),
		Left(left), Top(top), Width(width), Height(height),
		Parent(parent), Tl(tl), Tr(tr), Bl(bl), Br(br),
		FilledSlots(0),
		Block(NULL)
	{
	}

	~QuadRegion() {
		if(Tl) delete Tl;
		if(Tr) delete Tr;
		if(Bl) delete Bl;
		if(Br) delete Br;
		if(Block) delete Block;
		foreach(it, Objects) {
			if(*it != NULL) {
				delete (*it);
			}
		}
	}

	bool Fits(GameObject * go) {
		return go->Pos.X >= Left && go->Pos.Y >= Top &&
			go->Pos.X + go->Width < Left + Width &&
			go->Pos.Y + go->Height < Top + Height;
	}

	bool Fits(int L, int T, int W, int H) {
		return L >= Left && T >= Top &&
			L + W < Left + Width &&
			T + H < Top + Height;
	}

	static bool Fits(int L, int T, int W, int H, GameObject * go)
	{
		return go->Pos.X >= L && go->Pos.Y >= T &&
			go->Pos.X + go->Width < L + W &&
			go->Pos.Y + go->Height < T + H;
	}

	bool Contains(int l, int t, int w, int h) {
		if(l >= Left + Width) return false;
		if(t >= Top + Height) return false;
		if(l + w < Left) return false;
		if(t + h < Top) return false;
		return true;
	}

	bool Contains(int l, int t, int w, int h, GameObject * go) {
		if(go->Pos.X >= l + w) return false;
		if(go->Pos.Y >= t + h) return false;
		if(go->Pos.X + go->Width < l) return false;
		if(go->Pos.Y + go->Height < t) return false;
		return true;
	}

	void CreateTl()	{
		if(Tl != NULL) return;
		Tl = new QuadRegion(TopMost, this, Left, Top, Width / 2, Height / 2, NULL , NULL , NULL, NULL);
	}

	void CreateTr() {
		if(Tr != NULL) return;
		Tr = new QuadRegion(TopMost, this, Left + Width / 2, Top, Width / 2, Height / 2, NULL , NULL , NULL, NULL);
	}

	void CreateBl() {
		if(Bl != NULL) return;
		Bl = new QuadRegion(TopMost, this, Left, Top + Height / 2, Width / 2, Height / 2, NULL , NULL , NULL, NULL);
	}

	void CreateBr() {
		if(Br != NULL) return;
		Br = new QuadRegion(TopMost, this, Left + Width / 2, Top + Height / 2, Width / 2, Height / 2, NULL , NULL , NULL, NULL);
	}

	void Move(GameObject * go) {
		if(!Remove(go)) {
			fprintf(stderr, "Removing gameobject failed\n");
			assert(false);
		}
		Add(go);
	}

	void AddBlock(WorldBlock * block) {
		if(Left == block->X * 256 && Top == block->Y * 256 && Width == 256 && Height == 256) {
			assert(Block == NULL);
			Block = block;
			return;
		}

		//assert(!(Width == 256 && Height == 256));

		int bx = block->X * 256;
		int by = block->Y * 256;

		if(bx >= Left && by >= Top && bx < Left + Width / 2 && by < Top + Height / 2) {
			CreateTl(); Tl->AddBlock(block);
		} else if(bx < Left + Width && by >= Top && bx >= Left + Width / 2 && by < Top + Height / 2) {
			CreateTr(); Tr->AddBlock(block);
		} else if(bx >= Left && by < Top + Height && bx < Left + Width / 2 && by >= Top + Height / 2) {
			CreateBl(); Bl->AddBlock(block);
		} else if(bx < Left + Width && by < Top + Height && bx >= Left + Width / 2 && by >= Top + Height / 2) {
			CreateBr(); Br->AddBlock(block);
		} else if(bx > Left && by <= Top) {
			fprintf(stdout, "Expanding right and up\n");
			Parent = new QuadRegion(TopMost, NULL, Left, Top - Height, Width * 2, Height * 2, NULL, NULL, this, NULL);
			*TopMost = Parent;
		} else if(bx > Left && bx > Top) {
			fprintf(stdout, "Expanding right and down\n");
			Parent = new QuadRegion(TopMost, NULL, Left, Top, Width * 2, Height * 2, this, NULL, NULL, NULL);
			*TopMost = Parent;
		} else if(bx <= Left && by <= Top) {
			fprintf(stdout, "Expanding left and up\n");
			Parent = new QuadRegion(TopMost, NULL, Left - Width, Top - Height, Width * 2, Height * 2, NULL, NULL, NULL, this);
			*TopMost = Parent;
		} else if(bx <= Left && by > Top) {
			fprintf(stdout, "Expanding left and down\n");
			Parent = new QuadRegion(TopMost, NULL, Left - Width, Top, Width * 2, Width * 2, NULL, this, NULL, NULL);
			*TopMost = Parent;
		} else {
			assert(false);
		}
	}

	void Add(GameObject * go) {
		/* Create a new parent if the */
		if(!Fits(go)) {
			// fprintf(stdout, "The object doesn't fit\n");
			// fprintf(stdout, "%d, %d, %d, %d\n", Left, Top, Width, Height);
			// fprintf(stdout, "%d, %d, %d, %d\n", (int)go->Pos.X, (int)go->Pos.Y, go->Width, go->Height);
			if(Parent == NULL) {

				bool expandRight = (go->Pos.X + go->Width >= Left + Width);
				bool expandLeft = !expandRight;//(go->Pos.X < Left);
				bool expandUp = (go->Pos.Y <= Top);
				bool expandDown = !expandUp;//(go->Pos.Y + go->Height > Top + Height);

				bool expandRightUp =  expandRight && expandUp;
				bool expandLeftUp = expandLeft && expandUp;//Contains(Left - Width, Top - Height, Width * 2, Height * 2, go);
				bool expandRightDown = expandRight && expandDown;//Contains(Left, Top, Width * 2, Height * 2, go);
				bool expandLeftDown = expandLeft && expandDown;//Contains(Left - Width, Top, Width * 2, Height * 2, go);

				if(expandRightUp) { /* This will become bottomleft */
					fprintf(stdout, "Expanding right and up\n");
					Parent = new QuadRegion(TopMost, NULL, Left, Top - Height, Width * 2, Height * 2, NULL, NULL, this, NULL);
				} else if(expandLeftUp) { /* This will become bottomright */
					fprintf(stdout, "Expanding left and up\n");
					Parent = new QuadRegion(TopMost, NULL, Left - Width, Top - Height, Width * 2, Height * 2, NULL, NULL, NULL, this);
				} else if(expandRightDown) { /* This will become topleft */
					fprintf(stdout, "Expanding right and down\n");
					Parent = new QuadRegion(TopMost, NULL, Left, Top, Width * 2, Height * 2, this, NULL, NULL, NULL);
				} else if(expandLeftDown) { /* This will become topright */
					fprintf(stdout, "Expanding left and down\n");
					Parent = new QuadRegion(TopMost, NULL, Left - Width, Top, Width * 2, Width * 2, NULL, this, NULL, NULL);
				} else {
					assert(false);
				}
				*TopMost = Parent;
				// fprintf(stdout, "Adding to created parent\n");
				Parent->Add(go);
				return;
			} else {
				Parent->Add(go);
				return;
			}
		} else {
			// fprintf(stdout, "The object fits\n");
			// fprintf(stdout, "%d, %d, %d, %d\n", Left, Top, Width, Height);
			// fprintf(stdout, "%d, %d, %d, %d\n", (int)go->Pos.X, (int)go->Pos.Y, go->Width, go->Height);
		}

		/* The object fits in this region, but we would like it to be
		   in one of the lower regions, so we'll check that first */

		int hwidth = Width / 2;
		int hheight = Height / 2;


		/* Minimum tile size is 256 */
		if(Width == 256 || Height == 256) {
			// fprintf(stdout, "Adding to THIS\n");
			FilledSlots += 1;
			go->Region = this;
			for(unsigned int i = 0; i < Objects.size(); i++) {
				if(Objects[i] == NULL) {
					Objects[i] = go;
					return;
				}
			}
			Objects.push_back(go);
			return;
		}

		/* See if the gameobject fits in a subregion, if it doesn't 
		 add it to this region */
		if(Fits(Left, Top, hwidth, hheight, go)) {
			CreateTl();
			// fprintf(stdout, "Adding to TL\n");
			Tl->Add(go);
		} else if(Fits(Left + hwidth, Top, hwidth, hheight, go)) {
			CreateTr();
			// fprintf(stdout, "Adding to TR\n");
			Tr->Add(go);	
		} else if(Fits(Left, Top + hheight, hwidth, hheight, go)) {
			CreateBl();
			// fprintf(stdout, "Adding to BL\n");
			Bl->Add(go);
		} else if(Fits(Left + hwidth, Top + hheight, hwidth, hheight, go)) {
			CreateBr();
			// fprintf(stdout, "Adding to BR\n");
			Br->Add(go);
		} else {
			// fprintf(stdout, "Adding to THIS\n");
			FilledSlots += 1;
			go->Region = this;
			for(unsigned int i = 0; i < Objects.size(); i++) {
				if(Objects[i] == NULL) {
					Objects[i] = go;
					return;
				}
			}
			Objects.push_back(go);
		}
		return;
	}

	void GetBlocks(std::vector<WorldBlock*> & blocks, int left, int top, int width, int height) {
		if(Block != NULL) {
			blocks.push_back(Block);
			return;
		}
		if(!Contains(left, top, width, height)) {
			return;
		}
		if(Tl) Tl->GetBlocks(blocks, left, top, width, height);
		if(Tr) Tr->GetBlocks(blocks, left, top, width, height);
		if(Bl) Bl->GetBlocks(blocks, left, top, width, height);
		if(Br) Br->GetBlocks(blocks, left, top, width, height);
	}

	bool Remove(GameObject * go) {
		for(unsigned int i = 0; i < Objects.size(); i++) {
			if(Objects[i] == go) {
				Objects[i] = NULL;
				FilledSlots -= 1;
				return true;
			}
		}
		if(Tl && Tl->Remove(go)) return true;
		if(Tr && Tr->Remove(go)) return true;
		if(Bl && Bl->Remove(go)) return true;
		if(Br && Br->Remove(go)) return true;
		return false;
	}

	void Draw(int l, int t, int w, int h) {
		if(!Contains(l, t, w, h)) {
			return;
		}

		if(Block != NULL) {
			Block->Draw();
		}

		if(Tl) Tl->Draw(l, t, w, h);
		if(Tr) Tr->Draw(l, t, w, h);
		if(Bl) Bl->Draw(l, t, w, h);
		if(Br) Br->Draw(l, t, w, h);
		
		foreach(it, Objects) {
			if(*it != NULL) (*it)->Draw();
		}

		//DrawRect(Left, Top, Width, Height, Color(1.0f, 0.0f, 0.0f, 1.0f));
	}

	bool ShouldDelete() {
		return this != NULL && Block == NULL && Tl == NULL && Tr == NULL && Bl == NULL && Br == NULL && FilledSlots == 0;
	}

	void Update(float delta) {
		foreach(it, Objects) {
			if(*it != NULL && (*it)->LastUpdateAt != mFrame) {
				(*it)->LastUpdateAt = mFrame;
				(*it)->Update(delta);
			}
		}
		if(Tl) Tl->Update(delta);
		if(Tr) Tr->Update(delta);
		if(Bl) Bl->Update(delta);
		if(Br) Br->Update(delta);

		if(Tl->ShouldDelete()) { delete Tl; Tl = NULL; }
		if(Tr->ShouldDelete()) { delete Tr; Tr = NULL; }
		if(Bl->ShouldDelete()) { delete Bl; Bl = NULL; }
		if(Br->ShouldDelete()) { delete Br; Br = NULL; }
	}
};

// static bool overlaps(int L, int T, int W, int H, int l, int t, int w, int h) {
// 	if(l+w < L) return false;
// 	if(l > L+w) return false;
// 	if(t+h < T) return false;
// 	if(t > T+H) return false;
// 	return true;
// }

std::queue<GameObject*> mAddObjects;
std::queue<GameObject*> mDeleteObjects;

#define BULLET_BASIC 0
#define BULLET_ROCKBREAKER 1
#define BULLET_ROCKSOFTENER 2
#define BULLET_COREBUSTER 3

#define ORE_ROCK 0
#define ORE_SAND 1
#define ORE_HARDROCK 2
#define ORE_LAVA 3

struct Ore : public GameObject {
	float Age;
	int Type;

	Ore(int type, Vector pos) :
		GameObject(pos, 16, 16),
		Type(type)
	{
	}

	int CheckCollision(Vector newPos) {
		int result = 0;
		std::vector<WorldBlock*> blocks;
		Region->GetBlocks(blocks, newPos.X, newPos.Y, 5, 5);

		for(unsigned int i = 0; i < blocks.size(); i++) {
			int blockx = blocks[i]->X * 256;
			int blocky = blocks[i]->Y * 256;
			
			int bx = rintf(newPos.X);
			int by = rintf(newPos.Y);
			for(int y = -1; y < 1; y++) {
				for(int x = -1; x < 1; x++) {
					int dx = (bx + x) - blockx;
					int dy = (by + y) - blocky;

					if(dx >= 0 && dx < 256 && dy >= 0 && dy < 256) {
						uint32_t color = blocks[i]->Data[dx + dy * 256];
						if((color & 0xFF000000) != 0) {
							result += 1;
						}
					}
				}
			}
		}
		return result;
	}

	virtual void Update(float dt) {
		Age += dt;

		if(Age > 60.0f && !Deleted) {
			Deleted = true;
			mDeleteObjects.push(this);
		}

		if(CheckCollision(Pos + Vel * dt) == 0) {
			SetPos(Pos + Vel * dt);	
		} else {
			Vel = Vector::Zero;
		}
	}

	virtual void Draw() {
		Vector drawPos = Pos - Vector(Width/2, Height/2);
		switch(Type) {
			case ORE_ROCK: {
				DrawTexture(*mRockTex, drawPos, Vector(Width, Height));
				break;
			}
			case ORE_SAND: {
				DrawTexture(*mSandTex, drawPos, Vector(Width, Height));
				break;
			}
			case ORE_LAVA: {
				DrawTexture(*mLavaTex, drawPos, Vector(Width, Height));
				break;
			}
			case ORE_HARDROCK: {
				DrawTexture(*mHardRockTex, drawPos, Vector(Width, Height));
				break;
			}
		}
	}
};

struct Explosion : public GameObject {
	int Type;
	float Age;
	int Radius;
	bool TerrainRemoved;

	Explosion(int type, Vector pos, int radius) :
		GameObject(pos, radius, radius),
		Type(type),
		Radius(radius),
		TerrainRemoved(false)
	{

	}

	~Explosion() {

	}

	virtual void Draw()	{

	}

	virtual void Update(float dt) {
		if(!TerrainRemoved) {
			std::vector<WorldBlock*> blocks;
			Region->GetBlocks(blocks, Pos.X-2*Radius, Pos.Y-2*Radius, Radius*4, Radius*4);
			for(unsigned int i = 0; i < blocks.size(); i++) {
				int blockx = blocks[i]->X * 256;
				int blocky = blocks[i]->Y * 256;
				
				int bx = rintf(Pos.X);
				int by = rintf(Pos.Y);
				for(int y = -Radius; y < Radius; y++) {
					for(int x = -Radius; x < Radius; x++) {
						if(x * x + y * y > Radius * Radius)
							continue;
						int dx = (bx + x) - blockx;
						int dy = (by + y) - blocky;

						if(dx >= 0 && dx < 256 && dy >= 0 && dy < 256) {

							uint32_t color = blocks[i]->Data[dx + dy * 256];

							bool rock = isRock(color);
							bool sand = isSand(color);
							bool hardrock = isHardRock(color);
							bool lava = isLava(color);

							if(Type <= BULLET_BASIC && (rock || hardrock || lava)) {
								continue;
							}
							if(Type <= BULLET_ROCKBREAKER && (hardrock || lava)) {
								continue;
							}
							if(Type <= BULLET_ROCKSOFTENER && (lava)) {
								continue;
							}
							blocks[i]->Data[dx + dy * 256] = 0x0;
							blocks[i]->Dirty = true;

							if(rock) { mRockDestroyed++; mUnpayedRock++; }
							if(sand) { mSandDestroyed++; mUnpayedSand++; }
							if(hardrock) { mHardRockDestroyed++; mUnpayedHardRock++; }
							if(lava) { mMagmaDestroyed++; mUnpayedMagma++; }
						}
					}
				}
			}
			play_sound(mExplode1);
			TerrainRemoved = true;		
		}

		while(mUnpayedSand > SAND_SPAWN_AMOUNT) {
			mAddObjects.push(new Ore(ORE_SAND, Pos));
			mUnpayedSand -= SAND_SPAWN_AMOUNT;
		}
		while(mUnpayedRock > ROCK_SPAWN_AMOUNT) {
			mAddObjects.push(new Ore(ORE_ROCK, Pos));
			mUnpayedRock -= ROCK_SPAWN_AMOUNT;
		}
		while(mUnpayedHardRock > HARDROCK_SPAWN_AMOUNT) {
			mAddObjects.push(new Ore(ORE_HARDROCK, Pos));
			mUnpayedHardRock -= HARDROCK_SPAWN_AMOUNT;
		}
		while(mUnpayedMagma > LAVA_SPAWN_AMOUNT) {
			mAddObjects.push(new Ore(ORE_LAVA, Pos));
			mUnpayedMagma -= LAVA_SPAWN_AMOUNT;
		}

		if(Age > 0.5f && !Deleted) {
			Deleted = true;
			mDeleteObjects.push(this);
		}
	}
};

struct Bullet : public GameObject {

	int Type;
	float Angle;
	float Age;

	Bullet(int type, Vector pos, float angle) :
		GameObject(pos, 32, 32),
		Type(type),
		Angle(angle),
		Age(0.0f)
	{
		Vel = Vector(sinf(Angle), cosf(Angle)) * 800.0f;
	}

	~Bullet() {

	}

	virtual void Draw() {
		gl_PushModelView();
		Matrix::translate(gl_modelview, Pos.X, Pos.Y, 0.0f);
		Matrix::rotate(gl_modelview, (Angle - M_PI / 4.0f) / M_PI * 180.0f + 180.0f, 0.0f, 0.0f, 1.0f);
		Matrix::translate(gl_modelview, -(Pos.X), -(Pos.Y), 0.0f);

		if(Type == BULLET_BASIC) {
			DrawTexture(*mRedBulletTex, Pos, Vector(32, 32));
		} else if(Type == BULLET_ROCKBREAKER) {
			DrawTexture(*mBlueBulletTex, Pos, Vector(32, 32));
		} else if(Type == BULLET_ROCKSOFTENER) {
			DrawTexture(*mPurpleBulletTex, Pos, Vector(32, 32));
		} else if(Type == BULLET_COREBUSTER) {
			DrawTexture(*mGreenBulletTex, Pos, Vector(32, 32));
		}
		gl_PopModelView();
	}

	virtual void Update(float dt) {
		Age += dt;
		std::vector<WorldBlock*> blocks;
		Region->GetBlocks(blocks, Pos.X, Pos.Y, 5, 5);

		for(unsigned int i = 0; i < blocks.size(); i++) {
			int blockx = blocks[i]->X * 256;
			int blocky = blocks[i]->Y * 256;
			
			int bx = rintf(Pos.X);
			int by = rintf(Pos.Y);
			for(int y = 0; y < 5; y++) {
				for(int x = 0; x < 5; x++) {
					int dx = (bx + x) - blockx;
					int dy = (by + y) - blocky;

					if(dx >= 0 && dx < 256 && dy >= 0 && dy < 256) {
						uint32_t color = blocks[i]->Data[dx + dy * 256];
						if((color & 0xFF000000) != 0) {
							// fprintf(stdout, "%x\n", color);
							if(!Deleted) {
								if(Type == BULLET_BASIC) {
									mAddObjects.push(new Explosion(Type, Pos, 8));
								} else if(Type == BULLET_ROCKBREAKER) {
									mAddObjects.push(new Explosion(Type, Pos, 12));
								} else if(Type == BULLET_ROCKSOFTENER) {
									mAddObjects.push(new Explosion(Type, Pos, 16));
								} else if(Type == BULLET_COREBUSTER) {
									mAddObjects.push(new Explosion(Type, Pos, 20));
								}
								Deleted = true;
								mDeleteObjects.push(this);
							}
							break;
						}
					}
				}
			}
		}

		if(Age > 0.5f && !Deleted) {
			Deleted = true;
			mDeleteObjects.push(this);
		}

		SetPos(Pos + Vel * dt);
	}
};

struct PlanetRegion : public GameObject {

	int PlanetX;
	int PlanetY;

	PlanetRegion(int x, int y, Vector pos) :
		GameObject(pos - Vector(512.0f,512.0f), 2048+1024, 2048+1024),
		PlanetX(x), PlanetY(y)
	{
	}
	~PlanetRegion() {

	}

	virtual void Draw() {
		//DrawRect(Pos.X, Pos.Y, Width, Height, Color(0.0f, 1.0f, 0.0f, 1.0f));
	}

	void ApplyGravity(Vector center, QuadRegion * region, float dt) {
		if(region == NULL) {
			return;
		}

		foreach(it, region->Objects) {
			if(*it == this || *it == NULL) {
				continue;
			}

			if((*it)->Pos.GetDist(center) < (2048+1024)/2) {
				Vector diff = center - (*it)->Pos;
				(*it)->Vel += diff.GetNormalized() * 200.0f * dt;
			}
		}

		ApplyGravity(center, region->Tl, dt);
		ApplyGravity(center, region->Tr, dt);
		ApplyGravity(center, region->Bl, dt);
		ApplyGravity(center, region->Br, dt);
	}

	virtual void Update(float dt) {
		// Apply force to objects within the field of gravity
		Vector center = Pos + Vector(Width / 2, Height / 2);
		mPlanetCenter = center;
		ApplyGravity(center, Region, dt);
	}
};

struct Merchant : public GameObject {
	TexRef mImage;
	float mAngle;

	Merchant(Vector pos) :
		GameObject(pos, 64, 64),
		mImage(NULL),
		mAngle(0.0f)
	{
		mImage = TexRef(Res.LoadTexture("img/altship.png"));
	}

	virtual void Update(float dt) {
	}

	virtual void Draw() {
		gl_PushModelView();
		Matrix::translate(gl_modelview, -32.0f, -32.0f, 0.0f);
		Matrix::translate(gl_modelview, Pos.X+32.0f, Pos.Y+32.0f, 0.0f);
		Matrix::rotate(gl_modelview, mAngle / M_PI * 180.0f + 180.0f, 0.0f, 0.0f, 1.0f);
		Matrix::translate(gl_modelview, -(Pos.X+32.0f), -(Pos.Y+32.0f), 0.0f);
		DrawTexture(*mImage, Pos, Vector(Width, Height));
		gl_PopModelView();
	}
};

struct Player : public GameObject {
	TexRef mImage;
	float Age;
	float mAngle;
	float mSpeed;
	int Weapon;
	int Bullets;

	bool leftPressed, rightPressed, upPressed, downPressed, spacePressed, shiftPressed;

	Player(Vector pos, int width, int height) :
		GameObject(pos, width, height),
		mImage(NULL),
		Age(0.0f),
		mAngle(M_PI),
		mSpeed(0.0f),
		leftPressed(false), rightPressed(false), upPressed(false), downPressed(false), spacePressed(false), shiftPressed(false)
	{
		Weapon = BULLET_BASIC;
		Bullets = 0;
		mImage = TexRef(Res.LoadTexture("img/ship.png"));
	}

	int CheckCollision(Vector newPos) {
		int result = 0;
		std::vector<WorldBlock*> blocks;
		Region->GetBlocks(blocks, newPos.X, newPos.Y, 5, 5);

		for(unsigned int i = 0; i < blocks.size(); i++) {
			if(!blocks[i]->Ready) {
				int wcx = mydiv(blocks[i]->X, 8);
				int wcy = mydiv(blocks[i]->Y, 8);
				wcx *= 256 * 8;
				wcy *= 256 * 8;

				Vector wcenter;
				wcenter.X = wcx + 1024.0f;
				wcenter.Y = wcy + 1024.0f;
				if(Pos.GetDist(wcenter)+Width < 1124.0f) {
					result += 256 * 256;
				}
				continue;
			}
			int blockx = blocks[i]->X * 256;
			int blocky = blocks[i]->Y * 256;
			
			int bx = rintf(newPos.X);
			int by = rintf(newPos.Y);
			for(int y = -10; y < 10; y++) {
				for(int x = -10; x < 10; x++) {
					int dx = (bx + x) - blockx;
					int dy = (by + y) - blocky;

					if(dx >= 0 && dx < 256 && dy >= 0 && dy < 256) {
						uint32_t color = blocks[i]->Data[dx + dy * 256];
						if((color & 0xFF000000) != 0) {
							result += 1;
						}
					}
				}
			}
		}
		return result;
	}



	void FindOthers(std::vector<GameObject*> & others, QuadRegion * region) {
		if(region == NULL) {
			return;
		}

		foreach(it, region->Objects) {
			if(*it != NULL && *it != this) {
				others.push_back(*it);
			}
		}
		FindOthers(others, region->Tl);
		FindOthers(others, region->Tr);
		FindOthers(others, region->Bl);
		FindOthers(others, region->Br);
	}

	void FindOthers(std::vector<GameObject*> & others) {
		// Search upwards
		QuadRegion * upwards = Region->Parent;
		while(upwards) {
			foreach(it, upwards->Objects) {
				if(*it != NULL && *it != this) {
					others.push_back(*it);
				}
			}
			upwards = upwards->Parent;
		}

		// Search downwards
		FindOthers(others, Region);
	}

	bool Collides(GameObject * other) {
		if(other->Pos.X + other->Width / 2 < Pos.X - Width/2) return false;
		if(other->Pos.X - other->Width / 2 > Pos.X + Width /2) return false;
		if(other->Pos.Y + other->Height / 2 < Pos.Y - Height/2) return false;
		if(other->Pos.Y - other->Height / 2 > Pos.Y + Height / 2) return false;
		return true;
	}

	virtual void Update(float dt) {
		// fprintf(stdout, "%.2f, %.2f\n", Vel.X, Vel.Y);
		Age += dt;

		if(leftPressed) {
			mAngle += 2.5f * dt;
			// Vel.X -= PLAYER_ACCEL * dt;
		} else if(rightPressed) {
			mAngle -= 2.5f * dt;
			//Vel.X += PLAYER_ACCEL * dt;
		}

		Vector forceDir = Vector(sinf(mAngle), cosf(mAngle));




		if(upPressed) {
			Vel = Vel + forceDir * 1000.0f * dt;
			mSpeed += 1000.0f * dt;
		} else if(downPressed) {
			Vel = Vel - forceDir * 1000.0f * dt;
		}
		if(shiftPressed) {
			//Vel *= forceDir.GetNormalizedOrZero();
			Vel *= 0.8f;//1.0f - dt * 8.0f;
			//mSpeed -= 1000.0f * dt;
			if(mSpeed < -100.0f) {
				mSpeed = -100.0f;
			}
		}

		Vector newPos = Pos + Vel * dt;

		if(spacePressed) {
			Bullets += 3;
			Vector spawnPos = newPos + forceDir * 32.0f;

			float spawnAngle = mAngle;
			Bullet * bullet = NULL;

			if(Weapon == BULLET_BASIC && Bullets >= 1) {
				bullet = new Bullet(Weapon, spawnPos, spawnAngle);
				bullet->Vel += Vel;
				mAddObjects.push(bullet);
				Bullets -= 1;
			} else if(Weapon == BULLET_ROCKBREAKER && Bullets >= 2) {
				bullet = new Bullet(Weapon, spawnPos, spawnAngle - 0.05f);
				bullet->Vel += Vel;
				mAddObjects.push(bullet);
				bullet = new Bullet(Weapon, spawnPos, spawnAngle + 0.05f);
				bullet->Vel += Vel;
				mAddObjects.push(bullet);
				Bullets -= 2;
			} else if(Weapon == BULLET_ROCKSOFTENER && Bullets >= 1) {
				spawnAngle += sinf(Age*20.0f) / 3.0f;
				bullet = new Bullet(Weapon, spawnPos, spawnAngle);
				bullet->Vel += Vel;
				mAddObjects.push(bullet);
				Bullets -= 1;
			} else if(Weapon == BULLET_COREBUSTER && Bullets >= 3) {
				spawnAngle = mAngle + sinf(Age*10.0f) / 3.0f;
				bullet = new Bullet(Weapon, spawnPos, spawnAngle - 0.1f);
				bullet->Vel += Vel;
				mAddObjects.push(bullet);
				spawnAngle = mAngle + sinf(Age*10.0f - M_PI / 2.0f) / 3.0f;
				bullet = new Bullet(Weapon, spawnPos, spawnAngle);
				bullet->Vel += Vel;
				mAddObjects.push(bullet);
				spawnAngle = mAngle + sinf(Age*10.0f + M_PI / 2.0f) / 3.0f;
				bullet = new Bullet(Weapon, spawnPos, spawnAngle + 0.1f);
				bullet->Vel += Vel;
				mAddObjects.push(bullet);
				Bullets -= 3;
			}			
		}

		int currentCount = CheckCollision(Pos);
		int newCount = CheckCollision(Pos + Vel * (dt * 5.0f));
		// fprintf(stdout, "%d, %d\n", currentCount, newCount);
		if(newCount < currentCount || newCount < 10) {
			SetPos(newPos);
		} else {
			Vel *= 0.1f;
		}

		std::vector<GameObject*> others;
		FindOthers(others);
		foreach(it, others) {
			if(!Collides(*it)) {
				continue;
			}
			Ore * ore = NULL;
			if((ore = dynamic_cast<Ore*>(*it))) {
				if(!ore->Deleted) {
					switch(ore->Type) {
						case ORE_ROCK: mRockCollected++; break;
						case ORE_SAND: mSandCollected++; break;
						case ORE_HARDROCK: mHardRockCollected++; break;
						case ORE_LAVA: mLavaCollected++; break;
					}
					ore->Deleted = true;
					mDeleteObjects.push(ore);
					play_sound(mPickup1);
				}
			}
		}
	}

	virtual void Draw() {
		gl_PushModelView();
		Matrix::translate(gl_modelview, -32.0f, -32.0f, 0.0f);
		Matrix::translate(gl_modelview, Pos.X+32.0f, Pos.Y+32.0f, 0.0f);
		Matrix::rotate(gl_modelview, mAngle / M_PI * 180.0f + 180.0f, 0.0f, 0.0f, 1.0f);
		Matrix::translate(gl_modelview, -(Pos.X+32.0f), -(Pos.Y+32.0f), 0.0f);
		DrawTexture(*mImage, Pos, Vector(Width, Height));
		gl_PopModelView();
	}

	void KeyUp(int key) {
		if(key == KEYCODE_LEFT) {
			leftPressed = false;
		} else if(key == KEYCODE_RIGHT) {
			rightPressed = false;
		} else if(key == KEYCODE_DOWN) {
			downPressed = false;
		} else if(key == KEYCODE_UP) {
			upPressed = false;
		} else if(key == KEYCODE_SPACE) {
			spacePressed = false;
		} else if(key == KEYCODE_SHIFT) {
			shiftPressed = false;
		}
	}

	void KeyDown(int key) {
		if(key == KEYCODE_LEFT) {
			leftPressed = true;
		} else if(key == KEYCODE_RIGHT) {
			rightPressed = true;
		} else if(key == KEYCODE_DOWN) {
			downPressed = true;
		} else if(key == KEYCODE_UP) {
			upPressed = true;
		} else if(key == KEYCODE_SPACE) {
			spacePressed = true;
		} else if(key == KEYCODE_SHIFT) {
			shiftPressed = true;
		}
	}
};




QuadRegion * mRegion = NULL;
Player * mPlayer = NULL;
#define H_TILES (1024 / 256 + 1)
#define V_TILES (768 / 256 + 1)
GLuint mTexturePool[H_TILES * V_TILES];

Generator * mGenerator = NULL;


struct Navigation {
	GameState * mGameState;
	GLuint Tex;
	TexRef mBackground;
	TexRef mInfoFrame;
	TexRef mMissionFrame;
	uint8_t * Data;
	int Progress;
	Vector Center;

	Navigation(GameState * gameState) : 
		mGameState(gameState),
		mBackground(NULL),
		mInfoFrame(NULL),
		mMissionFrame(NULL),
		Data(new uint8_t[64*64])
	{
		memset(Data, 0xffu, 64*64);

		glGenTextures(1, &Tex);
		glBindTexture(GL_TEXTURE_2D, Tex);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); 
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE, 64, 64, 0, GL_LUMINANCE, GL_UNSIGNED_BYTE, Data);

		mBackground = TexRef(Res.LoadTexture("img/navframe.png"));
		mInfoFrame = TexRef(Res.LoadTexture("img/ffl.png"));
		mMissionFrame = TexRef(Res.LoadTexture("img/missionframe.png"));
	}

	~Navigation() {
		delete[] Data;
	}

	void SetCenter(Vector center) {
		Center = center;
	}

	void Update(float dt)
	{
		int offx = rintf(Center.X);
		int offy = rintf(Center.Y);
		offx = mydiv(offx, 512);
		offy = mydiv(offy, 512);


		for(int y = 0; y < 64; y++) {
			for(int x = 0; x < 64; x++) {
				if(contains_planet(mydiv(x - 32 + offx, 4), mydiv(y + offy - 32, 4))) {
					Data[x + y * 64] = 0x00;
				} else {
					Data[x + y * 64] = 0x44;
				}
			}
		}

		glBindTexture(GL_TEXTURE_2D, Tex);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE, 64, 64, 0, GL_LUMINANCE, GL_UNSIGNED_BYTE, Data);
	}

	void Draw()
	{
		Vector position = Vector(1024.0f - 128.0f, 768.0f - 128.0f);
		Vector size = Vector(128.0f, 128.0f);
		Quad frameverts = Quad(position - Vector(14.0f, 14.0f), size + Vector(14.0f, 14.0f));


		Quad vertices = Quad(position - Vector(7.0f, 7.0f), size);
		Quad texcoords;
		texcoords.TopLeft = Vector::Zero;
		texcoords.TopRight = Vector(1.0f, 0.0f);
		texcoords.BottomLeft = Vector(0.0f, 1.0f);
		texcoords.BottomRight = Vector(1.0f, 1.0f);

		glBindTexture(GL_TEXTURE_2D, Tex);
		gl_TextureProg->VertexPointer((void*)&vertices);
		gl_TextureProg->TexCoordPointer((void*)&texcoords);
		gl_TextureProg->Use();
		glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);

		DrawTexture(*mBackground, &frameverts);

		position = Vector(14.0f, 768.0f - 128.0f);
		frameverts = Quad(position - Vector(14.0f, 14.0f), Vector(256.0f,256.0f));
		DrawTexture(*mInfoFrame, &frameverts);

		position = Vector(14.0f + 256.0f, 768.0f - 128.0f);
		frameverts = Quad(position - Vector(14.0f, 14.0f), Vector(512.0f,512.0f));
		DrawTexture(*mMissionFrame, &frameverts);
	}
};

void GameObject::UpdateRegion()
{
	assert(Region != NULL);
	Region->Move(this);
}

extern bool mMp3Enabled;

int state = 0;

GameState::GameState(System * system) :
	State(system),
	mBackground(NULL),
	mNavigation(new Navigation(this)),
	mCoordinates(NULL),
	mMissionState(0)
{
	mCoordinates = new CompiledText("img/font.png");
	mCoordinates->SetText("");

	mSandCount = new CompiledText("img/font.png");
	mRockCount = new CompiledText("img/font.png");
	mHardRockCount = new CompiledText("img/font.png");
	mLavaCount = new CompiledText("img/font.png");
	mWeaponName = new CompiledText("img/font.png");

	mRedBulletTex = TexRef(Res.LoadTexture("img/red_bullet.png"));
	mGreenBulletTex = TexRef(Res.LoadTexture("img/green_bullet.png"));
	mPurpleBulletTex = TexRef(Res.LoadTexture("img/purple_bullet.png"));
	mBlueBulletTex = TexRef(Res.LoadTexture("img/blue_bullet.png"));
	mTitleScreen = TexRef(Res.LoadTexture("img/titlescreen.png"));

	mRegion = new QuadRegion(&mRegion, NULL, 0, 0, 256, 256, NULL, NULL, NULL, NULL);
	mGenerator = new Generator();
	mOffset = Platform::GetSize() / 2.0f;

	//mPlayer = new Player(Vector(1024.0f, -40.0f), 64, 64);
	mPlayer = new Player(Vector::Zero, 64, 64);
	//mPlayer->Vel = Vector(500.0f, 0.0f);
	mPlayer->Vel = Vector::Zero;

	mRegion->Add(mPlayer);
	mFrame = 1;

	mMissionLog = new MissionLog();

	mBackground = TexRef(Res.LoadTexture("img/background.png", GL_REPEAT, GL_NEAREST));

	mRockTex = TexRef(Res.LoadTexture("img/rock.png"));
	mSandTex = TexRef(Res.LoadTexture("img/sand.png"));
	mHardRockTex = TexRef(Res.LoadTexture("img/hardrock.png"));
	mLavaTex = TexRef(Res.LoadTexture("img/lava.png"));

	mExplode1 = load_wav("snd/explode1.wav");
	mPickup1 = load_wav("snd/pickup1.wav");
	mMission1 = load_wav("snd/mission1.wav");
	
	Mix_ChannelFinished(channel_finished_cb);


	if(mMp3Enabled) {
		fprintf(stdout, "lading music\n");
		mMusic = Mix_LoadMUS("res/snd/music.mp3");
		if(mMusic == NULL) {
			fprintf(stderr, "Failed to load music file\n");
		}
	}


	/* Fill the texture pool */
	glGenTextures(H_TILES * V_TILES, mTexturePool);
	for(int i = 0; i < H_TILES * V_TILES; i++) {
		glBindTexture(GL_TEXTURE_2D, mTexturePool[i]);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); 
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 256, 256, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
	}

	if(mMusic) {
		Mix_FadeInMusic(mMusic, -1, 1000);
	}
}

GameState::~GameState()
{
	delete mRegion;
	delete mGenerator;
	delete mNavigation;
	delete mCoordinates;
	delete mMissionLog;
	delete mWeaponName;


	mBlueBulletTex = NULL;
	mGreenBulletTex = NULL;
	mHardRockTex = NULL;
	mLavaTex = NULL;
	mPurpleBulletTex = NULL;
	mRedBulletTex = NULL;
	mRockTex = NULL;
	mSandTex = NULL;
	mTitleScreen = NULL;
	mRegion = NULL;
}

void GameState::UpdateShadowTexture()
{
}

/* x and y are given in tile coords (so multiply by 256 to get real world coords) */
void GameState::FindPlanets(QuadRegion * region, int x, int y, std::vector<PlanetRegion*> & planets)
{
	if(region == NULL) {
		return;
	}
	if(!region->Fits(x*256, y*256, 256, 256)) {
		return;
	}

	foreach(it, region->Objects) {
		if(*it == NULL) continue;
		PlanetRegion * region = NULL;
		if((region = dynamic_cast<PlanetRegion*>(*it))) {
			planets.push_back(region);
		}
	}

	FindPlanets(region->Tl, x, y, planets);
	FindPlanets(region->Tr, x, y, planets);
	FindPlanets(region->Bl, x, y, planets);
	FindPlanets(region->Br, x, y, planets);
}

WorldBlock * GameState::GenerateTile(int x, int y)
{
	// fprintf(stdout, "%d: created %d, %d\n", mFrame, x, y);
	if(contains_planet(mydiv(x, 8), mydiv(y, 8))) {
		// Find planet gameobject associated with this cell
		std::vector<PlanetRegion*> planets;
		FindPlanets(mRegion, x, y, planets);
		if(planets.size() == 0) {
			// Add a new planet
			Vector ppos = Vector(mydiv(x, 8)*2048, mydiv(y,8)*2048);
			PlanetRegion * planet = new PlanetRegion(mydiv(x,8), mydiv(y,8), ppos);
			mRegion->Add(planet);
			fprintf(stdout, "Adding planet\n");
		} else {
			/* Check if this particular planet does not exist yet */
			bool shouldAdd = true;
			for(unsigned int i = 0; i < planets.size(); i++) {
				if(planets[i]->PlanetX == mydiv(x,8) && planets[i]->PlanetY == mydiv(y,8)) {
					shouldAdd = false;
					break;
				}
			}
			if(shouldAdd) {
				Vector ppos = Vector(mydiv(x, 8)*2048, mydiv(y,8)*2048);
				PlanetRegion * planet = new PlanetRegion(mydiv(x,8), mydiv(y,8), ppos);
				mRegion->Add(planet);
				fprintf(stdout, "Adding planet\n");
			}
		}

		WorldBlock * block = new WorldBlock(x, y);
		mGenerator->Enqueue(block);
		mRegion->AddBlock(block);
		return block;
	} else { 
		return NULL;
	}	
}

static uint32_t get_free_slot(uint32_t slots) {
	for(int i = 0; i < 20; i++) {
		if((slots >> i) & 1) {
			return i;
		}
	}
	assert(false);
	return -1;
};

struct BulletInfo {
	Vector Pos;
	Vector Vel;
	int Type;
};

std::vector<BulletInfo> mBullets;

void CleanupBullets() {
	mBullets.clear();
}

void DrawBullets() {


	foreach(it, mBullets) {
		Vector pos = it->Pos;

		gl_PushModelView();
		Matrix::translate(gl_modelview, pos.X, pos.Y, 0.0f);
		Matrix::rotate(gl_modelview, -45.0f, 0.0f, 0.0f, 1.0f);
		Matrix::translate(gl_modelview, -(pos.X), -(pos.Y), 0.0f);

		if(it->Type == 0) {
			DrawTexture(*mRedBulletTex, pos, Vector(64.0f, 64.0f));
		} else if(it->Type == 1) {
			DrawTexture(*mPurpleBulletTex, pos, Vector(64.0f, 64.0f));
		} else if(it->Type == 2) {
			DrawTexture(*mBlueBulletTex, pos, Vector(64.0f, 64.0f));
		} else if(it->Type == 3) {
			DrawTexture(*mGreenBulletTex, pos, Vector(64.0f, 64.0f));
		}
		gl_PopModelView();
	}
}

uint64_t BulletsSpawned = 0;
float BulletDelay = 0.0f;

void UpdateBullets(float dt) {
	for(unsigned int i = 0; i < mBullets.size(); i++) {
		mBullets[i].Pos = mBullets[i].Pos + mBullets[i].Vel * dt;

		if(mBullets[i].Pos.Y < -64.0f) {
			mBullets[i] = mBullets[mBullets.size()-1];
			mBullets.pop_back();
			i--;
		}
	}

	BulletDelay -= dt;

	if(mBullets.size() < 21 && BulletDelay <= 0.0f) {
		BulletInfo binfo;
		binfo.Pos = Vector(16.0f + (BulletsSpawned % 20) * 50.0f, 768.0f);
		binfo.Vel = Vector(0.0f, -1000.0f);
		binfo.Type = rand() % 4;
		mBullets.push_back(binfo);
		BulletsSpawned += 1u;
		BulletDelay = 0.3f;
	}
}

void GameState::Update(float dt)
{
	if(state == 0) {
		UpdateBullets(dt);
		return;
	}
	Vector tl = mPlayer->Pos - Platform::GetSize() / 2.0f;
	Vector sz = Platform::GetSize();

	mRegion->Update(dt);
	mOffset = (mPlayer->Pos * Vector(-1.0f,-1.0f)) + Platform::GetSize() / 2.0f;
	mOffset.X = rintf(mOffset.X);
	mOffset.Y = rintf(mOffset.Y);

	int tile_ofx = rintf((tl.X - 128.0f) / 256.0f);
	int tile_ofy = rintf((tl.Y - 128.0f) / 256.0f);

	assert(H_TILES == 5);
	assert(V_TILES == 4);
	WorldBlock * world[V_TILES][H_TILES] = {
		{ NULL, NULL, NULL, NULL, NULL },
		{ NULL, NULL, NULL, NULL, NULL },
		{ NULL, NULL, NULL, NULL, NULL },
		{ NULL, NULL, NULL, NULL, NULL }
	};

	uint32_t avail_textures = 0x000FFFFFu;

	/* Fill the block 2d array */
	// fprintf(stdout, "\n");
	std::vector<WorldBlock*> blocks;
	mRegion->GetBlocks(blocks, (int)tl.X - 256, (int)tl.Y - 256, (int)sz.X + 512, (int)sz.Y + 512);
	foreach(it, blocks) {
		int tile_x = (*it)->X - tile_ofx;
		int tile_y = (*it)->Y - tile_ofy;
		if(tile_x >= 0 && tile_x < H_TILES && tile_y >= 0 && tile_y < V_TILES) {
			// fprintf(stdout, "%d: found %d, %d\n", mFrame, (*it)->X, (*it)->Y);
			world[tile_y][tile_x] = *it;

			/* If the block was rendered in the last frame we should reuse it's texture */
			/*if(tile_x * 256.0f + 256.0f <= tl.X) continue;
			if(tile_x * 256.0f >= tl.X + sz.X) continue;
			if(tile_y * 256.0f + 256.0f <= tl.Y) continue;
			if(tile_y * 256.0f >= tl.Y + sz.Y) continue;*/
			if((*it)->LastUpdateAt == mFrame - 1) {
				// fprintf(stdout, "%lld: Reusing slot: %d\n", mFrame, (*it)->TexPoolId);
				avail_textures &= ~(1 << (*it)->TexPoolId);
			}
		}
	}



	/* Iterate over the 2d block array */
	for(int y = 0; y < V_TILES; y++) {
		for(int x = 0; x < H_TILES; x++) {
			WorldBlock * block = world[y][x];
			if(block == NULL) {
				block = GenerateTile(x+tile_ofx, y+tile_ofy);
				if(block == NULL) {
					continue;
				}
			}

			
			/* If the block WAS renderend in the last frame but has become dirty */
			if(block->LastUpdateAt == mFrame -1 && block->Dirty) {
				glBindTexture(GL_TEXTURE_2D, block->TexId);
				glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 256, 256, 0, GL_RGBA, GL_UNSIGNED_BYTE, block->Data);
				block->Dirty = false;
			}
			/* If the block was not rendered in the last frame we should assign a texture to it */
			else if(block->LastUpdateAt != mFrame - 1 && block->Ready) {
				uint32_t slot = get_free_slot(avail_textures);
				avail_textures &= ~(1 << slot);
				block->TexPoolId = slot;
				block->TexId = mTexturePool[slot];
				// fprintf(stdout, "Uploading data\n");
				glBindTexture(GL_TEXTURE_2D, block->TexId);
				glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 256, 256, 0, GL_RGBA, GL_UNSIGNED_BYTE, block->Data);
				block->Dirty = false;
			}
			if(block->Ready) {
				block->LastUpdateAt = mFrame;
			}
		}
	}

	while(!mAddObjects.empty()) {
		mRegion->Add(mAddObjects.front());
		mAddObjects.pop();
	}

	while(!mDeleteObjects.empty()) {
		mRegion->Remove(mDeleteObjects.front());
		delete mDeleteObjects.front();
		mDeleteObjects.pop();
	}

	mNavigation->SetCenter(mPlayer->Pos);
	mNavigation->Update(dt);

	mMissionLog->Update(dt);
	switch(mMissionState) {
		case 0: {
			mMissionLog->AddLine("x: Fire Cannon, z: Brake");
			mMissionLog->AddLine("Left/Right: rotate, Up: Forwards, Down: Backwards");
			mMissionLog->AddLine("");
			mMissionLog->AddLine("Welcome, how are you?");
			mMissionLog->AddLine("Ready for a mission?");
			mMissionLog->AddLine("Collect 30 Sand and buy a new weapon at *300,50");
			play_sound(mMission1);
			mMissionState += 1;
			break;
		}
		case 1: {
			if(mSandCollected >= 30) {
				mMissionLog->AddLine("");
				mMissionLog->AddLine("Ah I see you've collected 30 sand, well done!");
				mMissionLog->AddLine("Now head over to *300,50, to buy that weapon.");
				play_sound(mMission1);
				mMissionState += 1;
			}
			break;
		}
		case 2: {
			mAddObjects.push(new Merchant(Vector(300,50)*Vector(256.0f,256.0f)));
			mMissionState += 1;
			break;
		}
		case 3: {
			int px = mydiv(mPlayer->Pos.X, 256.0f);
			int py = mydiv(mPlayer->Pos.Y, 256.0f);
			if((px == 300 || px == 299) && (py == 50 || py == 49)) {
				mMissionLog->AddLine("");
				mMissionLog->AddLine("That'll be 30 sand, thank you.");
				mMissionLog->AddLine("You have acquired the 'Rock Breaker'");
				mSandCollected -= 30;
				mPlayer->Weapon = BULLET_ROCKBREAKER;
				play_sound(mMission1);
				mMissionState += 1;
			}
			break;
		}
		case 4: {
			mMissionLog->AddLine("");
			mMissionLog->AddLine("Next up! A brand new Rock Melter for only 100 rock.");
			mMissionState += 1;
			break;
		}
		case 5: {
			if(mRockCollected >= 100) {
				mMissionLog->AddLine("");
				mMissionLog->AddLine("I see you've got enough rock, head to *300,50");
				play_sound(mMission1);
				mMissionState += 1;
			}
			break;
		}
		case 6: {
			int px = mydiv(mPlayer->Pos.X, 256.0f);
			int py = mydiv(mPlayer->Pos.Y, 256.0f);
			if((px == 300 || px == 299) && (py == 50 || py == 49)) {
				mMissionLog->AddLine("");
				mMissionLog->AddLine("That'll be 100 rock, thank you.");
				mMissionLog->AddLine("You have acquired the 'Rock Melter'");
				mRockCollected -= 100;
				mPlayer->Weapon = BULLET_ROCKSOFTENER;
				play_sound(mMission1);
				mMissionState += 1;
			}
			break;
		}
		case 7: {
			mMissionLog->AddLine("");
			mMissionLog->AddLine("Next up! A brand new Core Buster for only 60 hard rock.");
			mMissionState += 1;
			break;
		}
		case 8: {
			if(mHardRockCollected >= 60) {
				mMissionLog->AddLine("");
				mMissionLog->AddLine("I see you've got enough hard rock, head to *300,50");
				play_sound(mMission1);
				mMissionState += 1;
			}
			break;
		}
		case 9: {
			int px = mydiv(mPlayer->Pos.X, 256.0f);
			int py = mydiv(mPlayer->Pos.Y, 256.0f);
			if((px == 300 || px == 299) && (py == 50 || py == 49)) {
				mMissionLog->AddLine("");
				mMissionLog->AddLine("That'll be 60 hard rock, thank you.");
				mMissionLog->AddLine("You have acquired the 'Core Buster'");
				mHardRockCollected -= 100;
				mPlayer->Weapon = BULLET_COREBUSTER;
				play_sound(mMission1);
				mMissionState += 1;
			}
			break;
		}
		case 10: {
			mMissionLog->AddLine("");
			mMissionLog->AddLine("Next up! Collect 32 magma.");
			mMissionState += 1;
			break;
		}
		case 11: {
			if(mLavaCollected >= 32) {
				mMissionLog->AddLine("");
				mMissionLog->AddLine("I see you've got enough magma, head to *300,50");
				play_sound(mMission1);
				mMissionState += 1;
			}
			break;
		}
		case 12: {
			int px = mydiv(mPlayer->Pos.X, 256.0f);
			int py = mydiv(mPlayer->Pos.Y, 256.0f);
			if((px == 300 || px == 299) && (py == 50 || py == 49)) {
				mMissionLog->AddLine("");
				mMissionLog->AddLine("You're now the richest person in the universe. You Win!");
				mMissionLog->AddLine("Thanks for playing");
				mMissionLog->AddLine("");
				mMissionLog->AddLine("");
				mMissionLog->AddLine("");
				mLavaCollected -= 32;
				play_sound(mMission1);
				mMissionState += 1;
			}
			break;
		}

	}

}

void GameState::DrawBackground()
{
	Vector tl = mPlayer->Pos - Platform::GetSize() / 2.0f;
	Vector sz = Platform::GetSize();

	// fprintf(stdout, "Trying to render\n");
	// Vector position = Vector(256.0f * X, 256.0f * Y);
	// Vector size = Vector(256.0f, 256.0f);
	Quad vertices = Quad(Vector::Zero, sz);
	Quad texcoords = Quad(tl / 512.0f, (sz) / 512.0f);
	

	// fprintf(stdout, "Using texid: %u\n", TexId);
	glBindTexture(GL_TEXTURE_2D, mBackground->id);
	gl_TextureProg->VertexPointer((void*)&vertices);
	gl_TextureProg->TexCoordPointer((void*)&texcoords);
	gl_TextureProg->Use();
	glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}




void GameState::Draw()
{
	if(state == 0) {
		DrawBackground();
		DrawTexture(*mTitleScreen, Vector(256.0f,192.0f), Vector(512.0f, 512.0f));
		DrawBullets();
		return;
	}

	Vector tl = mPlayer->Pos - Platform::GetSize() / 2.0f;
	Vector sz = Platform::GetSize();

	DrawBackground();
	gl_PushModelView();

	Matrix::translate(gl_modelview, mOffset.X, mOffset.Y, 0.0f);
	mRegion->Draw((int)tl.X, (int)tl.Y, (int)sz.X, (int)sz.Y);
	gl_PopModelView();
	mNavigation->Draw();
	mCoordinates->SetText("*: %d, %d", mydiv(mPlayer->Pos.X, 256), mydiv(mPlayer->Pos.Y, 256));
	mCoordinates->Draw(Vector(20.0f, 638.0f));


	mSandCount->SetText("%d", mSandCollected);
	mRockCount->SetText("%d", mRockCollected);
	mHardRockCount->SetText("%d", mHardRockCollected);
	mLavaCount->SetText("%d", mLavaCollected);

	if(mPlayer->Weapon == BULLET_BASIC) {
		mWeaponName->SetText("Pea Shooter");
	} else if(mPlayer->Weapon == BULLET_ROCKBREAKER) {
		mWeaponName->SetText("Rock Breaker");
	} else if(mPlayer->Weapon == BULLET_ROCKSOFTENER) {
		mWeaponName->SetText("Rock Melter");
	} else if(mPlayer->Weapon == BULLET_COREBUSTER) {
		mWeaponName->SetText("Core Buster");
	} else {
		mWeaponName->SetText("Unknown");
	}

	DrawTexture(*mSandTex,     Vector(15.0f, 658.0f), Vector(16.0f, 16.0f));
	DrawTexture(*mRockTex,     Vector(70.0f, 658.0f), Vector(16.0f, 16.0f));
	DrawTexture(*mHardRockTex, Vector(15.0f, 678.0f), Vector(16.0f, 16.0f));
	DrawTexture(*mLavaTex,     Vector(70.0f, 678.0f), Vector(16.0f, 16.0f));

	mSandCount->Draw(    Vector(15.0f+20.0f, 658.0f));
	mRockCount->Draw(    Vector(70.0f+20.0f, 658.0f));
	mHardRockCount->Draw(Vector(15.0f+20.0f, 678.0f));
	mLavaCount->Draw(    Vector(70.0f+20.0f, 678.0f));

	mWeaponName->Draw(Vector(15.0f, 698.0f));

	mMissionLog->Draw();
	mFrame++;
}

void GameState::EnterState()
{
}

void GameState::LeaveState()
{
}

void GameState::PointerDown(Pointer *p)
{
	p->position = ToWorld(p->screenposition);
}

void GameState::PointerUp(Pointer *p)
{
}

void GameState::KeyDown(int key)
{
	if(state == 0) {
		if(key == KEYCODE_CONFIRM) {
			CleanupBullets();
			state = 1;
		}
	}
	if(key == KEYCODE_BACK) {
		Platform::Quit();
		return;
	}

	mPlayer->KeyDown(key);
}

void GameState::KeyUp(int key)
{
	mPlayer->KeyUp(key);
}

Vector GameState::ToWorld(Vector v)
{
	return v - mOffset;
}

Vector GameState::ToScreen(Vector v)
{
	return v + mOffset;
}
