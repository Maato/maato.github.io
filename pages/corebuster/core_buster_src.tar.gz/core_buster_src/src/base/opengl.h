#ifndef __OPENGL_HEADERS_H__
#define __OPENGL_HEADERS_H__

#ifdef _WIN32
	#include <windows.h>
	#define GLEW_STATIC
	#include <GL/glew.h>
#endif

#if defined(__native_client__)
	#include <GLES2/gl2.h>
	#include <GLES2/gl2ext.h>
#endif

#if defined(__linux__) & !defined(__ANDROID__)
	#define GL_GLEXT_PROTOTYPES
	#include <GL/gl.h>
	#include <GL/glext.h>
	#include "glstate.h"
#endif

#ifdef __ANDROID__
	#include <GLES/gl.h>
	#include <GLES2/gl2.h>
	#include <GLES2/gl2ext.h>
	#define glClearDepth glClearDepthf
	#include "glstate.h"
#endif

#ifdef __APPLE__
	#include <OpenGL/gl.h>
	#include <OpenGL/glext.h>
	#include "glstate.h"
#endif

#endif
