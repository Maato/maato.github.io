#ifndef __SMOOTHVALUE_H__
#define __SMOOTHVALUE_H__

template<typename T>
class SmoothValue
{
	private:
		T value;
		T smoothedValue;
		float smoothFactor;
	public:
		SmoothValue(T initialValue, float smoothFactor);
		T Get();
		T GetSmooth();
		void Set(T v);
		void SetFactor(float smoothFactor);
		void Reset();
};

template<typename T>
SmoothValue<T>::SmoothValue(T initialValue, float smoothFactor)
{
	this->value = initialValue;
	this->smoothedValue = initialValue;
	this->smoothFactor = smoothFactor;
}

template<typename T>
T SmoothValue<T>::Get()
{
	return value;
}

template<typename T>
T SmoothValue<T>::GetSmooth()
{
	return smoothedValue;
}

template<typename T>
void SmoothValue<T>::Set(T v)
{
	value = v;
	smoothedValue = smoothedValue * (1.0f - smoothFactor) + v * smoothFactor;
}

template<typename T>
void SmoothValue<T>::SetFactor(float smoothFactor)
{
	this->smoothFactor = smoothFactor;
}

template<typename T>
void SmoothValue<T>::Reset()
{
	smoothedValue = value;
}
#endif
