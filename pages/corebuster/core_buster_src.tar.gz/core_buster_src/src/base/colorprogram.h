#ifndef __COLOR_PROGRAM__
#define __COLOR_PROGRAM__

#include "gprogram.h"

class ColorProgram : public GProgram
{
	public:
		ColorProgram(const char * vert, const char * frag);
		bool Build();
		void Use();
		void Unuse();
		void VertexPointer(void * p) const;
		void SetColor(float r, float g, float b, float a);

	protected:
		GLint a_position;
		GLint u_mvp;
		GLint u_color;
};


#endif
