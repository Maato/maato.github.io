#ifndef __MATRIX_H__
#define __MATRIX_H__

#include <cstring>
#include "common.h"
#include "commonmath.h"

#include "platform.h"

struct Matrix
{
	Matrix() {
		for (int i = 0; i < 16; i++) {
			m[i] = 0;
		}
	}

	Matrix(const Matrix &other) {
		for (int i = 0; i < 16; i++) {
			m[i] = other.m[i];
		}
	}

	Matrix(const Matrix *other) {
		for (int i = 0; i < 16; i++) {
			m[i] = other->m[i];
		}
	}

	float& operator()(int i, int j) {
		return m[i*4 + j];
	}

	float operator()(int i, int j) const {
		return m[i*4 + j];
	}

	Matrix& operator= (const Matrix &other) {
		for (int i = 0; i < 16; i++) {
			m[i] = other.m[i];
		}

		return *this;
	}

	Matrix& operator= (const float *other) {
		for (int i = 0; i < 16; i++) {
			m[i] = other[i];
		}

		return *this;
	}

	bool operator== (const Matrix &other) {
		for (int i = 0; i < 16; i++) {
			if (m[i] != other.m[i]) {
				return false;
			}
		}

		return true;
	}

	bool operator!= (const Matrix &other) {

		return !operator==(other);
	}

	static void scale(Matrix *result, float sx, float sy, float sz)
	{
		result->m[0] *= sx;
		result->m[1] *= sx;
		result->m[2] *= sx;
		result->m[3] *= sx;

		result->m[4] *= sy;
		result->m[5] *= sy;
		result->m[6] *= sy;
		result->m[7] *= sy;

		result->m[8] *= sz;
		result->m[9] *= sz;
		result->m[10] *= sz;
		result->m[11] *= sz;
	}

	static void translate(Matrix *result, float tx, float ty, float tz)
	{
		result->m[12] += (result->m[0] * tx + result->m[4] * ty + result->m[8] * tz);
		result->m[13] += (result->m[1] * tx + result->m[5] * ty + result->m[9] * tz);
		result->m[14] += (result->m[2] * tx + result->m[6] * ty + result->m[10] * tz);
		result->m[15] += (result->m[3] * tx + result->m[7] * ty + result->m[11] * tz);
	}

	static void rotate(Matrix *result, float angle, float x, float y, float z)
	{
		float sinAngle = sinf(angle * M_PI / 180.0f);
		float cosAngle = cosf(angle * M_PI / 180.0f);
		float oneMinusCos = 1.0f - cosAngle;
		float mag = sqrtf(x * x + y * y + z * z);

		if (mag != 0.0f && mag != 1.0f) {
			x /= mag;
			y /= mag;
			z /= mag;
		}

		float xx = x * x;
		float yy = y * y;
		float zz = z * z;
		float xy = x * y;
		float yz = y * z;
		float zx = z * x;
		float xs = x * sinAngle;
		float ys = y * sinAngle;
		float zs = z * sinAngle;

		Matrix rotationMatrix;

		rotationMatrix.m[0] = (oneMinusCos * xx) + cosAngle;
		rotationMatrix.m[1] = (oneMinusCos * xy) - zs;
		rotationMatrix.m[2] = (oneMinusCos * zx) + ys;
		rotationMatrix.m[3] = 0.0f;

		rotationMatrix.m[4] = (oneMinusCos * xy) + zs;
		rotationMatrix.m[5] = (oneMinusCos * yy) + cosAngle;
		rotationMatrix.m[6] = (oneMinusCos * yz) - xs;
		rotationMatrix.m[7] = 0.0f;

		rotationMatrix.m[8] = (oneMinusCos * zx) - ys;
		rotationMatrix.m[9] = (oneMinusCos * yz) + xs;
		rotationMatrix.m[10] = (oneMinusCos * zz) + cosAngle;
		rotationMatrix.m[11] = 0.0f;

		rotationMatrix.m[12] = 0.0f;
		rotationMatrix.m[13] = 0.0f;
		rotationMatrix.m[14] = 0.0f;
		rotationMatrix.m[15] = 1.0f;

		multiply( result, &rotationMatrix, result );
	}

	static void frustum(Matrix *result, float left, float right, float bottom, float top, float nearZ, float farZ)
	{
		float deltaX = right - left;
		float deltaY = top - bottom;
		float deltaZ = farZ - nearZ;
		Matrix frust;

		assert(!((nearZ <= 0.0f) || (farZ <= 0.0f) || (deltaX <= 0.0f) || (deltaY <= 0.0f) || (deltaZ <= 0.0f)));

		frust.m[0] = 2.0f * nearZ / deltaX;
		frust.m[1] = frust.m[2] = frust.m[3] = 0.0f;

		frust.m[5] = 2.0f * nearZ / deltaY;
		frust.m[4] = frust.m[6] = frust.m[7] = 0.0f;

		frust.m[8] = (right + left) / deltaX;
		frust.m[9] = (top + bottom) / deltaY;
		frust.m[10] = -(nearZ + farZ) / deltaZ;
		frust.m[11] = -1.0f;

		frust.m[14] = -2.0f * nearZ * farZ / deltaZ;
		frust.m[12] = frust.m[13] = frust.m[15] = 0.0f;

		multiply(result, &frust, result);
	}

	static void perspective(Matrix *result, float fovy, float aspect, float nearZ, float farZ)
	{
		float frustumHeight = tanf(fovy / 360 * M_PI) * nearZ;
		float frustumWidth = frustumHeight * aspect;

		frustum( result, -frustumWidth, frustumWidth, -frustumHeight, frustumHeight, nearZ, farZ );
	}

	static void ortho(Matrix *result, float left, float right, float bottom, float top, float nearZ, float farZ)
	{
		float deltaX = right - left;
		float deltaY = top - bottom;
		float deltaZ = farZ - nearZ;
		Matrix ortho;

		assert(!((deltaX == 0) || (deltaY == 0) || (deltaZ == 0)));

		loadIdentity(&ortho);
		ortho.m[0] = 2 / deltaX;
		ortho.m[12] = -(right + left) / deltaX;
		ortho.m[5] = 2 / deltaY;
		ortho.m[13] = -(top + bottom) / deltaY;
		ortho.m[10] = -2 / deltaZ;
		ortho.m[14] = -(nearZ + farZ) / deltaZ;

		multiply(result, &ortho, result);
	}

	static void multiply(Matrix *result, const Matrix * const srcA, const Matrix * const srcB)
	{
		Matrix tmp;

		for (int i = 0; i < 4; i++)
		{
			int a = 4*i;
			int b = a + 1;
			int c = a + 2;
			int d = a + 3;

			tmp.m[a] =	srcA->m[a] * srcB->m[0] +
			srcA->m[b] * srcB->m[4] +
			srcA->m[c] * srcB->m[8] +
			srcA->m[d] * srcB->m[12];

			tmp.m[b] =	srcA->m[a] * srcB->m[1] +
			srcA->m[b] * srcB->m[5] +
			srcA->m[c] * srcB->m[9] +
			srcA->m[d] * srcB->m[13];

			tmp.m[c] =	srcA->m[a] * srcB->m[2] +
			srcA->m[b] * srcB->m[6] +
			srcA->m[c] * srcB->m[10] +
			srcA->m[d] * srcB->m[14];

			tmp.m[d] =	srcA->m[a] * srcB->m[3] +
			srcA->m[b] * srcB->m[7] +
			srcA->m[c] * srcB->m[11] +
			srcA->m[d] * srcB->m[15];
		}

		memcpy(result, &tmp, sizeof(Matrix));
	}

	static void multiply(Matrix *result, const Matrix * const srcA, const float* const srcB)
	{
		Matrix tmp;

		for (int i = 0; i < 4; i++)
		{
			int a = 4*i;
			int b = a + 1;
			int c = a + 2;
			int d = a + 3;

			tmp.m[a] =	srcA->m[a] * srcB[0] +
			srcA->m[b] * srcB[4] +
			srcA->m[c] * srcB[8] +
			srcA->m[d] * srcB[12];

			tmp.m[b] =	srcA->m[a] * srcB[1] +
			srcA->m[b] * srcB[5] +
			srcA->m[c] * srcB[9] +
			srcA->m[d] * srcB[13];

			tmp.m[c] =	srcA->m[a] * srcB[2] +
			srcA->m[b] * srcB[6] +
			srcA->m[c] * srcB[10] +
			srcA->m[d] * srcB[14];

			tmp.m[d] =	srcA->m[a] * srcB[3] +
			srcA->m[b] * srcB[7] +
			srcA->m[c] * srcB[11] +
			srcA->m[d] * srcB[15];
		}

		memcpy(result, &tmp, sizeof(Matrix));
	}

	static void loadIdentity(Matrix *result)
	{
		memset(result, 0x0, sizeof(Matrix));
		result->m[0] = 1;
		result->m[5] = 1;
		result->m[10] = 1;
		result->m[15] = 1;
	}

	static void transpose(Matrix *result)
	{
		Matrix tmp;

		tmp.m[0] = result->m[0];
		tmp.m[1] = result->m[4];
		tmp.m[2] = result->m[8];
		tmp.m[3] = result->m[12];
		tmp.m[4] = result->m[1];
		tmp.m[5] = result->m[5];
		tmp.m[6] = result->m[9];
		tmp.m[7] = result->m[13];
		tmp.m[8] = result->m[2];
		tmp.m[9] = result->m[6];
		tmp.m[10] = result->m[10];
		tmp.m[11] = result->m[14];
		tmp.m[12] = result->m[3];
		tmp.m[13] = result->m[7];
		tmp.m[14] = result->m[11];
		tmp.m[15] = result->m[15];

		memcpy(result, &tmp, sizeof(Matrix));
	}

	static void inverse(Matrix *result, const Matrix * const src)
	{
		int swap;
		float t;
		float temp[4][4];

		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				temp[i][j] = (*src)(i, j);
			}
		}

		loadIdentity(result);

		for (int i = 0; i < 4; i++) {
			swap = i;
			for (int j = i + 1; j < 4; j++) {
				if (fabs(temp[j][i]) > fabs(temp[i][i])) {
					swap = j;
				}
			}

			if (swap != i) {
				for (int k = 0; k < 4; k++) {
					t = temp[i][k];
					temp[i][k] = temp[swap][k];
					temp[swap][k] = t;

					t = (*result)(i, k);
					(*result)(i, k) = (*result)(swap, k);
					(*result)(swap, k) = t;
				}
			}

			assert(temp[i][i] != 0);
			t = temp[i][i];
			for (int k = 0; k < 4; k++) {
				temp[i][k] /= t;
				(*result)(i, k) /= t;
			}
			for (int j = 0; j < 4; j++) {
				if (j != i) {
					t = temp[j][i];
					for (int k = 0; k < 4; k++) {
						temp[j][k] -= temp[i][k] * t;
						(*result)(j, k) -= (*result)(i, k) * t;
					}
				}
			}
		}
	}

	static float clamp(float t, float minV, float maxV)
	{
		return MAX_F(MIN_F(maxV, t), minV);
	}

	float m[16];
};
#endif // MATRIX_H
