#include <cstdio>
#include <cstring>
#include <algorithm>
#include <set>

#include "system.h"
#include "common.h"
#include "commonmath.h"
#include "options.h"
#include "platform.h"

#include "state.h"
#include "pointer.h"
#include "glstate.h"
#include "matrix.h"

#include "gamestate.h"

using namespace std;

System::System() :
	mResources(),
	mPreviousTime(0.0),
	mPreviousState(NULL),
	mGameState(NULL),
	mCurrentState(NULL),
	mNextState(NULL)
{
	Options.Load();
}

System::~System()
{
	if(mCurrentState != NULL) {
		mCurrentState->LeaveState();
	}

	if(mGameState != NULL) {
		delete mGameState;
		mGameState = NULL;
	}
	
	foreach(it, mPointers) {
		if(it->second != NULL) {
			it->second->isDown = false;
			delete it->second;
		}
	}
	mPointers.clear();
}

Resources & System::GetResources()
{
	return mResources;
}

void System::SurfaceCreated()
{
	if(mGameState == NULL) {
		mGameState = new GameState(this);
	}
	if(mCurrentState == NULL)
	{
		gl_LoadShaders();
		mCurrentState = mGameState;
		mCurrentState->EnterState();
	}
	else
	{
		mResources.Reload();
	}
}

void System::SurfaceChanged(int width, int height)
{
	// Setup viewport
	glViewport(0, 0, width-(width%2), height-(height%2));

	// Setup matrices
	Matrix::loadIdentity(gl_projection);
	Matrix::ortho(gl_projection, 0.0f, (float)width, (float)height, 0.0f, -1.0f, 1.0f);
	Matrix::loadIdentity(gl_modelview);

	// Setup enabled functionality
	glEnable(GL_BLEND);

	// Setup disabled functionality
	glDisable(GL_DEPTH_TEST);
	
	// Configure enabled functionality
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);

}

void System::DrawFrame()
{
	double startTime = Platform::GetSeconds();
	double deltaTime = startTime - mPreviousTime;
	mPreviousTime = startTime;

	// Limit the maximimum delta time to keep physics stable during lag spikes
	deltaTime = MIN_F(deltaTime, 1.0 / 30.0);

	HandleEvents();
	
	// Update Current State
	mCurrentState->Update((float)deltaTime);

	// Change to another state
	if(mNextState != NULL) {
		TextureCacheLock lock;
		mCurrentState->LeaveState();
		mPreviousState = mCurrentState;
		mCurrentState = mNextState;
		mCurrentState->EnterState();
		mCurrentState->Update((float)deltaTime);
		mNextState = NULL;
	}

	// Draw the state
	glClear(GL_COLOR_BUFFER_BIT);
	mCurrentState->Draw();
}

void System::HandleEvents()
{
	while(!mTouchEventQueue.empty()) {
		touch_event & event = mTouchEventQueue.front();
		
		Pointer* p = mPointers[event.id];
		if (!p)
		{
			p = new Pointer();
			mPointers[event.id] = p;
			p->oldscreenposition.X = (float)event.x;
			p->oldscreenposition.Y = (float)event.y;
		}

		p->screenposition.X = (float)event.x;
		p->screenposition.Y = (float)event.y;

		switch(event.action)
		{
			case POINTER_DOWN:
				p->isDown = true;
				mCurrentState->PointerDown(p);
				break;
			case POINTER_UP:
				p->isDown = false;
				mCurrentState->PointerUp(p);
				mPointers.erase(event.id);
				delete p;
				break;
		}
		mTouchEventQueue.pop();
	}

	while(!mKeyEventQueue.empty()) {
		key_event & event = mKeyEventQueue.front();
		if(event.action == KEY_UP) {
			mCurrentState->KeyUp(event.key);
		} else {
			mCurrentState->KeyDown(event.key);
		}
		mKeyEventQueue.pop();
	}
}

void System::TouchEvent(int id, int action, int x, int y)
{
	touch_event event = { id, action, x, y, Platform::GetSeconds() };
	mTouchEventQueue.push(event);
}

void System::KeyUp(int id)
{
	key_event event = {KEY_UP, id};
	mKeyEventQueue.push(event);
}

void System::KeyDown(int id)
{
	key_event event = {KEY_DOWN, id};
	mKeyEventQueue.push(event);
}

State * System::GetState()
{
	return mCurrentState;
}

void System::ChangeState(State * newState)
{
	assert(mNextState == NULL);
	mNextState = newState;
}
