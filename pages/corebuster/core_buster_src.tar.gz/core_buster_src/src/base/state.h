#ifndef __STATE_H__
#define __STATE_H__

class System;
class Pointer;
class State
{
	public:
		virtual ~State() { }
		virtual void Update(float dt) = 0;
		virtual void Draw() = 0;
		virtual void EnterState() = 0;
		virtual void LeaveState() = 0;
		virtual void PointerDown(Pointer *p) = 0;
		virtual void PointerUp(Pointer *p) = 0;
		virtual void KeyDown(int key) {}
		virtual void KeyUp(int key) {}
		System * GetSystem() { return mSystem; }

	protected:
		State(System * system) : mSystem(system) { }
		System * mSystem;
};

#endif
