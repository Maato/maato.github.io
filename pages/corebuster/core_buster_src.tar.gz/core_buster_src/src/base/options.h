#ifndef __OPTIONS_H__
#define __OPTIONS_H__

#include <map>

#include "properties.h"

struct Options
{
	std::map<std::string, Properties> mSections;
	Properties & GetSection(std::string name);
	void Load();
	void Save();

	private:
		void Parse(char * data);
};

extern Options Options;

#endif
