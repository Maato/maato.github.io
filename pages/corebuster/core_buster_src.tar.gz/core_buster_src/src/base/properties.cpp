#include <cstdio>
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>
#include <cstring>

#include "properties.h"
#include "platform.h"
#include "common.h"

using namespace std;

const Properties Properties::Empty = Properties();

SerializedObject::SerializedObject()
{
}

SerializedObject::SerializedObject(std::string name, Properties properties) :
	name(name),
	properties(properties)
{
}

void SerializedObject::Write(FILE * file)
{
	fprintf(file, "%s", name.c_str());

	/* If there is at least one property we need to put in a space to
	 * separate it from the object name */
	if(properties.GetItems().size() > 0) {
		fprintf(file, " ");
		properties.Write(file);
	}
	fprintf(file, "\n");
}

Properties::Properties()
{
}

Properties::~Properties()
{
}

static bool sortPairByFirst(std::pair<std::string,std::string> a,
		std::pair<std::string,std::string> b) {
	return a.first.compare(b.first) < 0;
}

void Properties::Write(FILE * file)
{
	std::vector< std::pair<std::string, std::string> > items;
	foreach(p, mItems) {
		items.push_back(*p);
	}
	sort(items.begin(), items.end(), sortPairByFirst);

	for(uint i = 0; i < items.size(); i++) {
		const char * name = items[i].first.c_str();
		const char * value = items[i].second.c_str();
		/* If the value contains spaces it must be quoted */
		if(strchr(value, ' ') != NULL) {
			fprintf(file, "%s=\"%s\"", name, value);
		} else {
			fprintf(file, "%s=%s", name, value);
		}
		/* Print a space if there are more items to come */
		if(i+1 < items.size()) {
			fprintf(file, " ");
		}
	}
}

void Properties::Set(string name, string value)
{
	mItems[name] = value;
}

void Properties::Set(string name, bool value)
{
	stringstream ss;
	if(value) {
		ss << "True";
	} else {
		ss << "False";
	}
	Set(name, ss.str());
}

void Properties::Set(string name, int value)
{
	stringstream ss;
	ss << value;
	Set(name, ss.str());
}

void Properties::Set(string name, float value)
{
	stringstream ss;
	ss << value;
	Set(name, ss.str());
}

void Properties::Set(string name, Vector value)
{
	stringstream ss;
	ss << "(" << value.X << "," << value.Y << ")";
	Set(name, ss.str());
}

bool Properties::TryGetInt(string name, int * value) const
{
	map<string,string>::const_iterator it = mItems.find(name);
	if(it == mItems.end())
		return false;
	return sscanf(it->second.c_str(), "%10d", value) == 1;
}
int Properties::GetInt(string name, int defaultValue) const
{
	int v = defaultValue; TryGetInt(name, &v); return v;
}

bool Properties::TryGetBool(string name, bool * value) const
{
	map<string,string>::const_iterator it = mItems.find(name);
	if(it == mItems.end())
		return false;
	if(it->second == "True" || it->second == "true") {
		*value = true;
	} else if(it->second == "False" || it->second == "false") {
		*value = false;
	} else {
		return false;
	}
	return true;
}
bool Properties::GetBool(string name, bool defaultValue) const
{
	bool v = defaultValue; TryGetBool(name, &v); return v;
}

bool Properties::TryGetFloat(string name, float * value) const
{
	map<string,string>::const_iterator it = mItems.find(name);
	if(it == mItems.end())
		return false;
	return sscanf(it->second.c_str(), "%20f", value) == 1;
}
float Properties::GetFloat(string name, float defaultValue) const
{
	float v = defaultValue; TryGetFloat(name, &v); return v;
}

bool Properties::TryGetVector(string name, Vector * value) const
{
	map<string,string>::const_iterator it = mItems.find(name);
	if(it == mItems.end())
		return false;
	return sscanf(it->second.c_str(), "(%20f,%20f)", &(value->X), &(value->Y)) == 2;
}
Vector Properties::GetVector(string name, Vector defaultValue) const
{
	Vector v = defaultValue; TryGetVector(name, &v); return v;
}

bool Properties::TryGetString(string name, string * value) const
{
	map<string,string>::const_iterator it = mItems.find(name);
	if(it == mItems.end())
		return false;
	*value = it->second;
	return true;
}
string Properties::GetString(string name, string defaultValue) const
{
	string v = defaultValue; TryGetString(name, &v); return v;
}

void Properties::Add(string name, string value)
{
	mItems[name] = value;
}

void Properties::AddFromString(char * buffer)
{
	int i = 0;

	// Skip over whitespace
	for(; buffer[0] == ' '; buffer++);
	
	// Read properties
	while(buffer[0])
	{
		int quoted = 0;
		char * property_name = NULL;
		char * property_value = NULL;

		// Read property name
		property_name = buffer;
		for(i = 0; buffer[i]; i++)
		{
			if(buffer[i] == ' ')
			{
				Platform::LogError("Property parsing error\n"
					"property name cannot contain spaces\n"
					"buffer contents: '%s'\n", buffer);
				Platform::ReportFailure("property == valid", __FILE__, __LINE__, __func__);
			}
			else if(buffer[i] == '=')
			{
				if(buffer[i+1] == '"')
				{
					buffer[i] = '\0';
					buffer[i+1] = '\0';
					buffer = &buffer[i+2];
					quoted = 1;
					break;
				}
				else
				{
					buffer[i] = '\0';
					buffer = &buffer[i+1];
					break;
				}
			}
		}

		// Was the property name read?
		if(property_name == buffer)
		{
			Platform::LogError("Property parsing error\n"
				"buffer contents: '%s'\n", buffer);
			Platform::ReportFailure("property == valid", __FILE__, __LINE__, __func__);
		}

		// Read property value
		property_value = buffer;
		for(i = 0; buffer[i]; i++)
		{
			if(quoted && buffer[i] == '"')
			{
				buffer[i] = '\0';
				buffer = &buffer[i+1];
				break;
			}
			else if(!quoted)
			{
				if(buffer[i] == ' ' || buffer[i] == '\n' || buffer[i] == '\r')
				{
					buffer[i] = '\0';
					buffer = &buffer[i+1];
					break;
				}
				else if(buffer[i+1] == '\0')
				{
					buffer = &buffer[i+1];
					break;
				}
			}
		}

		// Was the property value read?
		if(property_value == buffer)
		{
			Platform::LogError("Property parsing error\n"
				"property name: '%s'\n"
				"buffer contents: '%s'\n", property_name, buffer);
			Platform::ReportFailure("property == valid", __FILE__, __LINE__, __func__);
		}

		// Skip over whitespace
		for(; buffer[0] == ' ' || buffer[0] == '\n' || buffer[0] == '\r'; buffer++);

		mItems[property_name] = property_value;
	}
}

std::map<std::string, std::string> Properties::GetItems() const
{
	return mItems;
}

uint Properties::GetSize() const
{
	return mItems.size();
}