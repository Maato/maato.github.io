#include "texture2dprogram.h"
#include "glstate.h"
#include "resources.h"
#include "matrix.h"
#include "texture.h"

Texture2DProgram::Texture2DProgram(const char * vert, const char * frag) :
	GProgram(vert, frag),
	a_position(0),
	a_texcoord(0),
	u_mvp(0),
	s_sampler(0)
{
}

bool Texture2DProgram::Build()
{
	if(!GProgram::Build()) {
		return false;
	}

	a_position = GetAttribLocation("a_position");
	a_texcoord = GetAttribLocation("a_texcoord");
	u_mvp = GetUniformLocation("u_mvp");
	s_sampler = GetUniformLocation("s_sampler");
	if(a_position < 0 || a_texcoord < 0 || u_mvp < 0 || s_sampler < 0) {
		return false;
	}
	return true;
}

void Texture2DProgram::Use()
{
	GProgram::Use();
	glEnableVertexAttribArray(a_position);
	glEnableVertexAttribArray(a_texcoord);
	Matrix mvp;
	gl_GetModelViewProjection(&mvp);
	glUniformMatrix4fv(u_mvp, 1, false, (GLfloat*)&mvp);
	glUniform1i(s_sampler, 0);
}

void Texture2DProgram::Unuse()
{
	glDisableVertexAttribArray(a_position);
	glDisableVertexAttribArray(a_texcoord);
	GProgram::Unuse();
}

void Texture2DProgram::VertexPointer(void *p) const
{
	glVertexAttribPointer(a_position, 2, GL_FLOAT, GL_FALSE, 0, p);
}

void Texture2DProgram::TexCoordPointer(void *p) const
{
	glVertexAttribPointer(a_texcoord, 2, GL_FLOAT, GL_FALSE, 0, p);
}

void Texture2DProgram::VertexPointer(void *p, int stride) const
{
	glVertexAttribPointer(a_position, 2, GL_FLOAT, GL_FALSE, stride, p);
}

void Texture2DProgram::TexCoordPointer(void *p, int stride) const
{
	glVertexAttribPointer(a_texcoord, 2, GL_FLOAT, GL_FALSE, stride, p);
}


ColorTexture2DProgram::ColorTexture2DProgram(const char * vert, const char * frag) :
	Texture2DProgram(vert, frag),
	r(1.0f), g(1.0f), b(1.0f), a(1.0f),
	u_color(0)
{
}

bool ColorTexture2DProgram::Build()
{
	if(!Texture2DProgram::Build()) {
		return false;
	}

	u_color = GetUniformLocation("u_color");
	if(u_color < 0) {
		return false;
	}
	return true;
}

void ColorTexture2DProgram::Use()
{
	Texture2DProgram::Use();
	glUniform4f(u_color, r, g, b, a);
}

void ColorTexture2DProgram::SetColor(float r, float g, float b, float a)
{
	this->r = r;
	this->g = g;
	this->b = b;
	this->a = a;
}
