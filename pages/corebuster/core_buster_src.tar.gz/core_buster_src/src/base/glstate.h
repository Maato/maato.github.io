#ifndef __GLSTATE_H__
#define __GLSTATE_H__

#include "opengl.h"

struct Matrix;
extern Matrix * gl_projection;
extern Matrix * gl_modelview;

void gl_PushModelView();
void gl_PopModelView();
void gl_PopProjection();
void gl_PushProjection();
void gl_GetModelViewProjection(Matrix*);
void gl_LoadShaders();

class Texture2DProgram;
class ColorTexture2DProgram;
class ColorProgram;

extern Texture2DProgram * gl_TextureProg;
extern ColorProgram * gl_ColorProg;
extern ColorTexture2DProgram * gl_ColorTextureProg;

#endif
