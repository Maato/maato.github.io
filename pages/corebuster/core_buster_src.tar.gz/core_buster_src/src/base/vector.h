#ifndef __VECTOR_H__
#define __VECTOR_H__

#include <cmath>

class Vector
{
	public:
		Vector() : X(0), Y(0){};
		Vector(float x, float y) : X(x), Y(y){};
		float X;
		float Y;

		static const Vector Zero;
		static const Vector XAxis;
		static const Vector YAxis;

		// * operator
		inline Vector operator*(const Vector& rhs) const { return Vector(X*rhs.X,Y*rhs.Y); }
		inline Vector operator*(float rhs) const { return Vector(X*rhs,Y*rhs); }
		inline void operator*=(const Vector& rhs) { X *= rhs.X; Y *= rhs.Y; }
		inline void operator*=(float rhs) { X *= rhs; Y *= rhs; }

		// + operator
		inline Vector operator+(const Vector& rhs) const { return Vector(X+rhs.X, Y+rhs.Y); }
		inline void operator+=(const Vector& rhs) { X += rhs.X; Y += rhs.Y; }

		// - operator
		inline Vector operator-(const Vector& rhs) const { return Vector(X-rhs.X, Y-rhs.Y); }
		inline void operator-=(const Vector& rhs) { X -= rhs.X; Y -= rhs.Y; }

		// / operator
		inline Vector operator/(const Vector& rhs) const { return Vector(X/rhs.X, Y/rhs.Y); }
		inline Vector operator/(float rhs) const { return Vector(X/rhs, Y/rhs); }
		inline void operator/=(const Vector& rhs) { X /= rhs.X; Y /= rhs.Y; }
		inline void operator/=(float rhs) { X /= rhs; Y /= rhs; }

		inline bool operator==(const Vector& rhs) const { return X == rhs.X && Y == rhs.Y; }
		inline bool operator!=(const Vector& rhs) const { return X != rhs.X || Y != rhs.Y; }

		// Modifiers
		inline void Normalize() { float length = sqrtf(X*X+Y*Y); X /= length; Y /= length; }
		inline void PerpRight() { float swap = X; X = -Y; Y = swap; }
		inline void PerpLeft() { float swap = X; X = Y; Y = -swap; }

		// Other
		inline float GetDist(const Vector & o) const { return sqrtf((X-o.X)*(X-o.X) + (Y-o.Y)*(Y-o.Y)); }
		inline float GetDistSquared(const Vector & o) const { return (X-o.X)*(X-o.X) + (Y-o.Y)*(Y-o.Y); }
		inline float GetLength() const { return sqrtf(X * X + Y * Y); }
		inline Vector GetNormalized() const { float length = GetLength(); return Vector(X / length, Y / length); }
		inline Vector GetNormalizedOrZero() const { float length = GetLength(); return (length == 0.0f) ? Vector::Zero : Vector(X / length, Y / length); }
		inline Vector GetNormalizedOr(const Vector & v) const { float length = GetLength(); return (length == 0.0f) ? v : Vector(X / length, Y / length); }
		inline Vector GetNegative() const { return Vector(-X, -Y); }
		inline Vector GetRightHandNormal() const { return Vector(-Y, X); }
		inline Vector GetLeftHandNormal() const { return Vector(Y, -X); }
		inline float GetDotProduct(const Vector & other) const { return X * other.X + Y * other.Y; }
		inline float GetCrossProduct(const Vector & other) const { return X * other.Y - Y * other.X; }
		inline float GetPerProduct(const Vector & other) const { return GetDotProduct(other.GetRightHandNormal()); }
};

#endif
