#ifndef __IMAGE_LOADER_H__
#define __IMAGE_LOADER_H__

#include <cstdint>
#include <cstdio>

struct ImageData
{
	uint32_t width;
	uint32_t height;
	int32_t internalFormat;
	uint8_t * data;
};

extern ImageData * imageloader_load_png(FILE * pngfile);
extern ImageData * imageloader_create_placeholder();
extern void imageloader_destroy(ImageData * image);

#endif
