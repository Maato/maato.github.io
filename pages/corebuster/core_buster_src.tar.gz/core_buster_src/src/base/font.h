#ifndef __FONT_H__
#define __FONT_H__

#include <vector>

#include "vector.h"

struct Texture;
struct Vbo;
struct ImageData;
struct Rect
{
	int x, y;
	int h, w;
};

class Font
{
	Texture * mAtlas;
	unsigned char mIndices[256];
	Rect mSizes[256];
	int mLineStride;
	int mLetterSpacing;

	public:
		Font(ImageData * imageData, Texture * texture, int lineStride, int letter_spacing, const char * alphabet);
		~Font();
		Texture * GetTexture();
		Vector PrepareText(std::vector<Vector>&, const char * text);

	private:
		void ParseTexture(ImageData * imageData, const char * alphabet, int height);
};

class CompiledText
{
	Vector mSize;
	float mScale;
	float mA, mR, mG, mB;
	Font * mFont;
	std::vector<Vector> mVerts;
	Vbo * mBuffer;
	char * mText;
	
	public:
		CompiledText(const char * fontname);
		CompiledText(Font * font);
		~CompiledText();
		void SetScale(float scale);
		void SetColor(float r, float g, float b, float a);
		Vector GetSize() const;
		void SetText(const char * format, ...);
		void DrawCentered(Vector position);
		void Draw(Vector position);
};

#endif
