#include "colorprogram.h"
#include "glstate.h"
#include "matrix.h"
#include "resources.h"

ColorProgram::ColorProgram(const char * vert, const char * frag) :
	GProgram(vert, frag),
	a_position(0),
	u_mvp(0),
	u_color(0)
{
}

bool ColorProgram::Build()
{
	if(!GProgram::Build()) {
		return false;
	}

	a_position = GetAttribLocation("a_position");
	u_mvp = GetUniformLocation("u_mvp");
	u_color = GetUniformLocation("u_color");
	if(a_position < 0 || u_mvp < 0 || u_color < 0) {
		return false;
	}
	return true;
}

void ColorProgram::Use()
{
	GProgram::Use();
	glEnableVertexAttribArray(a_position);
	Matrix mvp;
	gl_GetModelViewProjection(&mvp);
	glUniformMatrix4fv(u_mvp, 1, false, (GLfloat*)&mvp);
}

void ColorProgram::Unuse()
{
	glDisableVertexAttribArray(a_position);
	GProgram::Unuse();
}

void ColorProgram::VertexPointer(void *p) const
{
	glVertexAttribPointer(a_position, 2, GL_FLOAT, GL_FALSE, 0, p);
}

void ColorProgram::SetColor(float r, float g, float b, float a)
{
	glUniform4f(u_color, r, g, b, a);
}
