#ifndef COMMONGL_H
#define COMMONGL_H

#include "opengl.h"
#include "commonmath.h"
#include "texture.h"
#include "platform.h"
#include "quad.h"
#include "vector.h"
#include "color.h"
#include "texture2dprogram.h"
#include "colorprogram.h"

inline void DrawColoredQuad(const Quad * vertices, Color color)
{
	gl_ColorProg->VertexPointer((void*)vertices);
	gl_ColorProg->Use();
	gl_ColorProg->SetColor(color.R, color.G, color.B, color.A);
	glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}

inline void DrawTexturedQuad(const Quad * vertices, const Quad * texcoords)
{
	gl_TextureProg->VertexPointer((void*)vertices);
	gl_TextureProg->TexCoordPointer((void*)texcoords);
	gl_TextureProg->Use();
	glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}

inline void DrawTexturedQuad(Vector position, Vector size, const Quad * texcoords)
{
	Quad vertices = Quad(position, size);
	DrawTexturedQuad(&vertices, texcoords);
}

inline void DrawTexturedQuad(const Texture * texture, const Quad * vertices, const Quad * texcoords)
{
	glBindTexture(GL_TEXTURE_2D, texture->id);
	DrawTexturedQuad(vertices, texcoords);
}

inline void DrawTexturedQuad(const Texture * texture, Vector position, Vector size, const Quad * texcoords)
{
	Quad vertices = Quad(position, size);
	DrawTexturedQuad(texture, &vertices, texcoords);
}

inline void DrawTexture(const Texture * texture, const Quad * vertices)
{
	DrawTexturedQuad(texture, vertices, &(Quad::One));
}

inline void DrawTexture(const Texture * texture, Vector position, Vector size)
{
	DrawTexturedQuad(texture, position, size, &(Quad::One));
}

inline void DrawCenteredTexture(const Texture * texture, Vector position, Vector size, const Quad * texcoords)
{
	DrawTexturedQuad(texture, position-size*0.5f, size, texcoords);
}

inline void DrawCenteredTexture(const Texture * texture, Vector position, Vector size)
{
	DrawCenteredTexture(texture, position, size, &(Quad::One));
}

inline void DrawCircle(Color color, Vector position, float radius, int segments)
{
	std::vector<Vector> vertices;
	for (int i = 0; i < segments; i++)
	{
		float a = (float)(M_PI * 2.0f / segments * i);
		vertices.push_back(Vector(position.X + radius * (float)cos(a), position.Y + radius * (float)sin(a)));
	}

	gl_ColorProg->VertexPointer(&(vertices[0]));
	gl_ColorProg->Use();
	gl_ColorProg->SetColor(color.R, color.G, color.B, color.A);
	glDrawArrays(GL_LINE_LOOP, 0, segments);
}

inline void DrawCircle(Vector position, float radius, int segments)
{
	DrawCircle(Color::White, position, radius, segments);
}

inline void DrawFilledRect(Vector topleft, Vector size, Color c) {
	Quad vertices = Quad(topleft, size);
	gl_ColorProg->VertexPointer(&vertices);
	gl_ColorProg->Use();
	gl_ColorProg->SetColor(c.R, c.G, c.B, c.A);
	glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}

inline void DrawRect(int left, int top, int width, int height, Color c)
{
	Vector vertices[4];
	vertices[0] = Vector(left, top);
	vertices[1] = Vector(left + width, top);
	vertices[2] = Vector(left + width, top + height);
	vertices[3] = Vector(left, top + height);
	gl_ColorProg->VertexPointer(vertices);
	gl_ColorProg->Use();
	gl_ColorProg->SetColor(c.R, c.G, c.B, c.A);
	glDrawArrays(GL_LINE_LOOP, 0, 4);
}

inline void DrawLine(Vector a, Vector b, Color c)
{
	Vector vertices[2] = {a,b};
	gl_ColorProg->VertexPointer(vertices);
	gl_ColorProg->Use();
	gl_ColorProg->SetColor(c.R, c.G, c.B, c.A);
	glDrawArrays(GL_LINE_LOOP, 0, 2);
}

#endif // COMMONGL_H
