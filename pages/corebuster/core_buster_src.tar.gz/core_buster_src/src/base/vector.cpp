#include "vector.h"

const Vector Vector::Zero = Vector();
const Vector Vector::XAxis = Vector(1.0f, 0.0f);
const Vector Vector::YAxis = Vector(0.0f, 1.0f);
