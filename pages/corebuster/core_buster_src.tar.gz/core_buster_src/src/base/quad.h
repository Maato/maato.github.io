#ifndef __QUAD_H__
#define __QUAD_H__

#include "vector.h"
#include "platform.h"
#include "resources.h"
#include "texture2dprogram.h"

struct Quad
{
	Vector TopLeft;
	Vector TopRight;
	Vector BottomLeft;
	Vector BottomRight;

	Quad() {}
	Quad(Vector position, Vector size) :
		TopLeft(position.X, position.Y),
		TopRight(position.X + size.X, position.Y),
		BottomLeft(position.X, position.Y + size.Y),
		BottomRight(position.X + size.X, position.Y + size.Y) {}
	Quad(Vector topLeft, Vector topRight, Vector bottomLeft, Vector bottomRight) :
		TopLeft(topLeft),
		TopRight(topRight),
		BottomLeft(bottomLeft),
		BottomRight(bottomRight) {}
	Quad(float top, float left, float right, float bottom) :
		TopLeft(left, top),
		TopRight(right, top),
		BottomLeft(left, bottom),
		BottomRight(right, bottom) {}

	static const Quad Zero;
	static const Quad One;
	static const Quad CenterOne;
};

struct Vbo;
class TexturedTriangleStrip
{
	Vector * mQuads;
	Vbo * mBuffer;
	bool mDataChanged;
	unsigned int mCapacity;

public:	
	TexturedTriangleStrip(unsigned int capacity) :
		mDataChanged(false),
		mCapacity(capacity)
	{
		mQuads = new Vector[capacity*6*2];
		int total_vectors = capacity*6*2;
		mBuffer = Resources::I->CreateBuffer((float*)&mQuads[0], total_vectors*2);
	}

	~TexturedTriangleStrip()
	{
		if(mQuads != NULL) {
			delete[] mQuads;
			mQuads = NULL;
		}
		Resources::I->FreeBuffer(mBuffer);
		mBuffer = NULL;
	}

	inline void SetQuad(unsigned i, const Quad & q)
	{
		assert(i < mCapacity);
		mQuads[i*12+0] = q.TopLeft;
		mQuads[i*12+2] = q.TopRight;
		mQuads[i*12+4] = q.BottomLeft;
		mQuads[i*12+6] = q.BottomRight;
		mQuads[i*12+8] = q.BottomRight;
		if (i > 0) {
			mQuads[i*12-2] = q.TopLeft;
		}
		mDataChanged = true;
	}

	inline void SetTexQuad(unsigned i, const Quad & tq)
	{
		assert(i < mCapacity);
		mQuads[i*12+1] = tq.TopLeft;
		mQuads[i*12+3] = tq.TopRight;
		mQuads[i*12+5] = tq.BottomLeft;
		mQuads[i*12+7] = tq.BottomRight;
		mQuads[i*12+9] = tq.BottomRight;
		if (i > 0) {
			mQuads[i*12-1] = tq.TopLeft;
		}
		mDataChanged = true;
	}

	inline void Set(unsigned i, const Quad & q, const Quad & tq)
	{
		assert(i < mCapacity);
		mQuads[i*12+0] = q.TopLeft;
		mQuads[i*12+2] = q.TopRight;
		mQuads[i*12+4] = q.BottomLeft;
		mQuads[i*12+6] = q.BottomRight;
		mQuads[i*12+8] = q.BottomRight;
		mQuads[i*12+1] = tq.TopLeft;
		mQuads[i*12+3] = tq.TopRight;
		mQuads[i*12+5] = tq.BottomLeft;
		mQuads[i*12+7] = tq.BottomRight;
		mQuads[i*12+9] = tq.BottomRight;
		if (i > 0) {
			mQuads[i*12-2] = q.TopLeft;
			mQuads[i*12-1] = tq.TopLeft;
		}
		mDataChanged = true;
	}

	inline void DrawArrays(unsigned int amount)
	{
		assert(amount <= mCapacity);
		if(mDataChanged) {
			Resources::I->UpdateBuffer(mBuffer);
			mDataChanged = false;
		}

		glBindBuffer(GL_ARRAY_BUFFER, mBuffer->id);
		gl_TextureProg->VertexPointer((char*)NULL + 0, 16);
		gl_TextureProg->TexCoordPointer((char*)NULL + 8, 16);
		gl_TextureProg->Use();
		glDrawArrays(GL_TRIANGLE_STRIP, 0, amount*6-2);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
	}
};

#endif
