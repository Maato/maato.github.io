#include <cstring>
#include <cstdlib>

#include "options.h"
#include "common.h"
#include "platform.h"

struct Options Options;

void Options::Save()
{
	/*Properties & props = mSections["DebugFlags"];*/

	FILE * file = Platform::OpenFileForWriting("options");
	foreach(it, mSections) {
		auto & section = it->first;
		auto & props = it->second;
		if(props.GetSize() > 0) {
			fprintf(file, "%s ", section.c_str());
			props.Write(file);
			fprintf(file, "\n");
		}
	}
	fclose(file);
}

void Options::Parse(char * data)
{
	int i = 0;
	while(data[i]) {
		char * section_name = &data[i];
		/* Read until a space is encountered */
		for(; data[i+1] && data[i] != ' '; ++i);
		/* Replace the space with null termination */
		data[i] = '\0';
		char * properties = &data[i+1];
		/* Search the newline which indicates the end of the properties */
		for(; data[i+1] && data[i] != '\n'; ++i);
		/* Replace the newline with null termination */
		data[i] = '\0';
		mSections[section_name] = Properties();
		mSections[section_name].AddFromString(properties);
		/* Move to one character after the newline, where the next section starts */
		i++;
	}
}

void Options::Load()
{
	FILE * file = Platform::OpenResource("options");
	if(file != NULL) {
		size_t filesize = get_filesize(file);
		char * data = (char*)malloc(filesize+1);
		data[filesize] = '\0';
		fread(data, filesize, 1, file);
		fclose(file);
		Parse(data);
		free(data);
	}

	/*Properties & props = mSections["DebugFlags"];*/
}

Properties & Options::GetSection(std::string name)
{
	std::map<std::string,Properties>::iterator it = mSections.find(name);
	if(it == mSections.end()) {
		mSections[name] = Properties();
		return mSections[name];
	} else {
		return it->second;
	}
}