#ifndef __PROPERTIES_H__
#define __PROPERTIES_H__

#include <map>
#include <string>
#include <list>
#include <cstdio>
#include "common.h"

#include "vector.h"

class Properties
{
	std::map<std::string, std::string> mItems;

	public:
		static const Properties Empty;

		Properties();
		~Properties();
		void Write(FILE * file);		

		void Add(std::string,std::string);
		void AddFromString(char * properties);
		
		void Set(std::string, Vector);
		void Set(std::string, bool);
		void Set(std::string, int);
		void Set(std::string, float);
		void Set(std::string, std::string);

		bool TryGetInt(std::string, int*) const;
		int GetInt(std::string name, int defaultValue) const;
		bool TryGetBool(std::string, bool*) const;
		bool GetBool(std::string name, bool defaultValue) const;
		bool TryGetFloat(std::string, float*) const;
		float GetFloat(std::string name, float defaultValue) const;
		bool TryGetVector(std::string, Vector*) const;
		Vector GetVector(std::string name, Vector defaultValue) const;
		bool TryGetString(std::string, std::string*) const;
		std::string GetString(std::string name, std::string defaultValue) const;

		std::map<std::string, std::string> GetItems() const;
		uint GetSize() const;

};

class SerializedObject
{
	public:
		std::string name;
		Properties properties;
		SerializedObject();
		SerializedObject(std::string,Properties);
		void Write(FILE * file);
};

#endif
