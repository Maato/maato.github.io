#ifndef __RESOURCES_H__
#define __RESOURCES_H__

#include <map>
#include <vector>
#include <string>

#include "platform.h"
#include "opengl.h"

#define Res (*Resources::I)

struct Vbo
{
	GLuint id;
	GLfloat * source;
	int float_count;
};

struct TextureCacheLock
{
	TextureCacheLock();
	~TextureCacheLock();
};

struct Texture;
struct ImageData;
class Font;
class GProgram;
class Resources
{
	friend struct TextureCacheLock;

	int mTextureCacheLocks;
	std::map<std::string, std::pair<Texture*,int> > mTextures;
	std::map<std::string, Font*> mFonts;
	std::map<std::string, GProgram*> mPrograms;
	std::vector<Vbo*> mBuffers;
	
	public:
		static Resources * I;
		Resources();
		~Resources();
		void Reload();
		Texture * LoadTexture(const char*);
		Texture * LoadTexture(const char*, GLuint wrap, GLuint filter);
		char * GetText(const char*);
		void AcquireTexture(Texture * texture);
		void ReleaseTexture(Texture * texture);
		Vbo * CreateBuffer(GLfloat * data, int float_count);
		void UpdateBuffer(Vbo * buffer);
		void FreeBuffer(Vbo * vbo);
		Font * GetFont(const char * name);
		GProgram * GetProgram(const char*);
		void RegisterProgram(const char*,GProgram*);
		void ReloadShaders();

	private:
		ImageData * LoadImage(const char * name);
		void LoadTexture(Texture * texture, ImageData * image);
		void CreateBuffer(Vbo * vbo);
		void LockTextureCache();
		void UnlockTextureCache();
};

#endif
