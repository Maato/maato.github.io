#include <png.h>
#include <cstdlib>
#include <cstdio>

#include "common.h"
#include "imageloader.h"
#include "opengl.h"

ImageData * imageloader_create_placeholder()
{
	int channels = 3;
	ImageData * image = (ImageData*)malloc(sizeof(ImageData));
	image->width = 16;
	image->height = 16;
	image->internalFormat = GL_RGB;
	image->data = (uint8_t*)malloc(channels * image->width * image->height);

	// Draw cross
	typedef struct { uint8_t r, g, b; } ColorType;
	ColorType * color = (ColorType*)image->data;
	for(uint32_t y = 0; y < image->height; y++) {
		for(uint32_t x = 0; x < image->width; x++) {
			if(x == y || (image->width-x) == y || x == (image->width-x) || y == (image->height-y)) {
				ColorType c = { 0xff, 0x00, 0x00 };
				*color++ = c;
			} else {
				ColorType c = { 0x15, 0x15, 0x15 };
				*color++ = c;
			}
		}
	}

	return image;
}

ImageData * imageloader_load_png(FILE * png)
{
	unsigned char header[8];
	png_structp png_ptr = NULL;
	png_infop info_ptr = NULL;

	fread(header, 1, 8, png);
	if(png_sig_cmp(header, 0, 8)) {
		return NULL;
	}

	png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
	if(png_ptr == NULL) {
		return NULL;
	}

	info_ptr = png_create_info_struct(png_ptr);
	if(info_ptr == NULL) {
		png_destroy_read_struct(&png_ptr, NULL, NULL);
		return NULL;
	}

	if(setjmp(png_jmpbuf(png_ptr))) {
		png_destroy_read_struct(&png_ptr, &info_ptr, NULL);
		return NULL;
	}

	png_init_io(png_ptr, png);
	png_set_sig_bytes(png_ptr, 8);
	
	png_read_info(png_ptr, info_ptr);
	
	ImageData * image_data = (ImageData*)malloc(sizeof(ImageData));
	int bit_depth = 0;
	int color_type = 0;
	int interlace_type = 0;
	int channels = 0;
	png_uint_32 twidth, theight;
	png_get_IHDR(png_ptr, info_ptr, &twidth, &theight, &bit_depth, &color_type, &interlace_type, NULL, NULL);

	if(interlace_type != PNG_INTERLACE_NONE) {
		png_set_interlace_handling(png_ptr);
	}

	if(color_type & PNG_COLOR_MASK_ALPHA) {
		channels = 4;
		image_data->internalFormat = GL_RGBA;
	} else {
		channels = 3;
		image_data->internalFormat = GL_RGB;
	}

	if(color_type == PNG_COLOR_TYPE_PALETTE) {
		png_set_expand(png_ptr);
	}
	if(color_type == PNG_COLOR_TYPE_GRAY && bit_depth < 8) {
		png_set_expand(png_ptr);
	}
	if(color_type == PNG_COLOR_TYPE_GRAY) {
		channels = 1;
		image_data->internalFormat = GL_LUMINANCE;
	}
	if(color_type == PNG_COLOR_TYPE_GRAY_ALPHA) {
		channels = 2;
		image_data->internalFormat = GL_LUMINANCE_ALPHA;
	}

	// add alpha channel (fill with transparency information) if available
	if (png_get_valid(png_ptr, info_ptr, PNG_INFO_tRNS)) {
		png_set_expand(png_ptr);
		channels = 4; 
		image_data->internalFormat = GL_RGBA;
	}

	image_data->width = twidth;
	image_data->height = theight;
	image_data->data = (uint8_t*)malloc(twidth * theight * channels);

	png_read_update_info(png_ptr, info_ptr);

	if(setjmp(png_jmpbuf(png_ptr))) {
		free(image_data->data);
		free(image_data);
		png_destroy_read_struct(&png_ptr, &info_ptr, NULL);
		return NULL;
	}

	png_bytep * row_pointers = (png_bytep*)malloc(sizeof(png_bytep) * image_data->height);
	for(uint y = 0; y < image_data->height; y++) {
		row_pointers[y] = &image_data->data[y * image_data->width * channels];
	}
	png_read_image(png_ptr, row_pointers);

	free(row_pointers);

	png_destroy_read_struct(&png_ptr, &info_ptr, NULL);
	return image_data;
}

void imageloader_destroy(ImageData * image)
{
	if(image != NULL) {
		if(image->data != NULL) {
			free(image->data);
		}
		free(image);
	}
}
