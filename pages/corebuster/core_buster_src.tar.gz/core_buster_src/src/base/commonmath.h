#ifndef COMMONMATH_H
#define COMMONMATH_H
#include <stdlib.h>
#include <cmath>
#ifdef _WIN32
#define M_PI 3.14159265f
#include <math.h>

inline double rint(double x) { return (double)((int)(x+0.5)); }
inline float rintf(float x) { return (float)((int)(x+0.5f)); }
#define roundf rintf
//inline float roundf(float x) { return (x-floor(x))>0.5 ? ceil(x) : floor(x); }
#endif

#include "vector.h"

#define M_2PI M_PI+M_PI

inline float atan2(Vector v) {
	return atan2(v.Y, v.X);
}

inline Vector moveToward(Vector v, Vector d, float angleMovement) {
	float angle = atan2(v);
	float desiredAngle = atan2(d);
	float angleDiff = desiredAngle - angle;
	while (angleDiff > M_PI) angleDiff -= M_2PI;
	while (angleDiff < -M_PI) angleDiff += M_2PI;

	if (fabs(angleDiff) < angleMovement)
		angle = desiredAngle;
	else if (angleDiff > 0.0f)
		angle += angleMovement;
	else if (angleDiff < 0.0f)
		angle -= angleMovement;

	return Vector(cos(angle), sin(angle));
}

// a % b, where the result will be between 0 and a.
inline float pfmod(float a, float b)
{
	float r = fmod(a, b);
	if (r<0.0f)	return r + b;
	else		return r;
}

// Random number between 0.0f and 1.0f.
inline float frand()
{
	return (float)rand()/(float)RAND_MAX;
}

inline float frand(float min, float max) {
	return frand()*(max-min)+min;
}

#endif // COMMONMATH_H
