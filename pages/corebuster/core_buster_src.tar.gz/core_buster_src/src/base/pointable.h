#ifndef __POINTABLE_H__
#define __POINTABLE_H__
class Pointable
{
	public:
		virtual ~Pointable() {}
};
#endif
