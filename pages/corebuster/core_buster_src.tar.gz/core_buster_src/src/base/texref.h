#ifndef __TEXREF_H__
#define __TEXREF_H__

struct Texture;
class TexRef
{
	public:
		Texture * Tex;

		TexRef(Texture * tex);
		~TexRef();
		TexRef(const TexRef & copy_from_me);
		TexRef & operator=(const TexRef & other);
		Texture* operator->() const;
		Texture* operator*() const;
};

#endif
