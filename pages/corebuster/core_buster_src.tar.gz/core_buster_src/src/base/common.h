#ifndef __COMMON_H__
#define __COMMON_H__

#include <cstdio>
#include <stdint.h>

#ifdef _WIN32
#define uint unsigned int
#define snprintf _snprintf
#endif

#ifdef _WIN32
#include <intrin.h>
inline int CTZ(uint32_t x) {
	unsigned long index;
	_BitScanForward(&index, x);
	return index;
}
#else
#define CTZ __builtin_ctz
#endif

static __inline int CLAMP(int v, int minval, int maxval)
{
	return v < minval ? minval : (v > maxval ? maxval : v);
}

static __inline float CLAMP_F(float v, float minval, float maxval)
{
	return v < minval ? minval : (v > maxval ? maxval : v);
}

static __inline int MAX(int a, int b)
{
	return a > b ? a : b;
}

static __inline int MIN(int a, int b)
{
	return a < b ? a : b;
}

static __inline float MAX_F(float a, float b)
{
	return a > b ? a : b;
}

static __inline float MIN_F(float a, float b)
{
	return a < b ? a : b;
}

static __inline size_t get_filesize(FILE * file)
{
	/* Get file size */
	size_t oldPos = ftell(file);
	fseek(file, 0, SEEK_END);
	size_t length = ftell(file);
	fseek(file, oldPos, SEEK_SET);
	return length;
}

template<class Iterable, class T>
bool contains(const Iterable & iterable, const T & value)
{
	return find(iterable.begin(), iterable.end(), value) != iterable.end();
}

#define xcat(a,b) a##b
#define cat(a,b) xcat(a,b)
#define foreach(it, iterable) auto & cat(it,__LINE__) = iterable; for(auto it = cat(it,__LINE__).begin(); it != cat(it,__LINE__).end(); ++it)
/*template<typename T>
static __inline bool vector_remove(vector<T> v, T i)
{
	auto f = find(v.begin(), v.end(), i);
	if (f != v.end())
	{
		v.erase(f);
		return true;
	}
	return false;
}*/

template<typename T, int C>
struct FixedArray { FixedArray() { count = 0; } int count; T ptr[C]; };

template<typename T>
struct Array {
	Array() { count = 0; }
	Array(int count, T* ptr) { this->count = count; this->ptr = ptr; }
	template<int C> Array(FixedArray<T, C> & fa) {
		count = fa.count;
		ptr = fa.ptr;
	}

	int count;
	T* ptr;
};

#endif
