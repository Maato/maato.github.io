#include <cstdlib>

#include "pointer.h"
#include "pointable.h"
#include "platform.h"

Pointer::Pointer() :
	mUserObject(NULL),
	isDown(false),
	pressedTime(-1.0f),
	screenvelocity(Vector(0.0f,0.0f), 0.5f),
	lastUpdate(0.0f)
{
}

Pointer::~Pointer()
{
	assert(!isDown);
}

void Pointer::SetUserObject(Pointable*pointable)
{
	if(pointable == mUserObject)
		return;
	mUserObject = pointable;
}

Pointable * Pointer::GetUserObject()
{
	return mUserObject;
}
