#ifndef __COLOR_H__
#define __COLOR_H__

struct Color
{
	float R,G,B,A;

	Color() :
		R(1.0f),
		G(1.0f),
		B(1.0f),
		A(1.0f)
	{}

	Color(float r, float g, float b, float a) :
		R(r),
		G(g),
		B(b),
		A(a)
	{}

	static const Color White;
	static const Color Black;
	static const Color Red;
	static const Color Green;
	static const Color Blue;
};

#endif
