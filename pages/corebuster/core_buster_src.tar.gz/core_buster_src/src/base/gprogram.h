#ifndef __GPROGRAM_H__
#define __GPROGRAM_H__

#include <string>

#include "glstate.h"

struct GShader
{
	GLuint id;
	GLenum type;
	char * src_file;
	GShader(GLenum type, const char * src);
	~GShader();
	bool Compile();
	void Delete();
};

class GProgram
{
	bool mBuilt;
	GShader * mVertexShader;
	GShader * mFragmentShader;

	public:
		GLuint id;
		GProgram(const char * vertexShader, const char * fragmentShader);
		virtual ~GProgram();
		virtual void Use();
		virtual void Unuse();
		virtual bool Build();
		virtual void Delete();

	protected:
		bool LinkShaders();
		GLint GetAttribLocation(const char * name);
		GLint GetUniformLocation(const char * name);
};

#endif
