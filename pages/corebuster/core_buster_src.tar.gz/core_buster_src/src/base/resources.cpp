#include <cstdlib>
#include <cstring>
#include <algorithm>

#include "texref.h"
#include "resources.h"
#include "common.h"
#include "texture.h"
#include "font.h"
#include "platform.h"
#include "imageloader.h"
#include "gprogram.h"

using namespace std;

Resources * Resources::I = NULL;

Resources::Resources() :
	mTextureCacheLocks(0)
{
	I = this;
}

Resources::~Resources()
{
	for(unsigned int i = 0; i < mBuffers.size(); i++)
	{
		Vbo * buffer = mBuffers[i];
		glDeleteBuffers(1, &(buffer->id));
		free(buffer);
	}

	for(auto it = mFonts.begin(); it != mFonts.end(); it++) {
		delete it->second;
	}
	mFonts.clear();

	for(auto it = mTextures.begin(); it != mTextures.end(); it++) {
		Platform::LogInfo("Unreleased Texture: %s", it->second.first->name);
	}
}

GProgram * Resources::GetProgram(const char * name)
{
	auto it = mPrograms.find(name);
	if(it != mPrograms.end()) {
		return it->second;
	}
	return NULL;
}

void Resources::RegisterProgram(const char * name, GProgram * program)
{
	if(GetProgram(name) != NULL) {
		Platform::LogError("Registering a program with the same name twice");
	}
	mPrograms[name] = program;
}

void Resources::LockTextureCache()
{
	assert(mTextureCacheLocks >= 0);
	mTextureCacheLocks++;
}

void Resources::UnlockTextureCache()
{
	assert(mTextureCacheLocks > 0);
	mTextureCacheLocks--;
	if(mTextureCacheLocks == 0) {
		bool erasedTexture = false;
		do
		{
			erasedTexture = false;
			foreach(it, mTextures) {
				Texture * texture = it->second.first;
				if(it->second.second == 0) {
					glDeleteTextures(1, &(texture->id));
					free(texture->name);
					free(texture);
					mTextures.erase(it);
					erasedTexture = true;
					break;
				}
			}
		} while(erasedTexture);
	}
}

ImageData * Resources::LoadImage(const char * name)
{
	ImageData * image = NULL;
	FILE * file = Platform::OpenResource(name);
	if(file == NULL) {
		image = imageloader_create_placeholder();
	} else {
		image = imageloader_load_png(file);
		fclose(file);
		file = NULL;
	}
	return image;
}

void Resources::Reload()
{
	for(auto it = mTextures.begin(); it != mTextures.end(); it++) {
		ImageData * image = LoadImage(it->second.first->name);
		LoadTexture(it->second.first, image);
		imageloader_destroy(image);
	}

	for(unsigned int i = 0; i < mBuffers.size(); i++)
		CreateBuffer(mBuffers[i]);

	for(auto it = mPrograms.begin(); it != mPrograms.end(); it++) {
		GProgram * program = it->second;
		program->Build();
	}
}

void Resources::ReloadShaders()
{
	for(auto it = mPrograms.begin(); it != mPrograms.end(); it++) {
		GProgram * program = it->second;
		program->Delete();
		program->Build();
	}
}


void Resources::LoadTexture(Texture * texture, ImageData * image)
{
	// Generate a new texture with the appropriate parameters
	glGenTextures(1, &(texture->id));
	glBindTexture(GL_TEXTURE_2D, texture->id);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, texture->filter);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, texture->filter);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, texture->wrap); 
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, texture->wrap);

	// Read the image from the file into memory
	texture->width = image->width;
	texture->height = image->height;

	// Pre-multiply the alpha channel
	if(image->internalFormat == GL_RGBA){
		typedef struct { uint8_t r, g, b, a; } ColorType;
		ColorType * color = (ColorType*)image->data;
		int pixel_count = image->height*image->width;
		ColorType * end = color + pixel_count;
		for(; color < end; ++color) {
			uint16_t a = color->a + 1;
			color->r = (color->r * a) >> 8;
			color->g = (color->g * a) >> 8;
			color->b = (color->b * a) >> 8;
		}
	}
	if(image->internalFormat == GL_LUMINANCE_ALPHA){
		typedef struct { uint8_t l, a; } ColorType;
		ColorType * color = (ColorType*)image->data;
		int pixel_count = image->height*image->width;
		ColorType * end = color + pixel_count;
		for(; color < end; ++color) {
			uint16_t a = color->a + 1;
			color->l = (color->l * a) >> 8;
		}
	}

	// Copy the image data to the texture
	glTexImage2D(GL_TEXTURE_2D, 0, image->internalFormat, image->width,
		image->height, 0, image->internalFormat, GL_UNSIGNED_BYTE, image->data);
}

Texture * Resources::LoadTexture(const char* name) {
	return this->LoadTexture(name, GL_CLAMP_TO_EDGE, GL_LINEAR);
}

Texture * Resources::LoadTexture(const char* name, GLuint wrap, GLuint filter)
{
	auto it = mTextures.find(name);
	if(it != mTextures.end())
	{
		auto & pair = it->second;
		pair.second++;
		return pair.first;
	}

	Texture * texture = reinterpret_cast<Texture*>(malloc(sizeof(Texture)));
	texture->name = strdup(name);
	texture->wrap = wrap;
	texture->filter = filter;

	ImageData * image = LoadImage(name);
	LoadTexture(texture, image);
	imageloader_destroy(image);

	mTextures[name] = pair<Texture*,int>(texture,1);
	return texture;
}

char * Resources::GetText(const char * name)
{
	FILE * file = Platform::OpenResource(name);
	if(file == NULL) {
		return NULL;
	}
	size_t filesize = get_filesize(file);
	char * contents = (char*)malloc(filesize+1);
	contents[filesize] = '\0';
	fread(contents, filesize, 1, file);
	fclose(file);
	return contents;
}

void Resources::AcquireTexture(Texture * texture)
{
	auto it = mTextures.find(texture->name);
	if(it != mTextures.end())
	{
		auto & pair = it->second;
		pair.second++;
	}
	else
	{
		Platform::LogError("Tried to acquire a non-existing or already freed texture: %s", texture->name);
	}
}

void Resources::ReleaseTexture(Texture * texture)
{
	auto it = mTextures.find(texture->name);
	if(it != mTextures.end())
	{
		auto & pair = it->second;
		pair.second--;
		if(pair.second == 0 && mTextureCacheLocks == 0)
		{
			glDeleteTextures(1, &(texture->id));
			free(texture->name);
			free(texture);
			mTextures.erase(it);
		}
	}
	else
	{
		Platform::LogError("Tried to release a non-existing or already freed texture: %s", texture->name);
	}
}

Vbo * Resources::CreateBuffer(GLfloat * data, int float_count)
{
	assert(float_count > 0);
	Vbo * buffer = (Vbo*)malloc(sizeof(Vbo));
	buffer->source = data;
	buffer->float_count = float_count;

	CreateBuffer(buffer);

	mBuffers.push_back(buffer);
	return buffer;
}

void Resources::FreeBuffer(Vbo * vbo)
{
	assert(vbo != NULL);
	glDeleteBuffers(1, &(vbo->id));
	auto it = find(mBuffers.begin(), mBuffers.end(), vbo);
	if(it != mBuffers.end())
	{
		free(*it);
		*it = mBuffers.back();
		mBuffers.pop_back();
	}
}

void Resources::CreateBuffer(Vbo * buffer)
{
	assert(buffer->float_count > 0);
	glGenBuffers(1, &(buffer->id));
	glBindBuffer(GL_ARRAY_BUFFER, buffer->id);
	glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * buffer->float_count, buffer->source, GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void Resources::UpdateBuffer(Vbo * buffer)
{
	glBindBuffer(GL_ARRAY_BUFFER, buffer->id);
	glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * buffer->float_count, buffer->source, GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
}

Font * Resources::GetFont(const char * name)
{
	Font * font = NULL;
	Texture * texture = NULL;
	ImageData * image = NULL;

	// If the font is already cached, return that
	auto fit = mFonts.find(name);
	if(fit != mFonts.end())
		return fit->second;

	// If the texture for the font is already cached use that
	// otherwise create and cache a new texture
	auto it = mTextures.find(name);
	if(it != mTextures.end()) {
		auto & pair = it->second;
		pair.second++;
		texture = pair.first;
		image = LoadImage(name);
	} else {
		texture = reinterpret_cast<Texture*>(malloc(sizeof(Texture)));
		texture->name = strdup(name);
		texture->wrap = GL_REPEAT;
		texture->filter = GL_NEAREST;
		image = LoadImage(name);
		LoadTexture(texture, image);
		mTextures[name] = pair<Texture*,int>(texture,1);
	}

	// Create the new font
	if(strcmp(name, "img/font.png") == 0) {
		font = new Font(image, texture, 19, 0, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,!?-+/():;%&`'*#=[]\"");
	} else {
		Platform::LogError("This font cannot be instantiated by Resources");
	}

	imageloader_destroy(image);

	if(font != NULL)
		mFonts[name] = font;
	return font;
}

TextureCacheLock::TextureCacheLock()
{
	Res.LockTextureCache();
}

TextureCacheLock::~TextureCacheLock()
{
	Res.UnlockTextureCache();
}

TexRef::TexRef(Texture * tex) : 
	Tex(tex)
{
}

TexRef::~TexRef()
{
	if(Tex != NULL) {
		Res.ReleaseTexture(Tex);
		Tex = NULL;
	}
}

TexRef::TexRef(const TexRef & copy_from_me)
{
	Tex = copy_from_me.Tex;
	Res.AcquireTexture(Tex);
}

TexRef & TexRef::operator=(const TexRef & other)
{
	if(Tex != other.Tex) {
		if(Tex != NULL) {
			Res.ReleaseTexture(Tex);
		}
		Tex = other.Tex;
		if(Tex != NULL) {
			Res.AcquireTexture(Tex);
		}
	}
	return *this;
}

Texture * TexRef::operator->() const
{
	return Tex;
}

Texture * TexRef::operator*() const
{
	return Tex;
}