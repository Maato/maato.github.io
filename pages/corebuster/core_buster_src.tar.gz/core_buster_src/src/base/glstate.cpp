#include "glstate.h"
#include "texture2dprogram.h"
#include "colorprogram.h"
#include "resources.h"
#include "matrix.h"

static Matrix m_projection_matrix[16];
static Matrix m_modelview_matrix[16];
Matrix * gl_projection = &m_projection_matrix[0];
Matrix * gl_modelview = &m_modelview_matrix[0];
Texture2DProgram * gl_TextureProg = NULL;
ColorTexture2DProgram * gl_ColorTextureProg = NULL;
ColorProgram * gl_ColorProg = NULL;

void gl_PushModelView()
{
	assert(gl_modelview != &m_modelview_matrix[15]);
	gl_modelview[1] = gl_modelview[0];
	gl_modelview++;
}

void gl_PushProjection()
{
	assert(gl_projection != &m_projection_matrix[15]);
	gl_projection[1] = gl_projection[0];
	gl_projection++;
}

void gl_PopModelView()
{
	assert(gl_modelview != &m_modelview_matrix[0]);
	gl_modelview--;
}

void gl_PopProjection()
{
	assert(gl_projection != &m_projection_matrix[0]);
	gl_projection--;
}

void gl_GetModelViewProjection(Matrix * out)
{
	Matrix::multiply(out, gl_modelview, gl_projection);
}

void gl_LoadShaders()
{
	if(gl_ColorProg == NULL)
		gl_ColorProg = new ColorProgram("shaders/color.vert", "shaders/color.frag");
	if(gl_TextureProg == NULL)
		gl_TextureProg = new Texture2DProgram("shaders/texture.vert", "shaders/texture.frag");
	if(gl_ColorTextureProg == NULL)
		gl_ColorTextureProg = new ColorTexture2DProgram("shaders/colortexture.vert", "shaders/colortexture.frag");

	gl_ColorProg->Build();
	Res.RegisterProgram("color", gl_ColorProg);
	gl_TextureProg->Build();
	Res.RegisterProgram("texture", gl_TextureProg);
	gl_ColorTextureProg->Build();
	Res.RegisterProgram("colortexture", gl_ColorTextureProg);
}