#ifndef __TEXTURE2DPROGRAM_H__
#define __TEXTURE2DPROGRAM_H__

#include "gprogram.h"

class Texture2DProgram : public GProgram
{
	public:
		Texture2DProgram(const char * vert, const char * frag);
		bool Build();
		void Use();
		void Unuse();
		virtual void VertexPointer(void * p) const;
		virtual void VertexPointer(void * p, int stride) const;
		virtual void TexCoordPointer(void * p) const;
		virtual void TexCoordPointer(void * p, int stride) const;

	protected:
		GLint a_position;
		GLint a_texcoord;
		GLint u_mvp;
		GLint s_sampler;
};

class ColorTexture2DProgram : public Texture2DProgram
{
	float r, g, b, a;
	
	public:
		ColorTexture2DProgram(const char * vert, const char * frag);
		bool Build();
		void Use();
		void SetColor(float r, float g, float b, float a);

	protected:
		GLint u_color;
};


#endif
