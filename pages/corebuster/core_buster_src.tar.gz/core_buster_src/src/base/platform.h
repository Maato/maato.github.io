#ifndef __PLATFORM_H__
#define __PLATFORM_H__

#include <cstdio>

#include "vector.h"

typedef enum {
	KEY_UP,
	KEY_DOWN
} KeyAction;

typedef enum {
	KEYCODE_UNKNOWN,
	KEYCODE_BACK,
	KEYCODE_CONFIRM,
	KEYCODE_MENU,
	KEYCODE_LEFT,
	KEYCODE_RIGHT,
	KEYCODE_UP,
	KEYCODE_DOWN,
	KEYCODE_SPACE,
	KEYCODE_SHIFT
} KeyCode;

class File;
struct Texture;
class Platform
{
	public:
		static Vector GetSize();
		static double GetSeconds();
		static FILE * OpenResource(const char * name);
		static FILE * OpenFileForWriting(const char * name);
		static void LogInfo(const char * fmt, ...);
		static void LogError(const char * fmt, ...);
		static char * GetFilesDir();
		static void ReportFailure(const char * cond, const char * filename, int line, const char * function);
		static void Quit();
		static KeyCode TranslateKey(int key_id);
};

#ifdef assert
#undef assert
#endif

#ifdef _WIN32
#define __func__ __FUNCTION__
#endif

#ifdef NDEBUG
#define assert(cond) do { (void)sizeof(cond); } while(0)
#else
#define assert(cond) do { if(!(cond)) Platform::ReportFailure(#cond, __FILE__, __LINE__, __func__); } while(0)
#endif

#endif
