#ifndef __SYSTEM_H__
#define __SYSTEM_H__

#include <cstdio>
#include <queue>
#include <map>

#include "glstate.h"
#include "vector.h"
#include "resources.h"

#define POINTER_UPDATE 0
#define POINTER_DOWN 1
#define POINTER_UP 2

struct touch_event
{
	int id, action, x, y;
	double time;
};

struct key_event
{
	int action;
	int key;
};

class Pointer;
class State;
class System
{
	private: 
		Resources mResources;
		std::queue<touch_event> mTouchEventQueue;
		std::queue<key_event> mKeyEventQueue;

	public:
		State * mPreviousState;
		State * mGameState;

	private:
		std::map<int, Pointer*> mPointers;
		double mPreviousTime;
		State * mCurrentState;
		State * mNextState;

	public:
		System();
		~System();
		
		void SurfaceCreated();
		void SurfaceChanged(int width, int height);
		void DrawFrame();

		State * GetState();
		Resources & GetResources();
		void ChangeState(State * newState);
		void TouchEvent(int id, int action, int x, int y);
		void KeyUp(int id);
		void KeyDown(int id);
		
	private:
		void HandleEvents();
};

#endif
