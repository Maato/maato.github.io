#ifndef __POINTER_H__
#define __POINTER_H__

#include "vector.h"
#include "smoothvalue.h"

class Pointable;
class Pointer
{
	Pointable * mUserObject;
	
	public:
		Pointer();
		~Pointer();
		void SetUserObject(Pointable*);
		Pointable * GetUserObject();
		
		bool isDown;
		float pressedTime;
		Vector beginPosition;

		Vector position;
		Vector oldposition;

		Vector screenposition;
		Vector oldscreenposition;

		SmoothValue<Vector> screenvelocity;

		float lastUpdate;
};

#endif
