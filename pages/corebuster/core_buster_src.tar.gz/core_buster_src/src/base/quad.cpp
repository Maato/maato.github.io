#include "quad.h"

const Quad Quad::Zero = Quad();
const Quad Quad::One = Quad(Vector::Zero, Vector(1.0f, 1.0f));
const Quad Quad::CenterOne = Quad(-0.5f, -0.5f, 0.5f, 0.5f);
