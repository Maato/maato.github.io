#include <cstdarg>
#include <cstring>
#include <cstdlib>

#include "font.h"
#include "matrix.h"
#include "resources.h"
#include "texture.h"
#include "platform.h"
#include "imageloader.h"
#include "texture2dprogram.h"

Font::Font(ImageData * imageData, Texture * texture, int lineStride, int letter_spacing, const char * alphabet) :
	mLineStride(lineStride),
	mLetterSpacing(letter_spacing)
{
	mAtlas = texture;
	memset(mIndices, 0x0, sizeof(mIndices));
	memset(mSizes, 0x0, sizeof(mSizes));

	ParseTexture(imageData, alphabet, mLineStride);
}

Font::~Font()
{
	Resources::I->ReleaseTexture(mAtlas);
}

struct TextureScanner
{
	int x, y, w, h;
	int line_stride;
	ImageData * image;

	TextureScanner(ImageData * imageData, int line_stride) :
		x(0), y(0), w(0), h(0),
		line_stride(line_stride)
	{
		w = imageData->width;
		h = imageData->height;
		image = imageData;
	}

	inline bool IsValidPosition(int x, int y)
	{
		return x >= 0 && x < w && y >= 0 && y < h;
	}

	bool ScanVLine(int x, int y)
	{
		for(int i = 0; i < line_stride; i++) {
			if(!IsValidPosition(x, y+i)) {
				return false;
			}

			switch(image->internalFormat) {
				case GL_RGBA: {
					struct _rgba_ { uint8_t r, g, b, a; } * data = (struct _rgba_*)image->data;
					data += x + (y+i) * w;
					if(data->a || data->r || data->g || data->b)
						return true;
					break;
				}
				case GL_LUMINANCE: {
					uint8_t * data = image->data;
					if(data[x + (y+i) * w])
						return true;
					break;
				}
				case GL_RGB: {
					struct _rgb_ { uint8_t r, g, b; } * data = (struct _rgb_*)image->data;
					data += x + (y+i) * w;
					if(data->r || data->g || data->b)
						return true;
					break;
				}
				default: {
					Platform::ReportFailure("color == known", __FILE__, __LINE__, __func__);
				}
			}
		}
		return false;
	}

	bool TryGetNextCharacter(Rect * rect)
	{
		// scan until the first non zero line occurs
		for(; ; x++) {
			if(!IsValidPosition(x, y)) {
				return false;
			}
			
			if(ScanVLine(x, y)) {
				rect->x = x;
				rect->y = y;
				break;
			}

			if(x == w-1) {
				x = -1;
				y += line_stride;
			}
		}

		// Scan until the first zero line occurs
		for(; ; x++) {
			if(!IsValidPosition(x, y)) {
				return false;
			}

			if(!ScanVLine(x,y)) {
				rect->w = x - rect->x;
				rect->h = line_stride;
				return true;
			}

			if(x == w-1) {
				rect->w = x - rect->x;
				rect->h = line_stride;
				x = 0;
				y += line_stride;
				return true;
			}
		}
		return false;
	}
};

void Font::ParseTexture(ImageData * imageData, const char * alphabet, int height)
{
	TextureScanner ts = TextureScanner(imageData, height);
	mIndices[(int)' '] = 0;
	mSizes[0].w = mLineStride / 3;
	for(int i = 0; alphabet[i]; i++)
	{
		char letter = alphabet[i];
		assert(letter >= 0 && letter < 256);
		assert(letter != ' ');
		mIndices[(unsigned char)letter] = (unsigned char)i+1;
		if(!ts.TryGetNextCharacter(&mSizes[i+1])) {
			Platform::LogError("Could not find character in font."
				" Character was '%c'.\n", letter);
			break;
		}
	}
}

Texture * Font::GetTexture()
{
	return mAtlas;
}

Vector Font::PrepareText(std::vector<Vector> & verts, const char * text)
{
	//int cw = 16; // character width between characters on the tilesheet
	//int rw = 12; // render width, dist between characters when rendered
	//int ch = 20;
	int text_width = 0;
	for(int i = 0; text[i]; i++)
	{
		char letter = text[i];
		int index = mIndices[(int)letter];
		Rect & rect = mSizes[index];

		if(letter == ' ') {
			text_width += rect.w;
			continue;
		}

		text_width += mLetterSpacing;

		float vl = text_width;
		float vr = text_width + rect.w;

		float l = rect.x / (float)mAtlas->width;
		float r = (rect.x+rect.w) / (float)mAtlas->width;
		float t = rect.y / (float)mAtlas->height;
		float b = (rect.y+rect.h) / (float)mAtlas->height;

		// Interleave vertices and texture coordinates (starting with vertices)
		verts.push_back(Vector(vl, 0));
		verts.push_back(Vector(l, t));
		
		verts.push_back(Vector(vr, 0));
		verts.push_back(Vector(r, t));
		
		verts.push_back(Vector(vl, rect.h));
		verts.push_back(Vector(l, b));
		
		verts.push_back(Vector(vr, 0));
		verts.push_back(Vector(r, t));
		
		verts.push_back(Vector(vr, rect.h));
		verts.push_back(Vector(r, b));
		
		verts.push_back(Vector(vl, rect.h));
		verts.push_back(Vector(l, b));

		text_width += rect.w;
	}
	return Vector(text_width, mLineStride);
}

CompiledText::CompiledText(Font * font) :
	mScale(1.0f),
	mA(1.0f),mR(1.0f),mG(1.0f),mB(1.0f),
	mFont(font),
	mBuffer(NULL),
	mText(NULL)
{
}

CompiledText::CompiledText(const char * fontname) :
	mScale(1.0f),
	mA(1.0f),mR(1.0f),mG(1.0f),mB(1.0f),
	mBuffer(NULL),
	mText(NULL)
{
	mFont = Resources::I->GetFont(fontname);
}

CompiledText::~CompiledText()
{
	if(mBuffer != NULL) {
		Resources::I->FreeBuffer(mBuffer);
		mBuffer = NULL;
	}
	if(mText != NULL) {
		free(mText);
		mText = NULL;
	}
}

void CompiledText::SetColor(float r, float g, float b, float a)
{
	mR = r;
	mG = g;
	mB = b;
	mA = a;
}

void CompiledText::SetScale(float scale)
{
	mScale = scale;
}

Vector CompiledText::GetSize() const
{
	return mSize * mScale;
}

void CompiledText::SetText(const char * format, ...)
{
	char buffer[512];
	va_list vl;
	va_start(vl, format);
	vsnprintf(buffer, 512, format, vl);
	va_end(vl);

	if(mText != NULL && strcmp(mText, buffer) == 0)
		return;
	if(mText != NULL)
		free(mText);
	mText = strdup(buffer);

	if(mBuffer) {
		Resources::I->FreeBuffer(mBuffer);
		mBuffer = NULL;
	}
	if (mText[0] == 0) {
		return;
	}
	mVerts.clear();
	mSize = mFont->PrepareText(mVerts, buffer);
	mBuffer = Resources::I->CreateBuffer((GLfloat*)&mVerts[0], mVerts.size()*2);
}

void CompiledText::DrawCentered(Vector position)
{
	Draw(position - (mSize * mScale) / 2);
}

void CompiledText::Draw(Vector position)
{
	if (mBuffer == NULL) {
		return;
	}
	gl_ColorTextureProg->SetColor(mR, mG, mB, mA);
	gl_PushModelView();
	Matrix::translate(gl_modelview, roundf(position.X), roundf(position.Y), 0.0f);
	Matrix::scale(gl_modelview, mScale, mScale, 0.0f);
	glBindTexture(GL_TEXTURE_2D, mFont->GetTexture()->id);
	glBindBuffer(GL_ARRAY_BUFFER, mBuffer->id);
	gl_ColorTextureProg->VertexPointer((char*)NULL + 0, 16);
	gl_ColorTextureProg->TexCoordPointer((char*)NULL + 8, 16);
	gl_ColorTextureProg->Use();
	glDrawArrays(GL_TRIANGLES, 0, mVerts.size() / 2);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	gl_PopModelView();
}

