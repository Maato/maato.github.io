#ifndef __TEXTURE_H__
#define __TEXTURE_H__

#include "glstate.h"

struct Texture
{
	char * name;
	GLuint wrap;
	GLuint filter;
	GLuint id;
	int width;
	int height;
};

#endif
