#include <cstring>
#include <cstdlib>

#include "gprogram.h"
#include "platform.h"
#include "resources.h"

GShader::GShader(GLenum type, const char * src) :
	id(0),
	type(type),
	src_file(strdup(src))
{
}

GShader::~GShader()
{
	glDeleteShader(id);
	free(src_file);
}

bool GShader::Compile()
{
	GLuint shader = glCreateShader(type);
	if(shader == 0) {
		Platform::LogError("Could not create shader");
		return false;
	}
	
	char * src = Res.GetText(src_file);
	if(src == NULL) {
		Platform::LogError("Could not get source for shader: %s\n", src_file);
		return false;
	}

	// Compile the shader
	glShaderSource(shader, 1, (const char**)&src, NULL);
	glCompileShader(shader);

	// Check the compilation status
	GLint compile_status = 0;
	glGetShaderiv(shader, GL_COMPILE_STATUS, &compile_status);

	// Print the shader info log
	GLint infoLen = 0;
	glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &infoLen);
	#ifdef ANDROID
	// Always pass a large enough buffer on android because
	// glGetShaderiv doesn't return correct values there
	infoLen += 4096;
	#endif
	if(infoLen > 0) {
		char * buf = (char*)malloc(infoLen);
		if(buf != NULL) {
			glGetShaderInfoLog(shader, infoLen, NULL, buf);
			if(compile_status != GL_TRUE) {
				Platform::LogError("Shader Compile Errors in %s:\n%s", src_file, buf);
			} else {
				if(strlen(buf) > 0) {
					Platform::LogInfo("Shader Compile Warnings in %s:\n%s", src_file, buf);
				}
			}
			free(buf);
		}
	}

	// Free shader source string
	free(src);

	// Return success or failure of compilation
	if(compile_status != GL_TRUE) {
		glDeleteShader(shader);
		shader = 0;
		return false;
	} else {
		id = shader;
		return true;
	}
}

void GShader::Delete()
{
	glDeleteShader(id);
}

GProgram::GProgram(const char * vertexShader, const char * fragmentShader) :
	mBuilt(false),
	mVertexShader(new GShader(GL_VERTEX_SHADER, vertexShader)),
	mFragmentShader(new GShader(GL_FRAGMENT_SHADER, fragmentShader))
{
}

GProgram::~GProgram()
{
	glDeleteProgram(id);
	delete mVertexShader;
	delete mFragmentShader;
}

bool GProgram::Build()
{
	if(!mVertexShader->Compile()) {
		return false;
	}
	if(!mFragmentShader->Compile()) {
		return false;
	}
	if(!LinkShaders()) {
		return false;
	}
	mBuilt = true;
	return true;
}

void GProgram::Delete()
{
	glDeleteProgram(id);
	mVertexShader->Delete();
	mFragmentShader->Delete();
}

bool GProgram::LinkShaders()
{
	GLuint program = glCreateProgram();
	if(program == 0) {
		Platform::LogError("Could not create program");
		return false;
	}

	// Link the shader program
	glAttachShader(program, mVertexShader->id);
	glAttachShader(program, mFragmentShader->id);
	glLinkProgram(program);

	// Get program link status
	GLint link_status = GL_FALSE;
	glGetProgramiv(program, GL_LINK_STATUS, &link_status);

	// Print program info log
	GLint bufLength = 0;
	glGetProgramiv(program, GL_INFO_LOG_LENGTH, &bufLength);
	#ifdef ANDROID
	// Always pass a large enough buffer on android because
	// glGetProgramiv doesn't return correct values there
	bufLength += 4096;
	#endif
	if(bufLength > 0) {
		char * buf = (char*)malloc(bufLength);
		if(buf != NULL) {
			glGetProgramInfoLog(program, bufLength, NULL, buf);
			if(link_status != GL_TRUE) {
				Platform::LogError("Shader Program Link Error (%s,%s):\n%s\n",
					mVertexShader->src_file, mFragmentShader->src_file, buf);
			} else {
				if(!(strcmp(buf, "Link was successful.\n") == 0 || strlen(buf) == 0)) {
					Platform::LogInfo("Shader Program Link Warning (%s,%s):\n%s\n",
						mVertexShader->src_file, mFragmentShader->src_file, buf);
				}
			}
			free(buf);
		}
	}

	// Return success or failure of linking
	if(link_status != GL_TRUE) {
		glDeleteProgram(program);
		program = 0;
		return false;
	} else {
		id = program;
	}
	return true;
}

GLint GProgram::GetAttribLocation(const char * name)
{
	assert(mBuilt);
	GLint result = glGetAttribLocation(id, name);
	if(result == -1) {
		Platform::LogError("Invalid attrib name: %s", name);
	}
	return result;
}

GLint GProgram::GetUniformLocation(const char * name)
{
	assert(mBuilt);
	GLint result = glGetUniformLocation(id, name);
	if(result == -1) {
		Platform::LogError("Invalid uniform name: %s", name);
	}
	return result;
}

GProgram * m_last_program = NULL;
void GProgram::Use()
{
	if(m_last_program != this) {
		if(m_last_program != NULL) {
			m_last_program->Unuse();
		}
		glUseProgram(id);
		m_last_program = this;
	}
}

void GProgram::Unuse()
{
	glUseProgram(0);
	m_last_program = NULL;
	assert(mBuilt);
}
