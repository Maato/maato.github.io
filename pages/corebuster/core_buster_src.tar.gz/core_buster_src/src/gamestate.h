#ifndef __GAMESTATE_H__
#define __GAMESTATE_H__

#include <vector>

#include "state.h"
#include "pointer.h"
#include "vector.h"
#include "gprogram.h"
#include "common.h"
#include "texref.h"
#include "font.h"

struct WorldBlock;
struct Navigation;
struct PlanetRegion;
struct QuadRegion;
class GameState : public State
{
	Vector mOffset;
	Vector mPosition;
	TexRef mBackground;
	Navigation * mNavigation;
	CompiledText * mCoordinates;

	int mMissionState;

	CompiledText * mSandCount;
	CompiledText * mRockCount;
	CompiledText * mHardRockCount;
	CompiledText * mLavaCount;
	CompiledText * mWeaponName;

	public:
		GameState(System * system);
		~GameState();
		
		virtual void Update(float dt);
		virtual void Draw();
		virtual void EnterState();
		virtual void LeaveState();
		virtual void PointerDown(Pointer * p);
		virtual void PointerUp(Pointer * p);
		virtual void KeyUp(int key);
		virtual void KeyDown(int key);
		
		Vector ToWorld(Vector v);
		Vector ToScreen(Vector v);

		void SetOffset(Vector offset);
		Vector GetOffset();

		void UpdateShadowTexture();
		WorldBlock * GenerateTile(int x, int y);
		void FindPlanets(QuadRegion*, int x, int y, std::vector<PlanetRegion*> &);
		void DrawBackground();
};

#endif
