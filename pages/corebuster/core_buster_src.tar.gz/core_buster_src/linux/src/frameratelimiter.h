#ifndef __FRAMERATELIMITER_H__
#define __FRAMERATELIMITER_H__

extern void frameratelimiter_start();
extern void frameratelimiter_stop();
extern void frameratelimiter_limit_rate();

#endif
