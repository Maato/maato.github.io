#ifndef __WINDOW_H__
#define __WINDOW_H__

#include <string>

#include <SDL.h>

struct Size {
	int width;
	int height;
	static Size Make(int w, int h);
};

class Window
{
	Size mWindowSize;
	Size mScreenSize;
	std::string mCaption;
	SDL_Surface * mSurface;
	int mSurfaceFlags;

	public:
		Window(std::string caption, Size size, bool fullscreen);
		void Initialize();
		void HandleEvent();
		void BeginDraw();
		void EndDraw();
		Size GetSize();
		void Resize(Size);
		void ToggleFullscreen();
};

#endif
