#include <cstdlib>
#include <unistd.h>
#include <sstream>
#include <csignal>
#include <fenv.h>
#include <SDL.h>
#include <SDL_mixer.h>

#include "system.h"
#include "platform.h"
#include "common.h"
#include "window.h"
#include "frameratelimiter.h"

using namespace std;

/* Static variables */
static System * mSystem = NULL;
static bool mIsMouseDown = false;
static Window * mWindow = NULL;

/* Exported variables */
bool mRunning = true;
bool mMp3Enabled = false;

/* Static functions */
static void handle_mouse_event(int x, int y, int state)
{
	int action;
	bool wasMouseDown = mIsMouseDown;
	mIsMouseDown = state & SDL_BUTTON_LMASK;
	
	if(wasMouseDown == mIsMouseDown)
		action = POINTER_UPDATE;
	else if(wasMouseDown)
		action = POINTER_UP;
	else/*if (mIsMouseDown)*/ 
		action = POINTER_DOWN;
		
	mSystem->TouchEvent(0, action, x, y);
}

static void main_handle_events()
{
	SDL_Event event;
	while(SDL_PollEvent(&event))
	{
		switch(event.type)
		{
			case SDL_QUIT: {
				mRunning = false;
				break;
			}
			case SDL_VIDEORESIZE: {
				Size newSize = { event.resize.w, event.resize.h };
				mWindow->Resize(newSize);
				mSystem->SurfaceChanged(event.resize.w, event.resize.h);
				break;
			}
			case SDL_KEYUP: {
				mSystem->KeyUp(Platform::TranslateKey(event.key.keysym.sym));
				break;
			}
			case SDL_KEYDOWN: {
				mSystem->KeyDown(Platform::TranslateKey(event.key.keysym.sym));
				if(event.key.keysym.sym == SDLK_F5) {
					//reload_map(true);
					Res.Reload();
				} 
				break;
			}
			case SDL_MOUSEMOTION: {
				handle_mouse_event(event.motion.x, event.motion.y, event.motion.state);
				break;
			}
			case SDL_MOUSEBUTTONDOWN:
			case SDL_MOUSEBUTTONUP: {
				handle_mouse_event(event.button.x, event.button.y, event.button.state);
				break;
			}
		}
	}
}

static void main_initialize()
{
	// Compare linktime and compiletime versions of SDL
	SDL_version compile_version;
	const SDL_version * link_version = SDL_Linked_Version();
	SDL_VERSION(&compile_version);
	if(compile_version.major != link_version->major ||
		compile_version.minor != link_version->minor ||
		compile_version.patch != link_version->patch)
	{
		fprintf(stdout, "Compiled with SDL version: %d.%d.%d\n",
			compile_version.major,
			compile_version.minor,
			compile_version.patch);
		fprintf(stdout, "Running with SDL version: %d.%d.%d\n",
			link_version->major,
			link_version->minor,
			link_version->patch);
	}

	// Initialize SDL
	if(SDL_Init(SDL_INIT_AUDIO | SDL_INIT_VIDEO) == -1)
	{
		fprintf(stderr, "Failed to initialize SDL: %s\n", SDL_GetError());
		exit(EXIT_FAILURE);
	}

	if(Mix_Init(MIX_INIT_MP3) & MIX_INIT_MP3)
	{
		mMp3Enabled = true;
	}

	// Open sound mixer
	if(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 1024) == -1) {
		fprintf(stderr, "Mix_OpenAudio: %s\n", Mix_GetError());
	} else {
		// m_snd_potion = load_wav("snd_potion");
		// m_snd_hurt_spark = load_wav("snd_hurt_spark");
		// m_snd_flames = load_wav("snd_flames");
		// m_snd_boss_die = load_wav("snd_boss_die");
		// m_snd_menu_blip = load_wav("snd_menu_blip");
		// m_snd_book = load_wav("snd_book");
		fprintf(stdout, "Loaded music\n");
	}
}

static void sigfpe_handler(int a)
{
	fprintf(stderr, "Signal: %d caught, aborting!\n", a);
	switch(a)
	{
		case FPE_INTDIV:
			fprintf(stderr, "Integer divide by zero\n");
			break;
		case FPE_INTOVF:
			fprintf(stderr, "Integer overflow\n");
			break;
		case FPE_FLTDIV:
			fprintf(stderr, "Floating-point divide by zero\n");
			break;
		case FPE_FLTOVF:
			fprintf(stderr, "Floating-point overflow\n");
			break;
		case FPE_FLTUND:
			fprintf(stderr, "Floating point underflow\n");
			break;
		case FPE_FLTRES:
			fprintf(stderr, "Floating-point inexact result\n");
			break;
		case FPE_FLTINV:
			fprintf(stderr, "Invalid floatin-point operation\n");
			break;
		case FPE_FLTSUB:
			fprintf(stderr, "Subscript out of range\n");
			break;
		default:
			fprintf(stderr, "Unknown type of floating point exception\n");
	}
	abort();
}

static void main_swap_buffers()
{
	// Check for OpenGL errors, if there are no errors
	// the GL_NO_ERROR case will swap buffers and return
	// otherwise the program will be terminated
	const char * error_string = NULL;
	GLenum error = glGetError();
	switch(error)
	{
		case(GL_NO_ERROR):
			SDL_GL_SwapBuffers();
			return;
		case GL_INVALID_ENUM:
			error_string = "GL_INVALID_ENUM";
			break;
		case GL_INVALID_VALUE:
			error_string = "GL_INVALID_VALUE";
			break;
		case GL_INVALID_OPERATION:
			error_string = "GL_INVALID_OPERATION";
			break;
		case GL_STACK_OVERFLOW:
			error_string = "GL_STACK_OVERFLOW";
			break;
		case GL_STACK_UNDERFLOW:
			error_string = "GL_STACK_UNDERFLOW";
			break;
		case GL_OUT_OF_MEMORY:
			error_string = "GL_OUT_OF_MEMORY";
			break;
		default:
			error_string = "Unknown";
			break;
	}

	fprintf(stderr, "OpenGL error: %s\n", error_string);
	exit(EXIT_FAILURE);
}

// static int mydiver(int x, int y) {
// 	if(x >= 0) return x / y;
// 	return ((x-y+1) / y);
// }

/* Exported functions */
int main(int argc, char * argv[])
{

	// for(int i = -40; i < 40; i++) {
	// 	fprintf(stdout, "%d: %d\n", i, mydiver(i, 8));
	// }
	// exit(EXIT_FAILURE);

	signal(SIGFPE, sigfpe_handler);

	// feenableexcept(FE_INVALID | FE_DIVBYZERO | FE_OVERFLOW);

	main_initialize();

	mSystem = new System();
	mWindow = new Window("Core Buster", Size::Make(1024, 768), false);

	mWindow->Initialize();
	Size windowSize = mWindow->GetSize();

	mSystem->SurfaceCreated();
	mSystem->SurfaceChanged(windowSize.width, windowSize.height);

	while(mRunning)
	{
		frameratelimiter_start();
		main_handle_events();

		mSystem->DrawFrame();
		main_swap_buffers();

		frameratelimiter_stop();
		frameratelimiter_limit_rate();
	}

	delete mWindow;
	delete mSystem;
	SDL_Quit();
	return EXIT_SUCCESS;
}
