#include "window.h"
#include "platform.h"
#include "common.h"

#define SURFACE_BPP 32
#define SURFACE_FLAGS (SDL_OPENGL | SDL_DOUBLEBUF | SDL_HWSURFACE)

Size Size::Make(int w, int h)
{
	Size s = { w, h };
	return s;
}

Window::Window(std::string caption, Size size, bool fullscreen) :
	mWindowSize(size),
	mCaption(caption),
	mSurface(NULL),
	mSurfaceFlags(SURFACE_FLAGS)
{
	if(fullscreen) {
		mSurfaceFlags |= SDL_FULLSCREEN;
	}
}

void Window::Resize(Size size)
{
	size.width = MAX(size.width, 1);
	size.height = MAX(size.height, 1);

	if(mSurface == NULL || mSurface->w != size.width || mSurface->h != size.height) {
		mSurface = SDL_SetVideoMode(size.width, size.height, SURFACE_BPP, mSurfaceFlags);
		if(mSurface == NULL) {
			fprintf(stderr, "Failed to set video mode: %dx%d at %dbpp\n",
				size.width, size.height, SURFACE_BPP);
			exit(EXIT_FAILURE);
		}

		#ifdef _WIN32
			resources_reload();
		#endif
	}
}

//##############################################################################
// Exported functions
//##############################################################################
Size Window::GetSize()
{
	Size size = { 0 };
	if(mSurface != NULL) {
		size.width = mSurface->w;
		size.height = mSurface->h;
		return size;
	}
	return size;
}

void Window::ToggleFullscreen()
{
	if(mSurfaceFlags & SDL_FULLSCREEN) {
		mSurfaceFlags &= ~SDL_FULLSCREEN;
		Resize(mWindowSize);
	} else { 
		mSurfaceFlags |= SDL_FULLSCREEN;
		Resize(mScreenSize);				
	}
}

void Window::Initialize()
{
	SDL_WM_SetCaption(mCaption.c_str(), "");

	SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 5);
	SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 5);
	SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 5);
	SDL_GL_SetAttribute(SDL_GL_ALPHA_SIZE, 5);
	SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 16);
	SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
	SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE, 8);

	const SDL_VideoInfo * info = SDL_GetVideoInfo();
	mScreenSize.width = info->current_w;
	mScreenSize.height = info->current_h;

	if(mSurfaceFlags & SDL_FULLSCREEN) {
		Resize(mScreenSize);
	} else {
		Resize(mWindowSize);
	}
}
