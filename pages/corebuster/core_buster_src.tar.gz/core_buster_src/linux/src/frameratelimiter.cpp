#include <SDL.h>
#include <unistd.h>

#include "frameratelimiter.h"

//##############################################################################
// Static variables
//##############################################################################
static unsigned int m_start_ticks = 0;
static unsigned int m_stop_ticks = 0;
static int m_limit_frames = 1;

//##############################################################################
// Exported functions
//##############################################################################
void frameratelimiter_start()
{
	// When this environment variable is set, rely on GLSwapBuffers to provide
	// the appropriate delay to ensure a certain framerate, this means
	// SDL_Delay is not necessary.
	char * var = getenv("__GL_SYNC_TO_VBLANK");
	if(!(NULL == var || strcmp(var,"0") == 0))
		m_limit_frames = 0;
	m_start_ticks = SDL_GetTicks();
}

void frameratelimiter_stop()
{
	m_stop_ticks = SDL_GetTicks();
}

void frameratelimiter_limit_rate()
{
	unsigned int delta = m_stop_ticks - m_start_ticks;
	if(m_limit_frames && delta < 16)
		SDL_Delay(16 - delta);
}
