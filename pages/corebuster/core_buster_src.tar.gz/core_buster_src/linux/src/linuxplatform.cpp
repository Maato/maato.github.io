#include <SDL.h>
#include <SDL_image.h>
#include <unistd.h>
#include <cstdarg>
#include <sstream>

#include "platform.h"
#include "common.h"
#include "texture.h"

using namespace std;

void Platform::LogInfo(const char * fmt, ...)
{
	va_list args;
	va_start(args, fmt);
	vfprintf(stdout, fmt, args);
	fprintf(stdout, "\n");
	va_end(args);
}

void Platform::LogError(const char * fmt, ...)
{
	va_list args;
	va_start(args, fmt);
	vfprintf(stderr, fmt, args);
	fprintf(stderr, "\n");
	va_end(args);
}

Vector Platform::GetSize()
{
	const SDL_VideoInfo *info = SDL_GetVideoInfo();
	return Vector(info->current_w, info->current_h);
}

void Platform::ReportFailure(const char * cond, const char * filename, int line, const char * function)
{
	Platform::LogError("\nAssertion '%s' failed at %s:%d in %s", cond, filename, line, function);
	Platform::Quit();
	abort();
}

extern bool mRunning;
void Platform::Quit()
{
	mRunning = false;
}

double Platform::GetSeconds()
{
	struct timespec res;
	clock_gettime(CLOCK_REALTIME, &res);
	return res.tv_sec + (double)res.tv_nsec/1e9;
}

FILE * Platform::OpenFileForWriting(const char * name)
{
	/* Create file path */
	stringstream ss;
	ss << "res/" << name;
	string path = ss.str();

	return fopen(path.c_str(), "wb");
}

FILE * Platform::OpenResource(const char * name)
{
	/* Create file path name */
	stringstream ss;
	ss << "res/" << name;
	string path = ss.str();

	/* Open file */
	FILE * file = fopen(path.c_str(), "rb");
	return file;
}

char * Platform::GetFilesDir()
{
	return strdup(".");
}

KeyCode Platform::TranslateKey(int key_id)
{
	switch(key_id) {
		case SDLK_ESCAPE: return KEYCODE_BACK;
		case SDLK_RETURN: return KEYCODE_CONFIRM;
		case SDLK_TAB:    return KEYCODE_MENU;
		case SDLK_RIGHT:  return KEYCODE_RIGHT;
		case SDLK_LEFT:   return KEYCODE_LEFT;
		case SDLK_UP:     return KEYCODE_UP;
		case SDLK_DOWN:   return KEYCODE_DOWN;
		case SDLK_x:  return KEYCODE_SPACE;
		case SDLK_z:  return KEYCODE_SHIFT;
		default:          return KEYCODE_UNKNOWN;
	}
}
