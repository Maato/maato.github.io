#!/bin/bash

set -e

cd "$(dirname "$0")"

if [[ ! -d linux/build ]]; then
	echo "Making build directory"
	mkdir linux/build
fi

if [[ ! -f linux/build/Makefile ]]; then
	echo "Running cmake"
	(cd linux/build && cmake ..)
fi

make -C linux/build ; RETVAL="$?"

if [[ ! $RETVAL = 0 ]]; then
	echo "Building failed, nothing to run"
else
	echo "Stripping executable"
	strip linux/build/corebuster
	echo "Copying executable to working directory"
	cp linux/build/corebuster .
	echo "run ./corebuster to start the game"
fi

